from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf,hashlib
H=Path.home();sys.path.insert(0,str(H));from r118c4k_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4k_bass.py','matter.rs.txt':'r118c4k_matter.rs.txt','thomson.rs.txt':'r118c4k_thomson.rs.txt'},'REC':{'rec.py':'r118c4k_rec.py','feedback.py':'r118c4k_feedback.py','moving.py':'r118c4k_moving.py'},'REI':{'rei.py':'r118c4k_rei.py','probe.rs.txt':'r118c4k_probe.rs.txt','stage.rs.txt':'r118c4k_stage.rs.txt','clock.py':'r118c4k_clock.py'}}
notes={'BASS':['Actual C4J/C3X native baseline; compose tangent over entire represented 5120-step trajectory with simultaneous parameter control of radial weights and initial shear.','Differentiate original matter, Raychaudhuri/STF stage, matrix exponential coframe, actual harmonic RK4, parity and collision.','Analytic first-order tangent for fixed clock and Bianchi I. Independent fixed-coframe radial-weight and continuity derivative.','Native actual 4096+1024 steps; one tangent and four perturbation runs at p=±0.01,±0.003. Scope only C4K shadow.'],'REC':['Actual C4H 1773-step signed accepted history; differentiate lambda, including discrete moving event boundaries.','Use C3Z Map.mom3, affine atomic owner, three outgoing moments, C4J limiter.','Actual moving GL5 nodes and weights, centered spline parameter derivative, Planck and angular owner derivative, implicit gas stage. Independent fresh helium 2s emission and transport.','Full tangent and two actual nonlinear lambda runs, same grid; source HMLA and HeI post-stage coupled continuation.'],'REI':['Actual C4J native selected-cell support and number; test controlled threshold crossings, steep mean, exact native re-preparation.','Native positive moment reconstruction, actual Verner rate, native cell weights and geometry scale.','General moving-node covariance derivative; branch transition evidence separated. Independent observable-space CF4 defect transport.','One pinned native replay with actual cell and controlled probe scenarios, finite reference refinement and signed defect telescoping.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4k_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k):
 D=repos[k]/scopes[k]
 assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i,n in enumerate(notes[k],1):record(k,f'C{i}',n)
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):compile((D/dst).read_text(),str(D/dst),'exec')
 record(k,'C5','Runnable implementation and Python syntax checks; actual native build and numerical runs follow.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  r=job('bass.py',['build'],'build_driver',500);rr=[r]
  if r.get('exit')==0:rr.append(job('bass.py',['run'],'native',750))
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'feedback.py',[],'feedback',400)
   r=job('rec.py',['tangent'],'tangent',1000);rr=[r,f.result()]
   if r.get('exit')==0:
    rr+=list(ex.map(lambda p:job('rec.py',['fd',p],f'fd_{p:g}',700),[-.003,.003]))
    if all(x.get('exit')==0 for x in rr if x['tag'].startswith('fd_')):rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'clock.py',[],'clock',600);r=job('rei.py',['build'],'build_driver',500);rr=[r]
   if r.get('exit')==0:
    r=job('rei.py',['native'],'native',450);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['analyze'],'analysis',100))
   rr.append(f.result())
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n');print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual build/run exits and raw evidence: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a=j('COMPOSITE.json');ok=a is not None
  record(k,'C7','Full represented native composed tangent: '+json.dumps(a))
  record(k,'C8','Independent fixed-coframe weight/continuity numerical audit: '+json.dumps({x:a[x] for x in ['weight_fixed_coframe','continuity_fixed_coframe']} if a else None))
  next_='Propagate full second-order jet through actual native midpoint/Strang step, include external matter and general Lie types; use direct derivatives rather than finite cancellation.'
 elif k=='REC':
  a,b,c,d=j('LAMBDA_TANGENT.json'),j('FRESH_HEI.json'),j('FINAL_REC_COMPARISON.json'),j('BOUNDARY_CORRECTION_AUDIT.json');ok=all(x is not None for x in (a,b,c,d))
  record(k,'C7','Measured nodewise and direct-discrete-map tangent outcomes; fixed-topology nodewise route fails independent transient audit. Local half-jump correction and central secant comparison do not establish classical differentiability: '+json.dumps(dict(nodewise=a,comparison=c,boundary_correction=d)))
  record(k,'C8','Fresh source-owned helium 2s emission and H continuum absorption: '+json.dumps(b))
  next_='Implement and validate full branch-aware directional tangent (including event alignment and active LP) before a reverse adjoint. Distinguish central secants from classical derivatives; source H recombination radiation recycling and thermal balance.'
 else:
  a,b,c=map(j,['NATIVE_RUNS.json','MOVING_NODES.json','GOAL_DEFECT.json']);ok=a is not None and b is not None and c is not None
  record(k,'C7','Native represented cell and controlled threshold/steep branch derivatives: '+json.dumps(dict(native=a,nodes=b)));record(k,'C8','Observable-space CF4 signed defect transport and reference refinement: '+json.dumps(c))
  next_='Propagate branch-aware spectral reconstruction derivative through full accepted coupled radiation/geometry step; general coframe derivative and goal-adaptive interval selection.'
 record(k,'C9','Actual scientific and runtime status: '+json.dumps(rows)+'; local/represented scopes only; no full production regression or native subagent claim.')
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4K',base=base[k],scope=scopes[k],status=('SCOPED_EXECUTED_BRANCH_LIMITED' if k=='REC' else 'SCOPED_EXECUTED') if ok else 'SCOPED_PARTIAL',scientific_disposition='nodewise route falsified at transient; measured direct map central secant and local boundary correction only; full branch-aware tangent open' if k=='REC' else 'represented scoped tests only',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 k=sys.argv[1]
 if len(sys.argv)>2:finish(k);sys.exit()
 pre(k);r=execute(k)
 if all(x.get('exit')==0 for x in r):finish(k)
 else:print('REPAIR_REQUIRED',k,flush=True)

