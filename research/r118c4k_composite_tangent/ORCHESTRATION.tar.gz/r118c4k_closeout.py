"""C4K scoped closure; exact remote commit receipts and safe source/build scratch disposition."""
from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,datetime,shutil,gzip,io
H=Path.home();sys.path.insert(0,str(H));from r118c4k_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4k_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k]);assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=True,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists();manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False);manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def blob(k,n,rev=None):return subprocess.check_output(['git','-C',str(repos[k]),'show',(rev or git(repos[k],'rev-parse','HEAD'))+':'+n])
def published(k,n,hs):assert sha(blob(k,scopes[k]+'/'+n))==hs
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n');record(k,tag,'Verified archive members and matching remote head before scoped cleanup.',[target.name,mname]);published(k,target.name,info['archive_sha256'])
 return git(repos[k],'rev-parse','HEAD')
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
summary={'BASS':dict(composite=load(B/'COMPOSITE.json'),refined=maybe(B,'REFINED_COMPOSITE.json')),'REC':dict(lambda_tangent=maybe(R,'LAMBDA_TANGENT.json'),tangent=maybe(R,'TANGENT.json'),feedback=load(R/'FRESH_HEI.json'),spectral=load(R/'SPECTRAL_AUDIT.json'),fd_resolution=load(R/'FD_RESOLUTION.json'),terminal_repair=load(R/'TERMINAL_REPAIR_CHECK.json'),terminal_stencil=load(R/'TERMINAL_STENCIL_AUDIT.json'),direct_full=load(R/'DIRECT_FULL_TANGENT.json'),comparison=load(R/'FINAL_REC_COMPARISON.json'),boundary_correction=load(R/'BOUNDARY_CORRECTION_AUDIT.json')),'REI':dict(native=maybe(E,'NATIVE_RUNS.json'),nodes=maybe(E,'MOVING_NODES.json'),clock=load(E/'GOAL_DEFECT.json'),refinement=maybe(E,'GOAL_REFINEMENT.json'),endpoint_jump=load(E/'ENDPOINT_JUMP.json'))}
a=summary['BASS']['composite'];assert a['base_byte_replay'] and a['geometry_byte_replay'] and len(a['runs'])==5 and len(a['fd'])==4
assert len(summary['REC']['feedback']['rows'])==3 and len(summary['REI']['clock']['rows'])==4
assert summary['REC']['tangent'] is not None and summary['REC']['tangent']['steps']==1773 and summary['REC']['direct_full']['steps']==1773
assert summary['REC']['lambda_tangent'] is not None and len(summary['REC']['lambda_tangent']['finite_difference'])==1
assert len(summary['REC']['spectral']['rows'])==3 and summary['BASS']['refined'] is not None and summary['REI']['refinement'] is not None
for r in summary['REI']['clock']['rows']:assert max(r['adjoint_gap'])<1e-13 and max(r['forward_telescoping_gap'])<1e-12
if summary['REI']['native'] is not None:assert all(x['exit']==0 and all(x['replay_equal'].values()) for x in summary['REI']['native'])
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN';dag['htt_base_mutation']=False
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n');record(k,'C10-final-science','Final measured scoped results and actual source/claim boundaries; no original goal promotion.',['DAG.json','FINAL_SCIENCE.json'])
from r118c4k_coding import sources
names={k:list(v.values()) for k,v in sources.items()}
for k,v in sources.items():
 for dst,src in v.items():
  p=H/src; final= repos[k]/scopes[k]/dst
  assert p.is_file() and final.is_file() and not p.is_symlink() and not final.is_symlink()
  if hashfile(p)!=hashfile(final):
   assert dst in ('feedback.py','clock.py','bass.py','thomson.rs.txt','rec.py','moving.py','rei.py','stage.rs.txt','probe.rs.txt')
   shutil.copyfile(final,p)
common=['r118c4k_theory.py','r118c4k_coding.py','r118c4k_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4k_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4k_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';aux={'BASS':['refine.py'],'REC':['parallel_fd.py','spectral_audit.py','fd_resolution.py','rec_initial.py','diagnose_terminal.py','terminal_repair_check.py','terminal_stencil_audit.py','prefix_fd.py','direct_map_prefix.py','direct_map_full.py','local_node_audit.py','boundary_correction_audit.py','final_rec_audit.py'],'REI':['goal_refine.py','endpoint_jump.py']}[k];info=archive(target,[(H/n,n) for n in nn]+[(D/n,n) for n in aux]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
scratch={}
def cleanup(k,SH,prior,patches,table_hashes,binary_path,binary_archive,binary_sha,build_prefix):
 D=repos[k]/scopes[k]
 if not SH.exists():return dict(status='NOT_CREATED')
 assert SH.is_dir() and not SH.is_symlink() and SH.resolve()==SH
 if not binary_sha or not (SH/binary_path).is_file() or not (D/binary_archive).is_file():
  return dict(status='PRESERVED_INCOMPLETE_BUILD',path=str(SH))
 assert hashfile(SH/binary_path)==binary_sha==sha(gzip.decompress(blob(k,scopes[k]+'/'+binary_archive)))
 known=[];unique=[];build_n=build_bytes=0
 for p in sorted(SH.rglob('*')):
  assert not p.is_symlink(),str(p)
  if not p.is_file():continue
  rel=p.relative_to(SH);r=str(rel)
  if rel.parts[:len(build_prefix)]==build_prefix:
   build_n+=1;build_bytes+=p.stat().st_size;continue
  h=hashfile(p);kind=None
  if prior.get(r)==h:kind='pinned original source'
  elif r in patches:
   dest,want=patches[r];assert h==want
   if dest:published(k,dest,h)
   kind='verified published patched source'
  elif r in table_hashes:
   assert h==table_hashes[r];kind='verified generated stage table receipt'
  elif len(rel.parts)==2:
   dst=rel.parts[0]+'_'+rel.parts[1]
   if (D/dst).is_file() and hashfile(D/dst)==h:published(k,dst,h);kind='published actual native output'
  if kind:known.append(dict(path=r,sha=h,bytes=p.stat().st_size,kind=kind))
  else:unique.append((p,r))
 info=dict(known=known,build_files=build_n,build_bytes=build_bytes,exact_binary_sha=binary_sha);fs=['SHADOW_MANIFEST.json']
 if unique:
  target=D/'NATIVE_SHADOW_UNIQUE.tar.gz';info['unique']=archive(target,unique);fs.append(target.name)
 (D/'SHADOW_MANIFEST.json').write_text(json.dumps(info,indent=2)+'\n');record(k,'C10-shadow-verified','Exact source, patched files, run outputs and native binary checked. Unique files archived before removing scratch.',fs)
 if unique:published(k,target.name,info['unique']['archive_sha256'])
 published(k,'SHADOW_MANIFEST.json',hashfile(D/'SHADOW_MANIFEST.json'))
 nfiles=sum(1 for p in SH.rglob('*') if p.is_file());nbytes=sum(p.stat().st_size for p in SH.rglob('*') if p.is_file());assert nfiles==len(known)+len(unique)+build_n
 shutil.rmtree(SH);assert not SH.exists();return dict(status='REMOVED_VERIFIED',files=nfiles,logical_bytes=nbytes,unique_count=len(unique),build_files=build_n)
# BASS archived source restoration can be checked directly against the pinned git archive and exact C3X patches.
X=B.parent/'r118c3x_native_coefficients';i=load(X/'ops/BUILD_ID.json')['identity'];a=maybe(B,'BUILD_ID.json')
ar=subprocess.check_output(['git','-C',str(repos['BASS']),'archive',i['base'],'_rustcore','generated/rust/typeii','runtime/rust/typeii','research/r109_native_sky/hyrec_1100']);assert sha(ar)==i['archive_sha']
with tarfile.open(fileobj=io.BytesIO(ar)) as t:prior={m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}
patch={n:(None,h) for n,h in i['patched_sha'].items()}
assert a
patch.update({n:(v['file'],v['sha']) for n,v in a['changes'].items()})
scratch['BASS']=cleanup('BASS',H/'r118c4k_bass_shadow',prior,patch,{},'_rustcore/target/release/examples/c3x_radial','composite_jet.gz',a['binary_sha'],('_rustcore','target'))
F=E.parent/'r118c4f_external_stress';prev=load(F/'SHADOW_ARCHIVE.json');assert hashfile(F/'NATIVE_SHADOW_SOURCE.tar.gz')==prev['archive_sha256'];prior={x['name']:x['sha256'] for x in prev['members']};a=load(E/'BUILD_ID.json')
patch={n:(v['file'],v['sha']) for n,v in a['changes'].items()}
scratch['REI']=cleanup('REI',H/'r118c4k_rei_shadow',prior,patch,{},'bridge/target/release/c3x_dg_bridge','moving_bridge.gz',a['binary_sha'],('bridge','target'))
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4k_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed)
 if k in scratch:obj['scratch']=scratch[k]
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Verified scoped redundant drivers and scratch cleanup; unrelated data/worktrees preserved.',['FINAL_CLEANUP.json'])
for k in repos:
 p=H/f'r118c4k_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4K',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),scratch=scratch,prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN',htt_base_mutation=False)
(H/'r118c4k_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4k_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],scratch=scratch,prunes=prunes),indent=2),flush=True)
