from pathlib import Path
import sys,json,subprocess,hashlib,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4l_theory import repos,scopes,base,git,record,notes
sources={'BASS':{'bass.py':'r118c4l_bass.py','matter.rs.txt':'r118c4l_matter.rs.txt','thomson.rs.txt':'r118c4l_thomson.rs.txt','lie.rs.txt':'r118c4l_lie.rs.txt','lie.py':'r118c4l_lie.py'},'REC':{'rec.py':'r118c4l_rec.py','feedback.py':'r118c4l_feedback.py'},'REI':{'rei.py':'r118c4l_rei.py','stage.rs.txt':'r118c4l_stage.rs.txt','clock.py':'r118c4l_clock.py'}}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4l_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k):
 D=repos[k]/scopes[k];assert [x['stage'] for x in receipts(k) if x['stage'].startswith('R')]==[f'R{i}' for i in range(1,11)]
 for i,n in enumerate([notes[k][0],notes[k][2],notes[k][4],notes[k][3]],1):record(k,f'C{i}',n)
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):compile((D/dst).read_text(),str(D/dst),'exec')
 record(k,'C5','Executable implementation, syntax checked; execution and measured evidence are separate.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  t=time.monotonic();cmd=[sys.executable,'-u',str(D/file),*map(str,args)]
  try:
   with (D/(tag+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   result=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-t,command=cmd)
  except Exception as e:result=dict(tag=tag,error=repr(e),seconds=time.monotonic()-t,command=cmd)
  print(k,result,flush=True);return result
 if k=='BASS':
  b=job('bass.py',['build'],'build_driver',600);rows=[b]
  if b.get('exit')==0:
   with cf.ThreadPoolExecutor(max_workers=2) as ex:
    f=ex.submit(job,'lie.py',[],'lie',120);r=job('bass.py',['run'],'native',900);rows.extend([r,f.result()])
   if r.get('exit')==0:rows.append(job('bass.py',['analyze'],'analysis',120))
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'feedback.py',[],'feedback',300);r=job('rec.py',[],'directional',1400);rows=[r,f.result()]
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'clock.py',[],'clock',450);b=job('rei.py',['build'],'build_driver',550);rows=[b]
   if b.get('exit')==0:
    r=job('rei.py',['native'],'native',600);rows.append(r)
    if r.get('exit')==0:rows.append(job('rei.py',['analyze'],'analysis',100))
   rows.append(f.result())
 (D/'EXECUTION.json').write_text(json.dumps(rows,indent=2)+'\n');return rows
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 files=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual commands, exit status and raw evidence: '+json.dumps(rows),sorted(set(files)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 a,b={'BASS':('JET2.json','LIE_STRESS.json'),'REC':('DIRECTIONAL.json','THERMAL_FEEDBACK.json'),'REI':('IMPLICIT_BRANCH.json','HELDOUT_GOAL.json')}[k];m,n=j(a),j(b)
 record(k,'C7','Measured main route, claim bounds: '+json.dumps(m))
 record(k,'C8','Independent science route, measured results: '+json.dumps(n))
 (D/'FINAL_SCIENCE.json').write_text(json.dumps(dict(main=m,independent=n,execution=rows),indent=2)+'\n')
 record(k,'C9','Evidence status: execution is not scientific promotion. Actual main/independent data inspected; no production integration, subagent or continuum claims. '+json.dumps(rows),['FINAL_SCIENCE.json'])
 next_={'BASS':'Extend second coefficient with external and general Lie transport/opacity response; preserve fixed-clock Taylor evidence.','REC':'Implement full analytic branch-aware event and limiter directional derivatives; reverse adjoint only after validation; integrate thermal and two-photon detailed balance without double counting.','REI':'Couple local directional reconstruction/gas derivative to all native radiation/geometry stages; re-evaluate goal policy on held-out physical clocks.'}[k]
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4L',base=base[k],status='SCOPED_EXECUTED' if m is not None and n is not None else 'SCOPED_PARTIAL',main=a,independent=b,execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 record(k,'C10','Scoped disposition and next executable science. '+next_,['NEXT.md','DAG.json'])
if __name__=='__main__':
 k=sys.argv[1]
 if len(sys.argv)>2:finish(k)
 else:
  pre(k);r=execute(k)
  if all(x.get('exit')==0 for x in r):finish(k)
  else:print('REPAIR_REQUIRED',k,r,flush=True)
