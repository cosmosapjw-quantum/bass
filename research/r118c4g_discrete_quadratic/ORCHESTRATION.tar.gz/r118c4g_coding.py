from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4g_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4g_bass.py','haar.py':'r118c4g_haar.py'},'REC':{'rec.py':'r118c4g_rec.py'},'REI':{'rei.py':'r118c4g_rei.py'}}
notes={'BASS':['C3X native midpoint+Strang coefficient, same C4F controls, native source and actual clock; independent adaptive Haar.','Archived Rust source, exact harmonic generator and FD radial normalization, native time stepping vs prior continuous DP5.','Taylor order-2 split and first-order geometry, longdouble; fixed native clock. Defensive cube proposal from pilot, independent evaluation and C4F replay.','Five actual time levels, 5 control cases, independent 4 likelihood targets and 2 scrambles.'], 'REC':['C4F 1613-step history, actual outgoing Legendre boundary jumps, fixed H and same weak moments.','Exact scalar and direct/signed source owner, gas affine JumpResponse, actual C4F He rates.','Rank 32 actual source knots and causal arrivals by gas Jacobian response; preserve prior grid, same +/- cases. Conservative two-photon profile diagnostic.','96 added nodes, 3 direct then 2 paired. 3 symmetric profiles x 3 frequency grids.'], 'REI':['C4F source archive and binary identity, exact accepted nodes, larger finite difference stencils; separate sparse truncation estimate.','Source-owned work and pressure, stable signed finite step response; C4F conditional tangent; C3Z generator.','Reconstruct work density directly and separately evolve continuity; polynomial projected defect estimator excludes full exponential from decision.','16 fresh native runs, 4 concurrent, compare original stencil and 8 prescribed geometry responses; 36 closure diagnostic cases.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4g_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst);subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Runnable scoped code and actual Python syntax compilation; native binary checked at runtime.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   fs=[ex.submit(job,'bass.py',[],'discrete',450),ex.submit(job,'haar.py',[],'haar',450)];rr=[f.result() for f in fs]
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=3) as ex:
   f=ex.submit(job,'rec.py',['helium'],'helium',120);r=job('rec.py',['mesh'],'mesh',180);rr=[r,f.result()]
   if r.get('exit')==0:
    ds=list(ex.map(lambda l:job('rec.py',['direct',l],f'direct_{l:g}',450),[0.,-.5,.5]));rr+=ds
    if all(x.get('exit')==0 for x in ds):
     ps=list(ex.map(lambda l:job('rec.py',['pair',l],f'pair_{l:g}',700),[-.5,.5]));rr+=ps
     if all(x.get('exit')==0 for x in ps):rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'rei.py',['adaptive'],'adaptive',240);r=job('rei.py',['native'],'native',900);rr=[r,f.result()]
   if r.get('exit')==0:
    r=job('rei.py',['work'],'work',90);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['geometry'],'geometry',180))
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n');print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual execution exits and artifacts, initial failures retained: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a,b=j('DISCRETE_B2.json'),j('ADAPTIVE_HAAR.json');record(k,'C7','Source-owned discrete coefficient and finite native comparisons: '+json.dumps(a));record(k,'C8','Adaptive importance integration, fixed data and prior: '+json.dumps(b));ok=a is not None and b is not None
  next_='Carry exact discrete coefficient into native Rust owner or compare higher jets and clock/geometry source; refine adaptive rotation quadrature with independent pilot and observed ESS.'
 elif k=='REC':
  a,b,o=map(j,['MESH.json','WEIGHTED_SUMMARY.json','HELIUM_SPECTRAL_PROXY.json']);record(k,'C7','Weighted source history arrivals and actual direct/signed comparison: '+json.dumps(dict(mesh=a,signed=b)));record(k,'C8','Conservative profile diagnostic from actual effective He rates: '+json.dumps(o));ok=a is not None and b is not None and o is not None
  next_='Test source-weighted arrival refinement against additional independent globally fine reference; develop source-owned He I two-photon spectrum and actual H I absorption.'
 else:
  a,b,o,c=map(j,['NATIVE_RUNS.json','WORK_STENCILS.json','DEFECT_CLOSURE.json','WORK_CONSTRAINED_TANGENT.json']);record(k,'C7','Fresh native stencils and work-based conditional response: '+json.dumps(dict(native=a,work=b,geometry=c)));record(k,'C8','Actual sparse polynomial defect adaptive diagnostics: '+json.dumps(o));ok=a is not None and all(x['exit']==0 for x in a) and b is not None and c is not None and o is not None
  next_='Derive and implement analytic discrete gas Jacobian through actual implicit native stages, work-state tangent rather than cancellation; validate adaptive defect on physical higher-depth history.'
 record(k,'C9','Self-review and actual failure boundaries: '+json.dumps(rows)+'; no production regression, exact full native coupled tangent or continuum promotion.')
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4G',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

