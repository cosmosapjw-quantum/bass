"""Final C4G verified publication and exact scoped cleanup."""
from pathlib import Path
import sys,json,subprocess,hashlib,tarfile,datetime,os,shutil,gzip
H=Path.home();sys.path.insert(0,str(H));from r118c4g_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4g_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k,clean=True):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k])
 if clean:assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=not status,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists()
 manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False)
   manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def verify_remote_file(k,name,hs):
 p=repos[k];h=git(p,'rev-parse','HEAD');b=subprocess.check_output(['git','-C',str(p),'show',h+':'+scopes[k]+'/'+name]);assert sha(b)==hs;return h
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n')
 record(k,tag,'Verified archive member bytes and matching remote commit before scoped deletion.',[target.name,mname])
 return verify_remote_file(k,target.name,info['archive_sha256'])
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
discrete=maybe(B,'DISCRETE_B2.json');haar=maybe(B,'ADAPTIVE_HAAR.json');time_refine=maybe(B,'TIME_REFINEMENT.json');mesh=maybe(R,'MESH.json');rec=maybe(R,'WEIGHTED_SUMMARY.json');he=maybe(R,'HELIUM_SPECTRAL_PROXY.json');rei=maybe(E,'NATIVE_RUNS.json');work=maybe(E,'WORK_STENCILS.json');geo=maybe(E,'WORK_CONSTRAINED_TANGENT.json');cl=maybe(E,'DEFECT_CLOSURE.json');defect=maybe(E,'DEFECT_EXTENDED.json');defect_recur=maybe(E,'DEFECT_RECURRENCE.json')
assert discrete is not None and len(discrete['rows'])==5 and haar is not None and len(haar['rows'])==8
if time_refine is not None:assert len(time_refine['n'])==7
if rei is not None:assert len(rei)==16 and all(x['exit']==0 for x in rei)
if work is not None:assert len(work['rows'])==8
if geo is not None:assert len(geo['rows'])==2 and all(len(x['directions'])==4 for x in geo['rows'])
if cl is not None:assert len(cl['rows'])==36
if defect is not None:assert len(defect['rows'])==36
if rec is not None:assert len(rec['pairs'])==2 and rec['steps']==mesh['steps'] and rec['min_positive']>0
if he is not None:assert len(he['rows'])==9
summary={'BASS':dict(discrete=discrete,haar=haar,time_refine=time_refine),'REC':dict(mesh=mesh,weighted=rec,helium=he,weight_replay=maybe(R,'WEIGHT_REPLAY.json')),'REI':dict(native=rei,work=work,geometry=geo,adaptive=cl,defect_recurrence=defect_recur,defect_extended=defect)}
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN';dag['htt_base_mutation']=False
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n')
 record(k,'C10-final-science','Final scoped results, checked actual artifacts and source boundary; no original-goal promotion.', ['DAG.json','FINAL_SCIENCE.json'])
names={'BASS':['r118c4g_bass.py','r118c4g_haar.py'],'REC':['r118c4g_rec.py'],'REI':['r118c4g_rei.py']}
common=['r118c4g_theory.py','r118c4g_coding.py','r118c4g_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4g_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4g_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';info=archive(target,[(H/n,n) for n in nn]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
# Scratch contains only one previously published binary and newly published native outputs.
SH=H/'r118c4g_native_scratch';shadow=dict(status='NOT_CREATED')
if SH.exists():
 assert SH.is_dir() and not SH.is_symlink() and SH.resolve()==SH
 duplicates=[];unique=[]
 prior='research/r118c4f_external_stress';priorrev='f2fea96867a553606ca220a16ad63666401bbb49';priorbin=gzip.decompress(subprocess.check_output(['git','-C',str(repos['REI']),'show',priorrev+':'+prior+'/c4f_dg_bridge.gz']))
 for p in sorted(SH.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file():continue
  rel=p.relative_to(SH)
  if str(rel)=='c4f_dg_bridge':
   assert sha(priorbin)==hashfile(p)
   duplicates.append(dict(source=str(rel),remote=priorrev+':'+prior+'/c4f_dg_bridge.gz',bytes=p.stat().st_size,sha256=hashfile(p)));continue
  dst=rel.parts[0]+'_'+rel.parts[1] if len(rel.parts)==2 else str(rel)
  if (E/dst).is_file() and hashfile(E/dst)==hashfile(p):
   verify_remote_file('REI',dst,hashfile(p));duplicates.append(dict(source=str(rel),remote=dst,bytes=p.stat().st_size,sha256=hashfile(p)))
  else:unique.append((p,str(rel)))
 info=dict(duplicates=duplicates,duplicate_count=len(duplicates),prior_binary_sha=sha(priorbin))
 fs=['SCRATCH_ARCHIVE.json']
 if unique:
  target=E/'NATIVE_SCRATCH_UNIQUE.tar.gz';info['unique']=archive(target,unique);fs.append(target.name)
 (E/'SCRATCH_ARCHIVE.json').write_text(json.dumps(info,indent=2)+'\n')
 record('REI','C10-scratch-verified','Every scratch file byte-verified against published output or archived uniquely; original binary matched previous immutable commit.',fs)
 if unique:verify_remote_file('REI',target.name,info['unique']['archive_sha256'])
 verify_remote_file('REI','SCRATCH_ARCHIVE.json',hashfile(E/'SCRATCH_ARCHIVE.json'))
 nfiles=sum(1 for p in SH.rglob('*') if p.is_file());nbytes=sum(p.stat().st_size for p in SH.rglob('*') if p.is_file())
 assert nfiles==len(duplicates)+len(unique)
 shutil.rmtree(SH);assert not SH.exists()
 shadow=dict(status='REMOVED_VERIFIED',files=nfiles,logical_bytes=nbytes,duplicate_count=len(duplicates),unique_count=len(unique),prior_binary_sha=sha(priorbin))
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4g_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed)
 if k=='REI':obj['shadow']=shadow
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Scoped redundant drivers and verified shadow cleanup; no unrelated worktree or data removed.',['FINAL_CLEANUP.json'])
for k in repos:
 p=H/f'r118c4g_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4G',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),shadow=shadow,prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN',htt_base_mutation=False)
(H/'r118c4g_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4g_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],shadow=shadow,prunes=prunes),indent=2),flush=True)
