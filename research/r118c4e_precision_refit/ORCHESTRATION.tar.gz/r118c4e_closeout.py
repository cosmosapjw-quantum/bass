"""R118-C4E final science/remote verification and scoped scratch cleanup."""
from pathlib import Path
import sys,json,subprocess,hashlib,tarfile,datetime,os,shutil
H=Path.home();sys.path.insert(0,str(H));from r118c4e_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4e_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k,clean=True):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k])
 if clean:assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=not status,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists()
 manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False)
   manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def verify_remote_file(k,name,hs):
 p=repos[k];h=git(p,'rev-parse','HEAD');b=subprocess.check_output(['git','-C',str(p),'show',h+':'+scopes[k]+'/'+name]);assert sha(b)==hs;return h
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n')
 record(k,tag,'Verified archive member bytes and matching remote commit before scoped deletion.',[target.name,mname])
 return verify_remote_file(k,target.name,info['archive_sha256'])
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
refit=maybe(B,'REFIT.json');direct=maybe(B,'DIRECT_REFIT.json');native=maybe(B,'NATIVE_REFINED.json');haar=maybe(B,'HAAR_COVARIANCE.json');haar_refined=maybe(B,'HAAR_COVARIANCE_2048.json');rec=maybe(R,'EARLY_SUMMARY.json');he=maybe(R,'PRIMORDIAL_HE_ENERGY.json');geo=maybe(E,'SIGNED_GEOMETRY.json');cl=maybe(E,'CLOSURE_REGIME.json')
if native is not None:assert len(native['rows'])==13 and all(x['exit']==0 for x in native['rows'])
if haar is not None:assert haar['n_pairs']==190 and haar['train']==130 and haar['new_test']==20
if haar_refined is not None:assert haar_refined['orientation_count']==2048 and haar_refined['n_pairs']==190 and haar_refined['tau2']==haar['tau2']
if geo is not None:assert len(geo['rows'])==2 and all(len(x['directions'])==4 for x in geo['rows'])
if cl is not None:assert len(cl['rows'])==36
summary={'BASS':dict(refit=refit,direct=direct,native=native,haar=haar,haar_refined=haar_refined),'REC':dict(early=rec,primordial_helium=he),'REI':dict(geometry=geo,regime=cl)}
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN'
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n')
 record(k,'C10-final-science','Final scoped results, checked actual artifacts and source boundary; no original-goal promotion.', ['DAG.json','FINAL_SCIENCE.json'])
names={'BASS':['r118c4e_bass.py','r118c4e_haar.py'],'REC':['r118c4e_rec.py'],'REI':['r118c4e_rei.py']}
common=['r118c4e_theory.py','r118c4e_coding.py','r118c4e_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4e_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4e_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';info=archive(target,[(H/n,n) for n in nn]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
# The cycle did not create a native shadow/worktree; remove only its verified redundant script copies, pyc and empty lock files.
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4e_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True,no_new_native_shadow=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed)
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Scoped redundant scripts removed after remote archive verification; no unrelated worktree or data removed.',['FINAL_CLEANUP.json'])
# Locks were released by record; no further mutation via record.
for k in repos:
 p=H/f'r118c4e_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4E',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN')
(H/'r118c4e_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4e_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],prunes=prunes),indent=2),flush=True)
