from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4e_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4e_bass.py','haar.py':'r118c4e_haar.py'},'REC':{'rec.py':'r118c4e_rec.py'},'REI':{'rei.py':'r118c4e_rei.py'}}
notes={'BASS':['C4D control/budget/clock, high-precision temporal basis and heldout radial matrix, native 8192 and independent actual Haar covariance.','C4D DP5 and harmonic bilinear map, C4A wedge target, C4B H/A, C3X native binary and official mask/beam.','Generic n extended DP5 in Schur basis, local constrained Newton; separate 192/256 direct control validation; Gaussian amplitude-prior orientation marginalization.','Two basis runs, independent physical validation, 13 actual 8192 runs, 60 new MC samples, disjoint paths and bounded workers.'],
'REC':['Early-only 4-way split z>=1108.5 from exact 128-grid, compare global dyadic 256 results. Independent helium source-stage energy demand.','C4D actual cumulative response, C4A quadratic native owner and C4B reference, source-owned primordial helium module.','Same fixed H and positivity; exact nested nodes; stable signed subtraction; ideal-gas binding and Compton first-law requirement with explicit T lock.','Scalar then direct +/- then paired; independent helium calculations; preserve all solver failures; no donor activation.'],
'REI':['Actual C4D DG3 gas directions on 2 grids; constrained signed Einstein/matter/primary response with prescribed external trace+collision STF; independent closure regime.','Exact C3Y quadrature, C3Z harmonic generator and C4C external contribution; actual raw C4D native histories.','Constraint algebra, dynamic lnH ODE, coframe and massive moments, opacity derivative, pressure trace, signed small scaling. Compare both formulations. Retained low-l closure on prescribed amplified histories.','Eight direction tangents, 36 finite closure cases, bounded actual source-owned calculations. No rebuild or production edit.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4e_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst);subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Executable scoped source and syntax verification.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  t=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-t)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-t)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'haar.py',[],'haar',650);r=job('bass.py',['fit'],'fit',350);rr=[r]
   if r.get('exit')==0:rr.append(job('bass.py',['native'],'native',750))
   rr.append(f.result())
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'rec.py',['helium'],'helium',90);r=job('rec.py',['direct',0.],'direct0',350);rr=[r,f.result()]
   if r.get('exit')==0:
    a=list(ex.map(lambda l:job('rec.py',['direct',l],f'direct_{l:g}',600),[-.5,.5]));rr+=a
    zz=[l for l,r in zip([-.5,.5],a) if r.get('exit')==0]
    rr+=list(ex.map(lambda l:job('rec.py',['pair',l],f'pair_{l:g}',650),zz))
   rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   rr=list(ex.map(lambda a:job('rei.py',[a],a,240),['geometry','regime']))
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n')
 print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual execution exits and numerical artifacts, including any failed runs: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  r=j('REFIT.json');d=j('DIRECT_REFIT.json');n=j('NATIVE_REFINED.json');o=j('HAAR_COVARIANCE.json')
  record(k,'C7','High precision constrained refit, independent direct control and native finite coefficients: '+json.dumps(dict(refit=r,direct=d,native=n)))
  record(k,'C8','Actual enlarged Commander covariance and proper Haar likelihood ratio: '+json.dumps(o))
  ok=all(x is not None for x in [r,d,n,o]);next_='Use actual heldout radial/refit and native convergence differences to choose robust controls, extend direct perturbative coefficient and higher-order jet; keep full likelihood open.'
 elif k=='REC':
  r=j('EARLY_SUMMARY.json');o=j('PRIMORDIAL_HE_ENERGY.json')
  record(k,'C7','Actual early-targeted retarded direct/signed comparison: '+json.dumps(r))
  record(k,'C8','Source-owned primordial helium gas energy demand: '+json.dumps(o))
  ok=r is not None and len(r.get('pairs',[]))==2 and o is not None;next_='Use cumulative early/global discrepancy to target propagated delay arrivals and odd response; independent primordial spectral owner required to close energy.'
 else:
  r=j('SIGNED_GEOMETRY.json');o=j('CLOSURE_REGIME.json')
  record(k,'C7','Actual signed conditional Einstein/massive/primary tangent: '+json.dumps(r))
  record(k,'C8','Finite low-l closure regime map: '+json.dumps(o))
  ok=r is not None and len(r['rows'])==2 and all(len(x['directions'])==4 for x in r['rows']) and o is not None;next_='Expose complete native external pressure/energy/source derivative and rate Jacobian; verify fully coupled signed tangent; use observed closure error to choose retained l.'
 record(k,'C9','Self-review, actual scope and failure status: '+json.dumps(rows)+'; no production regression, full native or continuum promotion.')
 (D/'NEXT.md').write_text(next_+'\n')
 (D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4E',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:
  finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

