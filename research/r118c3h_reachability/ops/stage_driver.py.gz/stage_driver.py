from pathlib import Path
import subprocess, os,json,hashlib,concurrent.futures,sys
H=Path.home()
repos={
'BASS':(H/'worktrees/bass-r109-native-20261124','research/r118c3h_reachability','98d332e3dc0007d52f06a25fd32d360a007a223f','research/r109-native-nonlinear-sky-20261124'),
'REC':(H/'Downloads/htt_r109_original_rec','research/r118c3h_paired_history','d0e95dcb8ff7695d72e01673f0831757b4593e82','research/r109-finite-tilt-ray-thomson-20261124'),
'REI':(H/'worktrees/rei-htt-thomson-20261124','research/r118c3h_chemistry_ledger','0c6b6ddb4d5dcb3bca9a7e406e8f3f7681271a56','research/htt-tilted-thomson-20261124')}
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
receipt=H/'r118c3h_push_receipts_20261126.jsonl'
def git(r,*args):
 p=subprocess.run(['git','-C',str(r),*args],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{r.name}: {args}: {p.stdout}')
 return p.stdout.strip()
def folder(k):r,d,_,_=repos[k];return r/d
def write(k,name,content):
 p=folder(k)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content.rstrip()+'\n' if isinstance(content,str) else json.dumps(content,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def publish(k,stage,extra=()):
 r,d,base,branch=repos[k];assert git(r,'branch','--show-current')==branch
 assert not git(r,'diff','--cached','--name-only')
 git(r,'add',*(['--sparse'] if k=='REI' else []),'--',d,*extra)
 git(r,'diff','--cached','--check')
 staged=git(r,'diff','--cached','--name-only').splitlines()
 assert staged and all(x.startswith(d+'/') or x in extra for x in staged),staged
 git(r,'commit','-m',f'R118-C3H {stage}: {k} science')
 head=git(r,'rev-parse','HEAD');git(r,'push','origin',f'HEAD:refs/heads/{branch}')
 remote=git(r,'ls-remote','--heads','origin',f'refs/heads/{branch}').split()[0];assert remote==head
 return dict(stage=stage,repo=k,head=head,remote=remote,tree=git(r,'rev-parse','HEAD^{tree}'),paths=staged)
def batch(stage,extras=None):
 done={(v['stage'],v['repo']) for v in map(json.loads,receipt.read_text().splitlines())} if receipt.exists() else set()
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(publish,k,stage,(extras or {}).get(k,())):k for k in repos if (stage,k) not in done};errs=[]
  for f in concurrent.futures.as_completed(fut):
   try:
    row=f.result();print('PUSH',row['stage'],row['repo'],row['head'],flush=True)
    with receipt.open('a') as h:h.write(json.dumps(row)+'\n')
   except Exception as e: print('ERROR',fut[f],stage,repr(e),flush=True);errs.append(e)
  if errs:raise RuntimeError('publication incomplete')
def note(stage,content):
 for k,t in zip(repos,content):write(k,stage+'.md','# '+stage+' | R118-C3H '+k+'\n\n'+t)
 batch(stage)
if __name__=='__main__':
 for k,(r,d,b,br) in repos.items():
  assert git(r,'rev-parse','HEAD')==b and git(r,'branch','--show-current')==br
  assert git(r,'ls-remote','--heads','origin',f'refs/heads/{br}').split()[0]==b
  assert not (r/d).exists()
 note('R1',[
  'C3G 98d332e source. Main: for an axial-normal span, construct candidate controls by linear temporal-mode congruence, then test native dynamics with nonzero wedge. Independent: analytic principal-angle spectrum in terms of STF eigenvalue gaps and linear reachability conditioning. Preserve C3F scalar donor; no production null claim.',
  'C3G d0e95dc source. Main: paired angular-on/off common-H local history at 256/512/1024 steps, 128 rays, alternate accepted-source interpolation. Independent: physical Lyman-alpha crossing stock and explicit 1s->2p excitation ledger under a prescribed absorbing-screen probability, no claim of full net reaction. Preserve original atomic prefix and source hashes.',
  'C3G 0c6b6ddb4 source. Main: corrected EOS-coupled signed spectrum at 4096/8192 bins; carry thermal ENERGY, not T at changing composition; explicit binding ledger under external chemistry owner. Independent: nested frequency cutoffs at exactly fixed log-spacing. No production activation or full autonomous chemistry.'])
 note('R2',[
  'Heinzle & Uggla, Dynamics of the spatially homogeneous Bianchi type I Einstein–Vlasov equations, https://arxiv.org/abs/gr-qc/0512031, establishes anisotropic stress and shear dynamics in reflection-symmetric subclass. No result there on general off-diagonal memory wedge reachability. Reuse C3G Gram and native solver as actual authority.',
  'Chluba & Sunyaev (2007), cosmological hydrogen recombination Lyman-line feedback and continuum escape, https://scispace.com/papers/cosmological-hydrogen-recombination-lyn-line-feedback-and-48r674jvyg : delayed feedback across Lyman lines. Hirata & Forbes, https://scispace.com/papers/lyman-alpha-transfer-in-primordial-hydrogen-recombination-zw2yc93gbjwk : time-dependent transfer, not validation of directional closure. Use original HyRec Oct2012 atomic data. An absorbing crossing is not the net Ly-alpha source because of reemission and stimulated emission.',
  'Comparison of numerical methods for computing the repeated Compton scattering of photons in isotropic media, MNRAS 507 2052 (2021), https://academic.oup.com/mnras/article/507/2/2052/6342116 : exact scattering matrix vs FP; log grid and conservation. Chluba, Greens function of cosmological thermalization II, https://academic.oup.com/mnras/article/454/4/4182/999273 : photon number and energy both matter. Our low electron temperature/low physical photon energy fits nonrelativistic regime, not exact high-frequency kernel.'])
 note('R3',[
  'C3G memory_controls.py supplies Frobenius STF basis, pair order and P3. Native r118c3g_controls.rs uses three massive distributions with J norm <=0.1, positive weights sum 1 and initial shear. Axialfine geometry provides a measured linear-response proxy, not exact scalar basis at finite amplitude. Extract temporal coefficients in its leading span and audit condition number/Pfaffian.',
  'C3G shared_gas.py uses canonical_history.incoming_canonical, linear temporal interpolation and immutable accepted prefix. On/off delta changes +1.15e-9 at 64 to -2.92e-11 at 512 (32 rays). Current pair signal smaller than discretization error. Compare equal H, time grid and ray count, both interpolation families. C3G accepted ray NPZ plus coframe provides stock diagnostic only.',
  'C3G spectral_coupling.py uses abundance_from_clock (Y=0.0813013517), corrected Cv. C3B bridge ledger tracks u_primary+w+B- initial-source+escape+cmb+work. Native HHe binding thresholds from coupled_primary.rs. C3G coupled local Cv_mid*(T_new-T_pred) does not equal change of state energy when composition changes. New mode tracks w=Cv(x)T explicitly.'])
 note('R4',[
  'Routes: exact gap formula for arbitrary normal; build candidate axial congruence using rank-four temporal skew coefficient matrix; test scaled controls at two amplitudes and native resolution. If condition number huge, scale to respect all owner norms and retain relative result and absolute wedge. Alternative orthogonal-only rotations cannot change skew singular value ratio. No global optimization claim.',
  'Routes: same-grid pairs at high angular order; local PCHIP vs linear history interpolation using only available accepted points, no extrapolation through prefix switch; paired residual difference from stored x/T/f. Independent finite-volume crossing formula with optically thin/thick controls and physically specified line energy. Do not add full feedback on unresolved signal.',
  'Routes: exact nested grids (drop leading edges, identical spacing), fixed-chemistry comparison, variable-composition energy owner. Two chemical-work models: prescribed external source equals Delta B (isolates kinetic redistribution), and baseline-calibrated non-spectral energy using native thermal/binding plus legacy CMB/FF energy transfer. Latter is conditional replay, not independent prediction.'])
 note('R5',[
  'Derived: rotation generators L_i=[Omega_i,.] have wedge norm squared 5, mutually orthogonal (Wolfram exact matrix). For unit normal N with eigenvalues a,b,c and W=N^perp, projection from normalized spin1 generators to n∧W equals contraction A n, whose Gram in principal axes is diag(2(b-c)^2,2(a-c)^2,2(a-b)^2)/5. By principal-angle complement duality the six singular values of P3 restricted to wedge^2 W are three unit values and sqrt(2/5)*the three absolute gaps. Thus min bound is exact, not just numerical SVD. For scalar S(t)=A g(t), Wedge(t_f)=A M A^T where M evolves via scalar response and antisymmetric memory. For invertible rank-four skew M, orthogonal Schur blocks m1 J,m2 J can be congruence-scaled to prescribed axial spin1 blocks 2J,J; overall scaling controls positivity and amplitude. Reachability only conditional on fixed scalar modes and free control tensor orientations; finite native system must test it.',
  'Derived: for t in [h_k,h_{k+1}], monotone cubic Hermite interpolation uses local harmonic slope d_k=(w1+w2)/(w1/m_prev+w2/m_next) for same-sign adjacent secants, zero otherwise. Clip roundoff to endpoint interval; fallback to linear if stencil crosses the prefix/suffix join or accepted end. No future samples. Paired residual identity (delta x_new-delta x_old)-dt/2*(delta f_old+delta f_new)=r_on-r_off; evaluate using longdouble for subtraction diagnostic. For redshift monotone along ray E=q r/a, Lyman crossing shell q in [E_L a0/r0,E_L a1/r1]. In piecewise constant f integrate q^2 dq exactly; split captured p and transmitted 1-p. Absorbed photons debit number and E_L energy to 1s->2p excitation at crossing, redshift work equals initial crossing-shell energy minus E_L*N. Screen assumes prescribed probability, no emitted photons or competing processes.',
  'Derived: w=1.5 kB(1+Y+xe)T eV/H, B=chi_H xHII+Y[chi_HeI xHeII+(chi_HeI+chi_HeII)xHeIII]. Exact adiabatic map at fixed w owner: w_ad=w_old*(a_old/a_new)^2; W_g=w_old-w_ad. Discrete gas equation w_new+B_new=w_ad+B_old+Q_ext-Q_C-Q_FF. Signed spectral U obeys U_new-U_old+W_rad=Q_C+Q_FF (using existing midpoint energy scale). Thus gas+radiation closure Delta(w+B+U)+W_g+W_rad-Q_ext=0. Q_ext=Delta B for a prescribed binding-funded experiment; or infer reference Q_ext from reference w_ad and B plus reconstructed legacy radiation increments, which is explicitly baseline-calibrated and approximate at stage midpoint. No double-counted legacy term in new residual. Fixed log grid by common upper edge and truncation of integer bins; common cells exactly identical.'])
 note('R6',[
  'Self-review: complement principal-angle argument includes dimension difference, hence three forced unit singular values. Test arbitrary rotated normals and degenerate gaps. Congruence is NOT physical controllability proof; exact norm and minimum wedge magnitude must be reported. If finite-amplitude projection differs from linear surrogate, retain discrepancy. Native subagents NOT_RUN (no dispatch tool).',
  'Self-review: paired residual equality is not error bound on true delta; PCHIP source shape is a sensitivity check, not proof of converged sign. Preserve original accepted prefix and linear fallback near switch; compare high-ray pair at same grids. Lyman crossing count is collisionless diagnostic from a reconstructed occupation; no repeated use or insertion into native virtual history. p=1-exp(-tau) models absorption without reemission, not Sobolev escape probability. Native subagents NOT_RUN.',
  'Self-review: composition changes may require ionization heat, photon reservoir and recombination radiation, so a DeltaB-funded experiment only tests energy accounting. Calibration may depend on legacy effective CMB midpoint and FF birth. Do not present calibrated Q_ext as predictive reaction model. Frequency cutoff must be nested and compare photon number as well as energy. Native subagents NOT_RUN.'])

