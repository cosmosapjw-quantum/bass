# CE1-AB reproducibility / provenance

Parent Git HEAD exact `bc06cb2fc3952477b437891d8b04650f8f164b40`; original PR275 `research/ce1aa_20261030` must exist beside this directory in the GitHub branch. The standalone ZIP supplies exactly the original 99/99-member CE1-AA source under `ce1aa_input/` and checksums. Runtime: Python 3.11+, NumPy 2.3.5, SciPy 1.17.0, pytest 9+, Linux libmpfr.so.6 with directed rounding.

From the folder containing `replay_dop853.py`, execute:

```bash
python replay_dop853.py
python mpfr_defect.py --n 6 --divisions 32
python mpfr_defect.py --n 8 --divisions 32
python mpfr_angular_transport.py --n 6 --divisions 32
python mpfr_angular_transport.py --n 8 --divisions 32
python -m pytest -q tests/test_ce1ab.py
python -m compileall -q replay_dop853.py mpfr_defect.py mpfr_angular_transport.py tests/test_ce1ab.py
```

The 41x6 binary64 frozen comparison is exact, and all raw dense-output DOP853 F matrices are serialized as exact binary64 hex; the 192-bit interval calculation evaluates **the stored hex interpreted as exact rational input**. MPFR results are outward binary64 result bounds (not high precision printed digits). Test original source binary64 hashes and compare against `SOURCE_IDENTITY.json` before using any old theorem. Do not treat the source's `rtol=3e-12` as a rigorous integrator certificate; this unit's defect computation is essential.

`R6_DISTINCT_AUTHOR=NOT_RUN`, `C9_DISTINCT_AUTHOR=NOT_RUN` and full formal C proof NOT_RUN. No reproduction of old costly angular moment proof is needed. The second eigemode is the 41-sample time Gram, not an integral-operator λ2 lower bound. STOP_AFTER_ONE_BOUNDED_UNIT=true.
