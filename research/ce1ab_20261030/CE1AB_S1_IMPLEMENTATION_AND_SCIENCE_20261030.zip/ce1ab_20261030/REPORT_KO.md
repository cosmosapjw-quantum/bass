# BASS CE1-AB | 연속 시공간 원래 rank2 인증 결과 (2026-10-30)

원래 사용자가 고정한 양의 six-cell massless collisionless diagonal Bianchi I, Λ=0, (-,+,+,+), u∈[0,.08], shear(.2,-.13,-.07), source SHA와 h target는 변경하지 않았다. 원래 PR275 exact stored geometry 41개만으로 남았던 conditional source 인증을 DOP853 exact GL IVP·원래 continuum geometry error bridge로 확장했다.

## 물리 결과

| 검증량 | GL6 | GL8 |
|:--|--:|--:|
| 원본 41×6 binary64 재생 | 246/246 | 246/246 |
| DOP853 적응 스텝 | 3 | 3 |
| MPFR192 최대 결함 | 1.2750354589096e-05 | 1.27504312813282e-05 |
| 연속 GL ODE 전구간 ∞ 오차 | 1.71247512750963e-06 | 1.71248542784402e-06 |
| 저장 상태와 exact dense polynomial 오차 | 5.86708403661638e-17 | 5.50887106902763e-17 |
| 원래 연속 시공간 vs 저장 기하학 ∞ 오차 | 1.71247567502697e-06 | 1.71248543921501e-06 |
| angular X Frobenius 이동 | 5.7761807820414e-06 | 5.77621599367996e-06 |
| Gram Weyl 이동 상계 | 7.69629883632649e-06 | 7.69634575781094e-06 |
| **원래 exact continuum 41-epoch λ2 엄격 하계** | > 0.0000244225376510682458938785229543 | > 0.0000299648944830831102428389508014 |

## 정확한 해석

물리적으로 새로 얻은 결과는 41개 **정확한 원래 binary64 적분 시점**에서 원본 continuum angular sky의 3열 Gram 행렬 두 번째 고유값이 양수임을 엄격하게 하계로 증명한 것이다. 이는 positivity/smoothness와 함께 continuous-time deterministic K4delta kernel rank≥2를 함의하지만, 시간 적분연산자의 λ2 고유값 수치 하계는 주지 않는다. 세 번째 모드, 원시 CMB 온도·분극, 관측 Likelihood 및 일반 Bianchi 해석을 추가로 주장하지 않는다.

기존 PR264 exact-ODE vs exact-ODE source geometry theorem, PR270 uniform source-only K4 theorem, PR275 MPFR192 stored input source-only λ2는 **재사용**하였다. 이번 CE1-AB는 original continuous Einstein–Vlasov IVP의 DOP853 trajectory defect와 angular Jacobian transport가 신규이다. PR273의 별도 RK4/Hermite 결과는 병합하지 않았다.

## 실행과 검증 범위

- DOP853 3 adaptive segments × 32 interval slabs × GL6/8 = 192 MPFR192 residual slabs. 82 new angular Jacobian epoch records.
- SciPy 1.17.0·NumPy 2.3.5로 원래 binary64 41×6 상태 각 GL 246/246 동등. 재생 step coefficients는 원본 archival binary와 동일하다고 주장하지 않는다.
- MPFR192 RNDD/RNDU interval residual, pressure Jacobian, initial mismatch, knot jump 및 Grönwall 계산. 별도 numpy finite-difference source/Jacobian 대조.
- 새 scope pytest 12/12 PASS. 기존 PR275 원래 CI는 inherited; 새 GitHub CI는 게시 후 별도로 확인해야 한다.
- 증명 이식은 PR264/PR270/PR275 기존 원본 정리와 libmpfr ctypes 외연 연산 구현의 정확성에 **조건부**다. 독립 distinct-author R6/C9, native subagent, formally verified whole-program MPFR는 NOT_RUN.

## DAG / 결론

`UPPER_DAG=9/15`, `UPPER_EDGES=21`, `CE1=PARTIAL`, `SCOPED_R_C=18/20`, `R6=C9=NOT_RUN`, `PRODUCTION_READY=false`, `MERGE_READY=false`, `AUTO_NEXT=false`.

원래 h<1e-5 통과. 원래 source SHA·PR275·PR273 유지. **ONE BOUNDED UNIT 종료**.

완전한 원전 재현용 수식과 근거는 `CE1AB_DERIVATION_KO.md`, 계산식 구현은 `replay_dop853.py`, `mpfr_defect.py`, `mpfr_angular_transport.py`, 결과 raw `results/`를 참조.
