from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4i_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4i_bass.py','haar.py':'r118c4i_haar.py'},'REC':{'rec.py':'r118c4i_rec.py','feedback.py':'r118c4i_feedback.py'},'REI':{'rei.py':'r118c4i_rei.py','transport_patch.rs.txt':'r118c4i_transport_patch.rs.txt','stage_patch.rs.txt':'r118c4i_stage_patch.rs.txt','clock.py':'r118c4i_clock.py'}}
notes={'BASS':['Exact C3X nonlinear owner and C4H DD companion on same time grid; prior native output replay; independent deterministic MIS.','Pinned archived original sources, actual radial tables and clock, same C4F robust control; old binary/reference identities.','Sidecar advances inside actual native step loop with actual ne0/nem, independent radial tables; balance heuristic with pilot-only allocation.','Two time grids, 14 signed/zero cases and one archived replay, 4 workers; independent MIS pilots and 4 eval replicates per target.'],'REC':['Actual C4H scalar weak-history owner, same stored history, all 5 receiving moments; independent HI abundance-opacity feedback.','Native affine JumpResponse and original 3-stage gas, weak reconstruction; published HeI profile and source HeII actual rates.','Exact event-split scalar delay map transpose, implicit 2D gas and 3 outgoing weak moments; scalar inactive limiter, separate active LP audit.','Actual baseline plus signed initial-x scalar replay and dot/adjoint test; 3 spectral grids and matched no source.'],'REI':['Actual C4F shadow plus exact C4H implicit diagnostic, analytic prepared radiation derivatives; independent physical early clock CF4.','Native prepared old/birth node factors and source amplitude, same accepted chemical stage; actual C4H J.','Stable analytic phi/psi derivative, species events and heat. Compose J^-1 rate derivative and compare independent residual; CF4 chronological right early-weighted exponential, left late-weighted exponential.','Two isolated native base replays, 6 actual chemical stages, same owner and acceptance; actual early tau, 5 time levels, knot split and refined reference.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4i_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Scoped runnable source and actual Python syntax check. Build and scientific execution follow.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'haar.py',[],'haar',480);r=job('bass.py',['build'],'build_driver',480);rr=[r]
   if r.get('exit')==0:rr.append(job('bass.py',['native'],'native',900))
   rr.append(f.result())
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'feedback.py',[],'feedback',300);r=job('rec.py',[],'weak',600);rr=[r,f.result()]
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'clock.py',[],'clock',480);r=job('rei.py',['build'],'build_driver',480);rr=[r]
   if r.get('exit')==0:
    r=job('rei.py',['native'],'native',650);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['analyze'],'analysis',90))
   rr.append(f.result())
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n');print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual build/run exits and evidence; failed runs retained: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a,b=j('COUPLED_NATIVE_JET.json'),j('MIS.json');record(k,'C7','Synchronized actual nonlinear native example and DD coefficient companion: '+json.dumps(a));record(k,'C8','Pilot-selected deterministic mixture estimator: '+json.dumps(b));ok=a is not None and b is not None
  next_='Differentiate actual nonlinear matter/geometry and native streaming operators; extend direct coefficient to higher orders and general Lie types. Validate adaptive MIS against independent multi-scramble reference.'
 elif k=='REC':
  a,b=j('WEAK_ADJOINT.json'),j('HI_FEEDBACK.json');record(k,'C7','Actual scalar weak-history tangent, reverse adjoint, nonlinear replay and active limiter diagnostic: '+json.dumps(a));record(k,'C8','Actual HeI source with ground-state H detailed-balance conditional feedback: '+json.dumps(b));ok=a is not None and b is not None
  next_='Extend exact weak-history derivative to signed ray transport, active LP reconstruction and event motion; couple helium and excited-level H, radiation recycling and thermal balance.'
 else:
  a,b,c=map(j,['NATIVE_RUNS.json','TRANSPORT_JACOBIAN.json','CLOCK_CF4.json']);record(k,'C7','Actual prepared radiation Jacobian composed with implicit gas stage: '+json.dumps(dict(native=a,transport=b)));record(k,'C8','Actual optical-depth clock higher-order time integration: '+json.dumps(c));ok=a is not None and b is not None and c is not None
  next_='Differentiate prepared reconstruction, geometry and source shape, propagate full composite native discrete Jacobian; use CF4 with source knot and time-error control.'
 record(k,'C9','Actual scope and failure classification: '+json.dumps(rows)+'; no full production regression or general coupled derivative promotion.')
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4I',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

