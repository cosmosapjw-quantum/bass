from pathlib import Path
import subprocess,os,json,hashlib,concurrent.futures
H=Path.home()
repos={
'BASS':(H/'worktrees/bass-r109-native-20261124','research/r118c3i_temporal_rank','216500e84e4757850eaf0bbadf431e5598e8c234','research/r109-native-nonlinear-sky-20261124'),
'REC':(H/'Downloads/htt_r109_original_rec','research/r118c3i_event_quadrature','e259b9eebe280c6f2f3316d81f2bfa24deed9206','research/r109-finite-tilt-ray-thomson-20261124'),
'REI':(H/'worktrees/rei-htt-thomson-20261124','research/r118c3i_event_ledger','55ce4eed5ba5c89fb8bfb6ce8de069e60daf1083','research/htt-tilted-thomson-20261124')}
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
receipt=H/'r118c3i_push_receipts_20261126.jsonl'
def git(r,*args):
 p=subprocess.run(['git','-C',str(r),*args],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{r.name}: {args}: {p.stdout}')
 return p.stdout.strip()
def folder(k):r,d,_,_=repos[k];return r/d
def write(k,name,content):
 p=folder(k)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content.rstrip()+'\n' if isinstance(content,str) else json.dumps(content,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def publish(k,stage,extra=()):
 r,d,base,branch=repos[k];assert git(r,'branch','--show-current')==branch
 assert not git(r,'diff','--cached','--name-only')
 git(r,'add',*(['--sparse'] if k=='REI' else []),'--',d,*extra)
 git(r,'diff','--cached','--check')
 staged=git(r,'diff','--cached','--name-only').splitlines();assert staged and all(x.startswith(d+'/') or x in extra for x in staged),staged
 git(r,'commit','-m',f'R118-C3I {stage}: {k} science')
 head=git(r,'rev-parse','HEAD');git(r,'push','origin',f'HEAD:refs/heads/{branch}')
 remote=git(r,'ls-remote','--heads','origin',f'refs/heads/{branch}').split()[0];assert remote==head
 return dict(stage=stage,repo=k,head=head,remote=remote,tree=git(r,'rev-parse','HEAD^{tree}'),paths=staged)
def batch(stage,extras=None):
 done={(v['stage'],v['repo']) for v in map(json.loads,receipt.read_text().splitlines())} if receipt.exists() else set()
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(publish,k,stage,(extras or {}).get(k,())):k for k in repos if (stage,k) not in done};errs=[]
  for f in concurrent.futures.as_completed(fut):
   try:
    row=f.result();print('PUSH',row['stage'],row['repo'],row['head'],flush=True)
    with receipt.open('a') as h:h.write(json.dumps(row)+'\n')
   except Exception as e:print('ERROR',fut[f],stage,repr(e),flush=True);errs.append(e)
  if errs:raise RuntimeError('publication incomplete')
def note(stage,content):
 for k,t in zip(repos,content):write(k,stage+'.md','# '+stage+' | R118-C3I '+k+'\n\n'+t)
 batch(stage)
if __name__=='__main__':
 for k,(r,d,b,br) in repos.items():
  assert git(r,'rev-parse','HEAD')==b and git(r,'branch','--show-current')==br
  assert git(r,'ls-remote','--heads','origin',f'refs/heads/{br}').split()[0]==b
  assert not (r/d).exists()
 note('R1',[
 'Base C3H 216500e. Main: derive first-order mass-dependent collisionless response and evaluate temporal skew rank independently of finite-amplitude near cancellation. Compare signed native controls at baseline and dispersed masses. Independent: isolate cubic/even magnetic vector alignment with exact signed amplitude decomposition; determine whether mixed quadratic/cubic signals are observationally collinear. Bianchi I, represented Fermi-Dirac species, fixed C3F scalar donor; no production promotion.',
 'Base C3H e259b9e. Main: identify the finite accepted-prefix turn-on in causal incoming interpolation, derive exact retarded crossing times and add jump-integral correction to trapezoidal shared gas without rewriting endpoint history. Compare matched angular on/off at multiple resolutions. Independent: paired 1s/2p spontaneous, stimulated and absorption with exact Planck equilibrium; compare signed net escape to native Ly-alpha expression on actual atom solves. No full donor/HHe.',
 'Base C3H 55ce4eed. Main: instrument existing native accepted BASS/REI bridge to expose primary source, absorption, cooling, event and expansion ledgers, then use native source-owned transfers (not thermal-history-calibrated forcing) in spectral gas trial. Independent: extend reflecting-grid low-frequency free-free relaxation inside Gaunt table validity, distinguish number and energy and detailed balance. No change to V11 production or autonomous chemistry claim.'])
 note('R2',[
 'de Vega & Sanchez, https://arxiv.org/abs/1111.0290, Volterra B-V for Fourier modes; useful distinction of mass-dependent response, not homogeneous Bianchi theorem. Native owned_vlasov.rs matter_impl, with_species and radiation_feedback::advance_mixture are actual authority. C3H memory response is retained only with same normalization.',
 'Eremin, Humphries & Lobaskin (2020), https://scispace.com/papers/some-issues-with-the-numerical-treatment-of-delay-2vu0ql73o8 : derivative discontinuities and DDE step control. Hale (2024), https://scispace.com/papers/a-spectral-collocation-method-for-functional-and-delay-1vdvokvz5kb7 : piecewise spectral collocation for delay equations. Source-specific discontinuity is established by reading native C3H sampler, not inferred from these papers. Original Oct2012 HyRec rates remain pinned.',
 'Modeling cosmic reionization (2022), https://link.springer.com/article/10.1007/s41115-022-00015-5 eqs 6–7: varying particle number and photoheating excess above threshold; MNRAS 460 1885 (2016), https://academic.oup.com/mnras/article-abstract/460/2/1885/2609103 gas cooling and ionization thermal evolution. Native igm_thermal.rs cooling_channels includes binding energy for RR and DR, FF gross separately. Native axbi_covariant_driver Ledgers owns source, photon and thermal work. C3H energy model supplies signed spectral coupling.'])
 note('R3',[
 'Native mass m/T0, radial Gauss-Legendre y on [0,60], isotropic weight y^2 f(y); f=1/(1+exp y). Physical momentum q in temperature units, e=sqrt(y^2+(a m/T0)^2). Coframe F=I+beta; v=F^-T q. Shear S=d beta/du at linear order. Native S prime=(qdec-2)S+3 Pi/H^2. Background h^2=rho+OmegaLambda; density perturbation vanishes at first STF order. Reuse C3H spin projector, signed source and ne(a).',
 'C3H retarded.py uses conserved p=n@Fref and source time t; sampler before initial history returns exactly 0; at first accepted knot, outgoing distortion is nonzero (max ~7.37e-15). Prefix switch is continuous piecewise interpolation, not same jump. C3H matched delta changed sign despite tiny algebraic residual. Source edges 313, original native Ly rate LYA_FACT_CM3 H/(nH*x1s), incoming line weighted by direction expansion.',
 'Native DriverState Ledgers includes cumulative source_u, photon_work, thermal_work, escaped_u, cmb_input, RR/CI/photo/DR counts. Bridge writes J0 physical primary energy, w,B, escape,cmb,source,work but not separate photon work. Instrument accepted rows only; full/two-half speculative trials not counted. Native geometry_map is adiabatic at fixed fractions; chemistry stage books energy in own ledger. Original run table had 479 accepted steps and 28.2s wall.'])
 note('R4',[
 'Routes: direct linear radial integral and coupled scalar ODE; signed native single-axis finite differences; alternative mass vectors and normalized skew block spectra. Optimize only after rank robust to radial/time refinement. Independent cubic study compares signed complex coefficient vectors with invariant real/complex inner product and normalized correlation, not raw norms alone.',
 'Routes: (a) event-aware quadrature of initial-prefix jump, (b) explicit event subdivision impractical for many rays, (c) smooth-before-start extension as sensitivity only, would change native history. Select (a), preserving discontinuity and endpoints. Independent Einstein rates with Sobolev screen at each original accepted atom state; compare stable net to native expression; no extra feedback.',
 'Routes: (a) exact accepted native event ledger and absorption from source+primary stock+work, (b) final checkpoint totals independent audit, (c) external calibrated C3H baseline retained separately. Source-owned non-spectral input Q_other=primary absorbed energy minus RR/DR/CE emitted energy; explicit channels retained. Low-frequency FF exact relaxation tau, source occupation positive, Planck equilibrium and common log spacing.'])
 note('R5',[
 'Derived: angular STF averages <n_i n_j n_k n_l> Q_kl=2Q_ij/15. For f(y exp(-n J n)), delta f=-y f_prime n J n. Initial anisotropic stress coefficient A=(2/15) integral y^5 f(1-f)/e dy. Metric perturbation v=(I-beta)q gives coefficient D=integral y^2 f[(2/3)y^2/e-(2/15)y^4/e^3]dy. Integration by parts A=D (boundary y^5 f/e zero at 0 and infinity), so Pi_m=a^-4 ON*w/norm D_m*(J_m-beta). For finite cutoff 60 boundary is -2 y^5 f/(15e), explicitly check. Photon Pi_gamma=(2/15)rho_gamma A_gamma using brightness quadrupole convention; A_gamma prime=-4S-K(.9 A+.4 P), P prime=-K(.15 A+.4P). Thus scalar S,beta,A,P for initial S and each J; memory skew W_ij prime=S_i P_j-S_j P_i-K W_ij, with fixed scalar background. Conditional first-order approximation, exact angular integration. Independent: even/odd B vector projected onto each other using real inner product (complex harmonics encode real sky); orthogonal residual distinguishes shapes.',
 'Derived: E(u,q)=q r(u) exp(-u), r=||F^-T p||. For source knot us, face arrival satisfies u_f-log r(u_f)=us-log r(us)+log(Esource/Eface). Monotonic branch gives unique crossing. For step [l,r], trapezoid integral of a jump J at t_e overestimates/underestimates by h*(1/2-(t_e-l)/h) J; add correction. Because fixed x,T,rates make atomic linear solve affine in incoming distortion, use aggregated per-ray/channel correction before weighted solve; evaluate at endpoint candidate, retain physical uncorrected outgoing only. Exact jump integration for constant gain, approximation for varying gain. Einstein exact net emission A21[(delta x2p)(1+f)-3 x1(1-e^-E/kT)delta f], with x2p=3x1 exp(-E/kT)+delta x2p; equilibrium exact. Compare escape-weighted net to native R_Ly(delta x2p-3x1 delta f); Wien limit. Gross pair counted once, signed correction only diagnostic.',
 'Derived from source-owned native identity: Delta U_primary + Delta W_primary - Delta source = -E_abs (boundary term included if nonzero). Q_other=E_abs - sum Delta cooling[0:7]; RR/DR already contain binding (do not debit it twice). Replace both legacy CMB and FF with same-grid spectral signed Q_rad; state equation Delta(w+B)+W_g=Q_other-Q_rad. Primary source independent of thermal endpoint, but transfer/count history prescribed from accepted source; explicit gas trial not autonomous. Event species checks: HII delta = photo_H+CI_H-RR_H; HeII delta/Y = photo_HeI+CI_HeI-RR_HeI-DR -photo_HeII-CI_HeII+RR_HeII; HeIII analog. At low x, exact FF update delta n=(n_eq-n_old)(1-exp(-tau)); number, energy integrals and equilibrium separately, cutoff floor set by Gaunt u=E/kT validity.'])
 note('R6',[
 'Self-review: derivative of density zero at linear STF; finite quadrature residual and finite y cutoff independently test. Need distinguish temporal Gram rank from skew rank: independent modes can still give near-rank-two antisymmetric response. Signed probes isolate odd first-order with O(eps^2) error, native time step and harmonic angular resolution differ from radial oracle. Do not claim universal no-go. Native subagents NOT_RUN.',
 'Self-review: event correction sign checked against scalar step jump; event exactly left included, right handled in integral; root solver must not mutate history using corrected surrogate outgoing. Correction is first approximation to coefficient variation; measure residuals and angular quadrature. Prefix source switch discontinuity not same as initial jump; unresolved if other mechanisms remain. Independent line transfer uses net signed rates, physical 2p reconstructed and Planck stimulated balance; no direct injection into native virtual bins. Native subagents NOT_RUN.',
 'Self-review: use actual accepted primary work, not aggregate bridge work, and cumulative counts differencing; ensure matching a grid and old source identity before reusing earlier spectral data. Q_other algebra does not derive from thermal endpoints; verify native balances from source/stock independently. Adiabatic midpoint splitting means previous w_ad formula is approximation across reaction stage; test closure and difference from native. Do not include legacy CMB heat again. Low-frequency table bounds enforced; zero-frequency continuum not claimed. Native subagents NOT_RUN.'])

