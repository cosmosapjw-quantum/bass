"""Final scoped evidence and safe cleanup for R118-C3Y; no branch/history rewrite."""
from pathlib import Path
import hashlib, json, subprocess, tarfile, sys
import numpy as np
H=Path.home()
sys.path.insert(0,str(H))
from r118c3y_theory_driver_20261127 import repos,scopes,push,git
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(p,ref,path):return subprocess.check_output(['git','-C',str(p),'show',f'{ref}:{path}'])
def receipts(k):return [json.loads(x) for x in (H/f'r118c3y_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
required={f'{s}{i}' for s in 'RC' for i in range(1,11)}
def verify(k):
 p=repos[k];rows=receipts(k);assert required <= {r['stage'] for r in rows};assert all(r['head']==r['remote'] for r in rows)
 h=git(p,'rev-parse','HEAD');b=git(p,'branch','--show-current');r=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0];assert h==r==rows[-1]['head']
 return dict(branch=b,head=h,tree=git(p,'rev-parse','HEAD^{tree}'),remote=r,receipts=len(rows),theory_and_coding_receipts=len(required))
before={k:verify(k) for k in repos}
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC']
assert (B/'RESULT.json').is_file()
runs=json.loads((B/'NATIVE_RUNS.json').read_text())
assert len(runs['jobs'])==8 and not runs['failures'] and all(j['returncode']==0 for j in runs['jobs'])
# Source staging copies are protected in their exact historical C5 commits.
delete=[]
for k,name in [('BASS','signed.py'),('REC','arrival_pair.py'),('REI','material.py')]:
 p=H/f'r118c3y_{name}'
 if not p.exists():continue
 rev=next(r['head'] for r in receipts(k) if r['stage']=='C5')
 content=blob(repos[k],rev,scopes[k]+'/'+name)
 assert p.read_bytes()==content, (p,'staging content differs from C5')
 assert subprocess.run(['git','-C',str(repos[k]),'merge-base','--is-ancestor',rev,before[k]['head']]).returncode==0
 delete.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(content),recovery=f'{k}:{rev}:{scopes[k]}/{name}',identity='byte'))
# Preserve executable orchestration before removing local staging copies.
drivers=[H/f'r118c3y_{n}_20261127.py' for n in ['theory_driver','coding_driver','repair','closeout']]
arc=B/'C3Y_DRIVERS.tar.gz'
with tarfile.open(arc,'w:gz') as f:
 for p in drivers:f.add(p,arcname=p.name)
with tarfile.open(arc,'r:gz') as f:
 for p in drivers:
  assert f.extractfile(p.name).read()==p.read_bytes()
  delete.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()),recovery='BASS:'+scopes['BASS']+'/C3Y_DRIVERS.tar.gz:'+p.name,identity='byte'))
# Replay data may be removed only if equivalent to already pushed baseline artifacts.
for lam in ['-0.5','0.5']:
 cert=R/f'FINAL_POS_{lam}.json'
 if not cert.exists():continue
 q=json.loads(cert.read_text());assert q['trajectory_bitwise_equal'] and q['last_signed_bitwise_equal']
 for ext in ['npz','json']:
  p=R/f'cert_pair_32_{lam}.{ext}';ref=R/f'pair_32_{lam}.{ext}'
  if not p.exists():continue
  assert blob(repos['REC'],before['REC']['head'],scopes['REC']+'/'+ref.name)==ref.read_bytes()
  if ext=='npz':
   with np.load(p) as a,np.load(ref) as b:assert set(a.files)==set(b.files) and all(np.array_equal(a[x],b[x]) for x in a.files)
  else:assert json.loads(p.read_text())==json.loads(ref.read_text())
  delete.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()),recovery='REC:'+before['REC']['head']+':'+scopes['REC']+'/'+ref.name,identity='semantic arrays/JSON'))
# Never remove active or unrelated worktrees; inspect and prune only metadata with default expiry.
worktrees={}
for k,p in repos.items():
 dry=git(p,'worktree','prune','--dry-run','--verbose')
 worktrees[k]=dict(list=git(p,'worktree','list','--porcelain'),prune_dry_run=dry,prune_performed=False,active_preserved=True)
 if not dry:
  git(p,'worktree','prune','--verbose')
  worktrees[k]['prune_performed']=True
(B/'AUXILIARY_EVIDENCE.md').write_text("""# C3Y auxiliary checks and observational route

Wolfram Language independent symbolic check (first expression failed due to 0^0 in polynomial evaluation; explicitly separated constant term and reran successfully): even = c2 + e^2 c4 + e^4 c6; odd = c1 + e^2 c3 + e^4 c5 + e^6 c7; quadratic Lagrange weights sum to 1; two-time covariance determinant v*w for [[v,z v],[z v,z^2 v+w]]. SymPy R7 checks retained.

Exa and Parallel both found Planck Collaboration V 2020, section 2.3, https://www.aanda.org/articles/aa/full_html/2020/09/aa36386-19/aa36386-19.html . LFI lowTEB/bflike is pixel-based and can be adapted to deterministic non-rotationally invariant sky means. Official likelihood description: https://wiki.cosmos.esa.int/planck-legacy-archive/index.php/CMB_spectrum_%26_Likelihood_Code . Distinct from baseline SimAll power-spectrum EE likelihood. No file acquisition, mask/beam/noise verification or observed likelihood result. No alteration of Commander-only analysis scope.
""")
(B/'OPS_PRE_CLEANUP.json').write_text(json.dumps(dict(cycle='R118-C3Y',verified_before=before,archive_sha256=sha(arc.read_bytes()),files_to_remove=delete,worktrees=worktrees),indent=2)+'\n')
push('BASS','ops-archive-before-cleanup',['C3Y_DRIVERS.tar.gz','AUXILIARY_EVIDENCE.md','OPS_PRE_CLEANUP.json'])
removed=[]
for x in delete:
 p=Path(x['path'])
 if p.exists():
  assert sha(p.read_bytes())==x['sha256']
  p.unlink();removed.append(x)
for p in [q for n in ['theory_driver','coding_driver','repair','closeout'] for q in (H/'__pycache__').glob(f'r118c3y_{n}_20261127.*.pyc')]:
 if p.is_file():
  x=dict(path=str(p),bytes=p.stat().st_size,identity='generated bytecode')
  p.unlink();removed.append(x)
# Record actual post-cleanup status; no force cleanup.
result=dict(cycle='R118-C3Y',removed=removed,bytes_removed=sum(x['bytes'] for x in removed),worktrees=worktrees,scope_status={k:git(p,'status','--short','--',scopes[k]) for k,p in repos.items()},unrelated_status={k:git(p,'status','--short') for k,p in repos.items()})
(B/'OPS_CLEANUP_RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
push('BASS','ops-cleanup-receipt',['OPS_CLEANUP_RESULT.json'])
final={k:verify(k) for k in repos}
allrows=[r for k in repos for r in receipts(k)]
(H/'r118c3y_push_receipts_20261127.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in allrows))
(H/'r118c3y_final_receipt_20261127.json').write_text(json.dumps(dict(cycle='R118-C3Y',verified_final=final,total_receipts=len(allrows),cleanup=result,science='bounded research evidence only; not full production regression'),indent=2)+'\n')
print(json.dumps(dict(final=final,total_receipts=len(allrows),removed_files=len(removed),removed_bytes=result['bytes_removed'],scoped_status={k:git(p,'status','--short','--',scopes[k]) for k,p in repos.items()},unrelated_status={k:git(p,'status','--short') for k,p in repos.items()}),indent=2),flush=True)
