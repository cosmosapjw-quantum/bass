from pathlib import Path
import sys,json,time,os,subprocess,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H))
from r118c3y_theory_driver_20261127 import repos,scopes,push,git
def do(k):
 D=repos[k]/scopes[k];receipt=H/f'r118c3y_{k.lower()}_push_receipts.jsonl'
 for _ in range(20):
  if len(receipt.read_text().splitlines())>=20:break
  time.sleep(2)
 else:raise RuntimeError(f'{k} original stage driver still active')
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 if k=='REI':
  p=D/'material.py';s=p.read_text();old='+[u[-1]])';new='+[u[-1:]])';assert s.count(old)==1;p.write_text(s.replace(old,new))
  push(k,'C6-repair-source',['material.py'])
  cmd=[sys.executable,'-u','-c','import sys,json;from pathlib import Path;sys.path.insert(0,sys.argv[1]);import material; o=material.ou(); (Path(sys.argv[1])/"OU_TWO_TIME.json").write_text(json.dumps(o,indent=2)+"\\n");print(o)',str(D)]
  with (D/'ou_repair.log').open('w') as f:q=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  rows=[dict(tag='ou_repair',exit=q.returncode)]
  files=['ou_repair.log']
  if (D/'OU_TWO_TIME.json').exists():files+=['OU_TWO_TIME.json']
 else:
  p=D/'arrival_pair.py';s=p.read_text();old='sys.path.insert(0,str(X));sys.path.insert(0,str(W))';new='sys.path.insert(0,str(D.parents[1]/"src"));'+old;assert s.count(old)==1;p.write_text(s.replace(old,new))
  push(k,'C6-repair-source',['arrival_pair.py'])
  def job(args,tag,timeout):
   f=D/(tag+'_repair.log')
   try:
    with f.open('w') as o:q=subprocess.run([sys.executable,'-u',str(p),*args],cwd=str(repos[k]),env=env,stdout=o,stderr=subprocess.STDOUT,timeout=timeout)
    r=dict(tag=tag,exit=q.returncode)
   except Exception as e:r=dict(tag=tag,exception=repr(e))
   print(k,r,flush=True);return r
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,['diag','32'],'diag32',120);r=job(['scalar','32'],'scalar32',180);rows=[r,f.result()]
  if rows[0].get('exit')==0:
   with cf.ThreadPoolExecutor(max_workers=2) as ex:rows.extend(ex.map(lambda lam:job(['pair','32',str(lam)],f'pair32_{lam:g}',300),[-.5,.5]))
  with cf.ThreadPoolExecutor(max_workers=2) as ex:rows.extend(ex.map(lambda n:job(['diag',str(n)],f'diag{n}',120),[64,128]))
  files=[p.name for p in D.iterdir() if p.is_file() and (p.name.endswith('_repair.log') or p.name.startswith(('m3_','pair_','DECOUPLE_')))]
 (D/'REPAIR_EXECUTION.json').write_text(json.dumps(rows,indent=2)+'\n')
 files+=['REPAIR_EXECUTION.json'];ok=all(r.get('exit')==0 for r in rows)
 push(k,'C6-repair-results',files)
 # Actual evidence classification; earlier failures preserved as historical receipts.
 dag=json.loads((D/'DAG.json').read_text());dag['repair_execution']=rows;dag['status']='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL';dag['repair_receipts']=[json.loads(x) for x in receipt.read_text().splitlines() if 'repair' in json.loads(x)['stage']]
 if k=='REI':
  a=json.loads((D/'MATERIAL.json').read_text());o=json.loads((D/'OU_TWO_TIME.json').read_text()) if (D/'OU_TWO_TIME.json').exists() else None
  report=dict(material_rows=[{k:v for k,v in t.items() if k!='FD'} for t in a],ou=o)
 else:
  pairs={}
  for lam in [-.5,.5]:
   p=D/f'pair_32_{lam:g}.json'
   if p.exists():pairs[str(lam)]=json.loads(p.read_text())
  diag={}
  for n in [32,64,128]:
   p=D/f'DECOUPLE_{n}.json'
   if p.exists():
    rr=json.loads(p.read_text())['rows'];diag[str(n)]=dict(cells=len(rr),max_GL5_9=max(v['GL5_9_relative'] for v in rr),max_partition=max(v['partition_relative'] for v in rr),max_interp_delta=max(abs(sum(v['quadratic'][:4])-sum(v['lin'][:4])) for v in rr),max_event_subset=max(abs(v['quadratic'][4]) for v in rr))
  report=dict(pairs=pairs,diagnostics=diag)
 (D/'REPAIR_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n')
 (D/'C10_REPAIR.md').write_text('# C10 repair closeout\n\nActual repaired execution: '+json.dumps(rows)+'\n\nScience evidence: REPAIR_VALIDATION.json. Earlier C6 failure receipts preserved. Full production or unresolved scientific target not promoted.\n')
 push(k,'C10-repair-closeout',['REPAIR_VALIDATION.json','DAG.json','C10_REPAIR.md'])
 print(k,'REPAIR_COMPLETE',json.dumps(report)[:2500],flush=True)
with cf.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(do,['REC','REI']))

