from pathlib import Path
import sys,subprocess,json,concurrent.futures as cf,os,shutil
H=Path.home();sys.path.insert(0,str(H))
from r118c3y_theory_driver_20261127 import repos,scopes,push,git
notes={"BASS":["Baseline C3X native binary SHA, actual signed controls and measured zero at each required mesh; exact B2 null is not acceptance from numerical floor.","Map C3W c3w_radial executable, C3L clock.csv and C3U selected controls to signed coefficient CSV epoch=1 ell=3,5,7. New executable unchanged; hash asserted.","Use scaled Vandermonde, unrestricted odd cubic (B1 included), constrained comparator and fixed-axis zero. Time 16384 at a single amplitude is a vector convergence diagnostic, not a full higher-order coefficient extrapolation.","Eight native jobs limited to two concurrent processes, actual previously available data reused. Native binary timeout 240 seconds/job, capture failures. Independent full-sky actual template rank."],"REC":["Baseline C3X nt32 same three-moment exact scalar reference, direct signed runs. Frozen diagnostic C3W 32/64/128 scalar history is separate, fixed H.","Use C3X Map.mom3, reconstruct, C3W common_pair thermal_diff and C3N JumpResponse. Recover full scalar A by exact replay; positivity applied to total field.","Stable pair separately evolves delta x,T and delta outgoing history, computes three weak moments from same endpoint-affine operator and corrects only P3..6 via total positivity. Diagnostic quadratic operator uses moments through order4 with GL9 vs GL5.","Execute scalar32 first then +/-0.5 pair, two processes; actual frozen C3W selected cells at 32,64,128 with operator/arrival decomposition. Independent native affine virtual/real partition. Stop on failure, preserve evidence."],"REI":["Baseline PR378 native source and C3X actual accepted F, rho/P and DG stock. Actual native represented massive quadrature reconstructed separately from harmonic and chemistry.","Read exact Git blobs; OwnedModel::new/ matter_impl and ThomsonOwner::matter, constants, quadrature and STF basis. Verify initial aggregate native matter and pressure; no hidden harmonic derivative.","For left generator A, A'=delta S+[S,A], delta P from same represented quadrature. Induced remainder trace radiation-like only; material tangent integrates actual signed source; finite difference of exp(eps A)F. OU two-time covariance and PSD.","Three accepted C3X histories, finite perturbations at 3 snapshots, refine DOP853 tolerance; use actual C3U thermal history from Git, 17 two-time nodes. No PR378 edits; native full coupled evolution remains open."]}
codes={'BASS':'signed.py','REC':'arrival_pair.py','REI':'material.py'}
def record(k,st,body,files=[]):
 D=repos[k]/scopes[k];f=D/(st+'.md');f.write_text('# '+st+' | R118-C3Y '+k+'\n\n'+body+'\n')
 push(k,st,[f.name]+list(files))
def cpre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1])
 else:
  # Copy prepared runnable source only after all theory receipts and numerical design stages.
  shutil.copyfile(H/f'r118c3y_{codes[k]}',D/codes[k])
  subprocess.run([sys.executable,'-m','py_compile',str(D/codes[k])],check=True)
  record(k,'C5','Runnable scoped implementation syntax compiled. Scientific acceptance follows actual C6–C9 runs.',[codes[k]])
def run(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(args,tag,timeout=360):
  fn=D/(tag+'.log')
  try:
   with fn.open('w') as f:q=subprocess.run([sys.executable,'-u',str(D/codes[k]),*args],cwd=str(repos[k]),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x={'tag':tag,'exit':q.returncode}
  except Exception as e:x={'tag':tag,'exception':repr(e)}
  print(k,x,flush=True);return x
 if k=='BASS': return [job([],'native',900)]
 if k=='REI':return [job([],'material',180)]
 rows=[]
 # Source-arrival diagnostic is independent of same-reference pair.
 with cf.ThreadPoolExecutor(max_workers=2) as ex:
  f=ex.submit(job,['diag','32'],'diag32',120)
  rows.append(job(['scalar','32'],'scalar32',180));rows.append(f.result())
 if rows[0].get('exit')==0:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   rows.extend(ex.map(lambda lam:job(['pair','32',str(lam)],f'pair32_{lam:g}',300),[-.5,.5]))
 with cf.ThreadPoolExecutor(max_workers=2) as ex:
  rows.extend(ex.map(lambda n:job(['diag',str(n)],f'diag{n}',120),[64,128]))
 return rows
def collect(k,rows):
 D=repos[k]/scopes[k];(D/'EXECUTION.json').write_text(json.dumps(rows,indent=2)+'\n')
 files=[p.name for p in D.iterdir() if p.is_file() and p.name not in ['EXECUTION.json',codes[k]] and not p.name.startswith(('R','C'))]
 # Add scientific outputs beginning with uppercase R/C explicitly, excluding existing stage notes.
 for n in ['RESULT.json','REACHABILITY.json','SIGNED_COEFFICIENTS.npz','NATIVE_RUNS.json','MATERIAL.json','OU_TWO_TIME.json']:
  if (D/n).is_file() and n not in files:files.append(n)
 # Exclude stale stage R7 JSON etc; commit only new output files. Preserve logs even on failure.
 files=sorted(set(files+['EXECUTION.json']))
 record(k,'C6','Actual execution exit evidence: '+json.dumps(rows)+'. Native/full production regression not implied. Any nonzero exit retained as blocker.',files)
def summarize(k,stage):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text());ok=all(r.get('exit')==0 for r in rows)
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a=j('RESULT.json');b=j('NATIVE_RUNS.json');c=j('REACHABILITY.json')
  if stage=='C7':body='Vector parity and matched zero checks. '+(json.dumps({'fits':a['fits'],'jobs':b}) if a and b else 'Native result unavailable. Inspect native.log.')
  if stage=='C8':body='Independent time/radial/angular axes and fit window: '+(json.dumps({'axes':a['independent_axes'],'time':a['time_axis'],'joint':c}) if a else 'Not run.')
  if stage=='C9':body='Self-review: exact-null inference not allowed; constrained vs unconstrained odd fits and zero-control matching. '+('Native partial failures: '+json.dumps(b['failures']) if b else 'No native result.')+' Observation covariance and bandlimit refinement remain unresolved.'
  nxt='Continue native lmax axis with measured zero, full 16384 amplitude set if material, primary observation covariance if accessible; original all-Bianchi target unchanged.'
 elif k=='REC':
  pairs=[j(f'pair_32_{lam:g}.json') for lam in [-.5,.5]];diags=[j(f'DECOUPLE_{n}.json') for n in [32,64,128]]
  if stage=='C7':body='Same-three-moment signed comparator: '+json.dumps(pairs)+'. Diagnostics on C3W scalar reference are distinct from paired C3X run.'
  if stage=='C8':
   zz=[]
   for n,x in zip([32,64,128],diags):
    if x:
     r=x['rows'];zz.append(dict(nt=n,cells=len(r),max_GL5_9=max(v['GL5_9_relative'] for v in r),max_partition=max(v['partition_relative'] for v in r),max_abs_interpolation=sum(abs(sum(v['quadratic'][:4])-sum(v['lin'][:4]))*v['h'] for v in r),sample_event_channels=max(abs(v['quadratic'][4]) for v in r)))
   body='Selected-cell integrated diagnostics (not exhaustive continuum convergence): '+json.dumps(zz)
  if stage=='C9':body='Self-review: positivity tested on total projected polynomial; signed lower moments overwritten algebraically, possible roundoff must be bounded; output partition is signed stock, not heat. No full HHe donor, fixed-H remains. '+('All launched commands exit zero.' if ok else 'One or more command failures: '+json.dumps(rows))
  nxt='Extend same-three-moment signed pair to 64/128 or common event-aligned union; propagate higher-order native operator in actual gas integration; verify positivity of final combined coefficients and real-line physical energy rates with owner.'
 else:
  a=j('MATERIAL.json');o=j('OU_TWO_TIME.json')
  if stage=='C7':body='Native initial identity and mass-shell tangent: '+(json.dumps([{k:v for k,v in x.items() if k!='FD'} for x in a]) if a else 'Unavailable; inspect material.log.')
  if stage=='C8':body='Finite difference refinement, solver comparison, actual nonstationary two-time OU: '+(json.dumps({'FD':[x['FD'] for x in a],'OU':o}) if a else 'Not run.')
  if stage=='C9':body='Self-review: exact represented massive quadrature checked at initial total and local derivative. Remainder has conditional radiation closure, not actual harmonic or chemistry Jacobian. Preserve signed source, original AX11 and PR378 status. '+('Execution successful.' if ok else json.dumps(rows))
  nxt='Implement actual primary harmonic and H/He material response, integrate native derivative in owner, refine 4096/32 DG if feasible; preserve AX11/T2 separate.'
 if stage=='C10':
  receipt=H/f'r118c3y_{k.lower()}_push_receipts.jsonl';prior=[json.loads(x) for x in receipt.read_text().splitlines()]
  dag=dict(cycle='R118-C3Y',scope=scopes[k],prior_receipts=prior,execution=rows,status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',native_subagent='NOT_RUN',production_regression='NOT_RUN',remaining=nxt)
  (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'NEXT.md').write_text(nxt+'\n')
  # Only scoped generated bytecode, no old unrelated worktrees or backups.
  cache=D/'__pycache__';removed=[]
  if cache.is_dir():
   for p in cache.glob('*.pyc'):
    if p.is_file():removed.append(dict(path=str(p),bytes=p.stat().st_size));p.unlink()
   if not any(cache.iterdir()):cache.rmdir()
  prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
  (D/'CLEANUP.json').write_text(json.dumps(dict(removed=removed,prune_dry_run=prune,unrelated_preserved=True),indent=2)+'\n')
  body='Executed scoped cycle. Science readiness separate from push and full project. '+nxt+'; command outcomes '+json.dumps(rows)
  record(k,stage,body,['DAG.json','NEXT.md','CLEANUP.json']);return
 record(k,stage,body)
if __name__=='__main__':
 for k in repos:
  f=H/f'r118c3y_{k.lower()}_push_receipts.jsonl';assert [json.loads(x)['stage'] for x in f.read_text().splitlines()]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:cpre(k,i),repos))
 # As soon as a project finishes, publish actual execution and validation. No fake receipt if process is still running.
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  fs={ex.submit(run,k):k for k in repos}
  for f in cf.as_completed(fs):
   k=fs[f];rows=f.result();collect(k,rows)
   for st in ['C7','C8','C9','C10']:summarize(k,st)
 print('CODING_RECEIPTS_VERIFIED',flush=True)

