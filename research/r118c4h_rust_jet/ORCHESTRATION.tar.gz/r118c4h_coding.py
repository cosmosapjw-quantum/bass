from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4h_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4h_bass.py','jet.rs':'r118c4h_jet.rs','haar.py':'r118c4h_haar.py'},'REC':{'rec.py':'r118c4h_rec.py','helium.py':'r118c4h_helium.py'},'REI':{'rei.py':'r118c4h_rei.py','stage_patch.rs.txt':'r118c4h_stage_patch.rs.txt','early.py':'r118c4h_early.py'}}
notes={'BASS':['C4G discrete coefficient, native clock and C4F controls; quaternion ACG proposal on fixed 4 targets.','C4G source radial table and native generator, actual archived coefficient vectors and prior likelihood.','Rust compensated signed coefficient, exact half-stream/collision recurrence and scalar midpoint; normalized defensive ACG mixture.','Five radial/time cases with actual extended comparison; two independent Haar evaluations per target.'],'REC':['C4G actual scalar trajectory and history, actual affine atomic response, frozen midpoint surrogate adjoint; independent HeI photon spectrum.','Source JumpResponse Schur/tri-diagonal operator, real outgoing jumps, original fixed H owner. HeI profile Eq103 and actual Saha HI.','Transpose exact represented linear map, duality and goal-weight mesh. Native weak-history direct and paired; spectral conservative number and comoving energy.','64 new nested knots, 3 direct cases then 2 stable paired; 3 spectral grids.'],'REI':['C4F native shadow source with unchanged physical owner; local implicit gas-stage Jacobian; separate physical early-clock hierarchy.','Actual immutable residual context and candidate absorption; source-owned cooling/CMB rates; actual C4D BASS shear and REC opacity.','Rate increments rather than residual subtraction; central/admissible one-sided stencils, inverse and ledger derivative; direct work scope limited to local stage.','Build native shadow and run 2 base cases with 3 diagnostic substages each, bitwise replay; actual physical tau and finite lmax6 closure.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4h_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Scoped runnable code and actual Python syntax compilation; native Rust build and physics tests in C6.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   fs=[ex.submit(job,'bass.py',[],'rust_jet',450),ex.submit(job,'haar.py',[],'haar',450)];rr=[f.result() for f in fs]
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=3) as ex:
   f=ex.submit(job,'helium.py',[],'helium',180);r=job('rec.py',['mesh'],'mesh',180);rr=[r,f.result()]
   if r.get('exit')==0:
    ds=list(ex.map(lambda l:job('rec.py',['direct',l],f'direct_{l:g}',450),[0.,-.5,.5]));rr+=ds
    if all(x.get('exit')==0 for x in ds):
     ps=list(ex.map(lambda l:job('rec.py',['pair',l],f'pair_{l:g}',700),[-.5,.5]));rr+=ps
     if all(x.get('exit')==0 for x in ps):rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'early.py',[],'early',300);r=job('rei.py',['build'],'build_driver',380);rr=[r,f.result()]
   if r.get('exit')==0:
    r=job('rei.py',['native'],'native',600);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['analyze'],'analysis',90))
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n');print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual execution exits and artifacts, including initial failures: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a,b=j('RUST_JET.json'),j('QUATERNION_HAAR.json');record(k,'C7','Compiled Rust direct discrete coefficient, source-bound time and radial verification: '+json.dumps(a));record(k,'C8','Quaternion ACG importance integration, fixed data and prior: '+json.dumps(b));ok=a is not None and b is not None
  next_='Choose numerical time/radial owner from actual residual, integrate coefficient into production native source only after full jet and invariants; improve multimodal quaternion proposals if needed.'
 elif k=='REC':
  a,b,o=map(j,['GOAL_MESH.json','GOAL_SUMMARY.json','HEI_HI_TRANSFER.json']);record(k,'C7','Goal-oriented surrogate adjoint and actual retarded owner comparison: '+json.dumps(dict(mesh=a,signed=b)));record(k,'C8','Literature helium profile and conditional HI continuum transfer: '+json.dumps(o));ok=a is not None and b is not None and o is not None
  next_='Full weak-history discrete adjoint including positivity reconstruction; independent global reference and complete self-consistent HHe line/continuum feedback.'
 else:
  a,b,o=map(j,['NATIVE_RUNS.json','STAGE_JACOBIAN.json','EARLY_CLOCK_CLOSURE.json']);record(k,'C7','Actual native implicit chemical-substage response with fixed prepared inputs: '+json.dumps(dict(native=a,jacobian=b)));record(k,'C8','Actual early physical opacity and prescribed BASS shear hierarchy diagnostic: '+json.dumps(o));ok=a is not None and b is not None and o is not None
  next_='Compose actual local discrete chemistry Jacobian with incoming photon, redshift/work, geometry, and source derivatives; verify long-clock closed response and adaptive hierarchy at matched tolerance.'
 record(k,'C9','Self-review and actual failure boundaries: '+json.dumps(rows)+'; no full production regression, full native AD or continuum promotion.')
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4H',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

