"""R118-C4H final scientific disposition and exact scoped backup verification."""
from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,datetime,shutil,gzip
H=Path.home();sys.path.insert(0,str(H));from r118c4h_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4h_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k]);assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=True,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists();manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False);manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def blob(k,n,rev=None):
 return subprocess.check_output(['git','-C',str(repos[k]),'show',(rev or git(repos[k],'rev-parse','HEAD'))+':'+n])
def published(k,n,hs):assert sha(blob(k,scopes[k]+'/'+n))==hs
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n');record(k,tag,'Verified archive members and matching remote head before scoped cleanup.',[target.name,mname]);published(k,target.name,info['archive_sha256'])
 return git(repos[k],'rev-parse','HEAD')
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
rust=load(B/'RUST_JET.json');dd=maybe(B,'RUST_DD_JET.json');haar=load(B/'QUATERNION_HAAR.json');mesh=load(R/'GOAL_MESH.json');rec=load(R/'GOAL_SUMMARY.json');he=load(R/'HEI_HI_TRANSFER.json');hefine=maybe(R,'HEI_HI_REFINED.json');native=load(E/'NATIVE_RUNS.json');stage=load(E/'STAGE_JACOBIAN.json');early=load(E/'EARLY_CLOCK_CLOSURE.json');energy=load(E/'STABLE_STAGE_ENERGY.json')
assert len(rust['rows'])==5 and len(haar['rows'])==8
assert len(rec['pairs'])==2 and rec['steps']==mesh['steps'] and mesh['duality_relative']<1e-8 and rec['min_positive']>0
assert len(he['rows'])==3 and len(native)==2 and all(x['exit']==0 and all(x['replay_equal'].values()) for x in native)
assert len(stage['rows'])==6 and all(x['status']=='COMPLETE' for x in stage['rows']) and len(early['rows'])==16 and len(energy['rows'])==6
if dd is not None:assert len(dd['rows'])==4
if hefine is not None:assert len(hefine['rows'])==4
summary={'BASS':dict(rust=rust,dd=dd,haar=haar,mixed=load(B/'MIXED_PROPOSAL_REPLAY.json')),'REC':dict(mesh=mesh,goal=rec,goal_replay=load(R/'GOAL_REPLAY.json'),helium=he,helium_refined=hefine),'REI':dict(native=native,jacobian=stage,early=early,stage_energy=energy,gas_observables=load(E/'LOCAL_GAS_OBSERVABLE_JAC.json'))}
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN';dag['htt_base_mutation']=False
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n')
 record(k,'C10-final-science','Final scoped scientific results and actual source/claim boundaries; no original goal promotion.', ['DAG.json','FINAL_SCIENCE.json'])
names={'BASS':['r118c4h_bass.py','r118c4h_jet.rs','r118c4h_haar.py','r118c4h_jet_dd.rs'],'REC':['r118c4h_rec.py','r118c4h_helium.py'],'REI':['r118c4h_rei.py','r118c4h_stage_patch.rs.txt','r118c4h_early.py']}
common=['r118c4h_theory.py','r118c4h_coding.py','r118c4h_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4h_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4h_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';info=archive(target,[(H/n,n) for n in nn]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
scratch={}
# Deterministic stage tables are checked against actual run receipts. Both actual binaries are archived.
BS=H/'r118c4h_bass_scratch'
if BS.exists():
 assert BS.is_dir() and not BS.is_symlink() and BS.resolve()==BS
 expected_tables={f"n{x['n']}_r{x['nr']}.bin":x['stage_table_sha'] for x in rust['rows']}
 if dd:expected_tables.update({f"dd/n{x['n']}_r{x['nr']}.bin":x['stage_table_sha'] for x in dd['rows']})
 binary_files={'jet':('jet_binary.gz',rust['binary_sha'])}
 if dd:binary_files['dd/jet_dd']=('jet_dd_binary.gz',dd['binary_sha'])
 known=[];unique=[]
 for p in sorted(BS.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file():continue
  rel=str(p.relative_to(BS));h=hashfile(p)
  if rel in expected_tables:
   assert h==expected_tables[rel];known.append(dict(path=rel,sha=h,bytes=p.stat().st_size,kind='deterministic generated stage table with committed source and actual receipt'))
  elif rel in binary_files:
   arc,bs=binary_files[rel];assert sha(gzip.decompress(blob('BASS',scopes['BASS']+'/'+arc)))==h==bs
   known.append(dict(path=rel,sha=h,bytes=p.stat().st_size,kind='exact archived executable'))
  elif rel in ['jet_test','dd/jet_dd_test']:
   known.append(dict(path=rel,sha=h,bytes=p.stat().st_size,kind='reproducible compiled test executable, source and actual test log published'))
  else:unique.append((p,rel))
 assert {x['path'] for x in known}>=set(expected_tables)|set(binary_files)
 info=dict(known=known);fs=['SCRATCH_MANIFEST.json']
 if unique:
  target=B/'NATIVE_SCRATCH_UNIQUE.tar.gz';info['unique']=archive(target,unique);fs.append(target.name)
 (B/'SCRATCH_MANIFEST.json').write_text(json.dumps(info,indent=2)+'\n');record('BASS','C10-scratch-verified','BASS generated stage tables verified by actual receipt, binaries matched exact published archives, unique files archived if present.',fs)
 if unique:published('BASS',target.name,info['unique']['archive_sha256'])
 published('BASS','SCRATCH_MANIFEST.json',hashfile(B/'SCRATCH_MANIFEST.json'))
 n=len(known)+len(unique);size=sum(p.stat().st_size for p in BS.rglob('*') if p.is_file());shutil.rmtree(BS);assert not BS.exists();scratch['BASS']=dict(status='REMOVED_VERIFIED',files=n,logical_bytes=size,unique_count=len(unique))
# REI shadow: original exact archive, changed driver and outputs matched; build intermediates derived from source.
SH=H/'r118c4h_rei_shadow'
if SH.exists():
 assert SH.is_dir() and not SH.is_symlink() and SH.resolve()==SH
 F=repos['REI']/'research/r118c4f_external_stress';prev=load(F/'SHADOW_ARCHIVE.json');priorarc=F/'NATIVE_SHADOW_SOURCE.tar.gz';assert hashfile(priorarc)==prev['archive_sha256']
 prior={x['name']:x['sha256'] for x in prev['members']};build=load(E/'BUILD_ID.json')
 bin0=SH/'bridge/target/release/c3x_dg_bridge';assert hashfile(bin0)==build['binary_sha']==sha(gzip.decompress(blob('REI',scopes['REI']+'/stage_bridge.gz')))
 known=[];unique=[];build_n=build_bytes=0
 for p in sorted(SH.rglob('*')):
  assert not p.is_symlink()
  if not p.is_file():continue
  rel=p.relative_to(SH);r=str(rel)
  if rel.parts[:2]==('bridge','target'):
   build_n+=1;build_bytes+=p.stat().st_size;continue
  h=hashfile(p);kind=None
  if prior.get(r)==h:kind='prior exact source archive'
  elif r=='rust/rei_microphysics/src/axbi_covariant_driver.rs' and hashfile(E/'instrumented_driver.rs')==h:
   published('REI','instrumented_driver.rs',h);kind='published changed source'
  elif len(rel.parts)==2:
   dest=rel.parts[0]+'_'+rel.parts[1]
   if (E/dest).is_file() and hashfile(E/dest)==h:
    published('REI',dest,h);kind='published actual native output'
  if kind:known.append(dict(path=r,sha=h,bytes=p.stat().st_size,kind=kind))
  else:unique.append((p,r))
 info=dict(known=known,build_files=build_n,build_bytes=build_bytes,exact_binary_sha=build['binary_sha'],prior_archive_sha=prev['archive_sha256']);fs=['SHADOW_MANIFEST.json']
 if unique:
  target=E/'NATIVE_SHADOW_UNIQUE.tar.gz';info['unique']=archive(target,unique);fs.append(target.name)
 (E/'SHADOW_MANIFEST.json').write_text(json.dumps(info,indent=2)+'\n');record('REI','C10-shadow-verified','Exact original source and patched driver/native outputs verified, actual binary matched archive; unique source archived, reproducible build intermediates removed.',fs)
 if unique:published('REI',target.name,info['unique']['archive_sha256'])
 published('REI','SHADOW_MANIFEST.json',hashfile(E/'SHADOW_MANIFEST.json'))
 nfiles=sum(1 for p in SH.rglob('*') if p.is_file());nbytes=sum(p.stat().st_size for p in SH.rglob('*') if p.is_file())
 assert nfiles==len(known)+len(unique)+build_n
 shutil.rmtree(SH);assert not SH.exists();scratch['REI']=dict(status='REMOVED_VERIFIED',files=nfiles,logical_bytes=nbytes,unique_count=len(unique),build_files=build_n)
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4h_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed)
 if k in scratch:obj['scratch']=scratch[k]
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Verified scoped redundant drivers and scratch cleanup; no unrelated worktree or data removed.',['FINAL_CLEANUP.json'])
for k in repos:
 p=H/f'r118c4h_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4H',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),scratch=scratch,prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN',htt_base_mutation=False)
(H/'r118c4h_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4h_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],scratch=scratch,prunes=prunes),indent=2),flush=True)
