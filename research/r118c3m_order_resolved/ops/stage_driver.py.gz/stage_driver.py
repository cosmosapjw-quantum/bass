from pathlib import Path
import subprocess,os,json,hashlib,concurrent.futures
H=Path.home()
repos={
'BASS':(H/'worktrees/bass-r109-native-20261124','research/r118c3m_order_resolved','cef2dd710abf0789ebe584d087cd2831195a73af','research/r109-native-nonlinear-sky-20261124'),
'REC':(H/'Downloads/htt_r109_original_rec','research/r118c3m_gain_events','c631804a33830aded7eb84595d4c2509d39a4496','research/r109-finite-tilt-ray-thomson-20261124'),
'REI':(H/'worktrees/rei-htt-thomson-20261124','research/r118c3m_frequency_rays','74c592849eb07bc8b933ebba34e3796df79f2d4c','research/htt-tilted-thomson-20261124')}
env=dict(os.environ,GIT_TERMINAL_PROMPT='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
receipt=H/'r118c3m_push_receipts_20261126.jsonl'
def git(r,*args):
 p=subprocess.run(['git','-C',str(r),*args],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{r.name}: {args}: {p.stdout}')
 return p.stdout.strip()
def folder(k):r,d,_,_=repos[k];return r/d
def write(k,name,content):
 p=folder(k)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content.rstrip()+'\n' if isinstance(content,str) else json.dumps(content,indent=2)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def publish(k,stage,extra=()):
 r,d,base,branch=repos[k];assert git(r,'branch','--show-current')==branch
 assert not git(r,'diff','--cached','--name-only')
 git(r,'add',*(['--sparse'] if k=='REI' else []),'--',d,*extra)
 git(r,'diff','--cached','--check')
 staged=git(r,'diff','--cached','--name-only').splitlines();assert staged and all(x.startswith(d+'/') or x in extra for x in staged),staged
 git(r,'commit','-m',f'R118-C3M {stage}: {k} science')
 head=git(r,'rev-parse','HEAD');git(r,'push','origin',f'HEAD:refs/heads/{branch}')
 remote=git(r,'ls-remote','--heads','origin',f'refs/heads/{branch}').split()[0];assert remote==head
 return dict(stage=stage,repo=k,head=head,remote=remote,tree=git(r,'rev-parse','HEAD^{tree}'),paths=staged)
def batch(stage,extras=None):
 done={(v['stage'],v['repo']) for v in map(json.loads,receipt.read_text().splitlines())} if receipt.exists() else set()
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(publish,k,stage,(extras or {}).get(k,())):k for k in repos if (stage,k) not in done};errs=[]
  for f in concurrent.futures.as_completed(fut):
   try:
    row=f.result();print('PUSH',row['stage'],row['repo'],row['head'],flush=True)
    with receipt.open('a') as h:h.write(json.dumps(row)+'\n')
   except Exception as e:print('ERROR',fut[f],stage,repr(e),flush=True);errs.append(e)
  if errs:raise RuntimeError('publication incomplete')
def note(stage,content):
 for k,t in zip(repos,content):write(k,stage+'.md','# '+stage+' | R118-C3M '+k+'\n\n'+t)
 batch(stage)
