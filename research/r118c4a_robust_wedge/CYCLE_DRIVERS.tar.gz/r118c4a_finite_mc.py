from pathlib import Path
import sys,json,numpy as np
from scipy.stats import f,chi2
H=Path.home();sys.path.insert(0,str(H))
from r118c4a_theory_driver import repos,scopes,record
D=repos['BASS']/scopes['BASS']
a=np.load(D.parent/'r118c3z_spin_projector_mc/mc_extension/COMMANDER_SCORES_120.npz')
b=np.load(D/'HOLDOUT_SCORES.npz')
assert np.array_equal(a['sample_pixel'],b['sample_pixel']) and np.array_equal(a['response'],b['response'])
T=a['signal']+a['noise'];V=b['signal']+b['noise'];n,p=T.shape;d=V-T.mean(0);Z=np.linalg.solve(np.linalg.cholesky(np.cov(T,rowvar=False)),d.T).T;Q=np.sum(Z*Z,axis=1)
old=json.loads((D/'HOLDOUT.json').read_text());assert abs(Q.mean()-old['mahalanobis_mean'])<1e-12
scale=(1+1/n)*(n-1)*p/(n-p)
crit=scale*f.ppf(.95,p,n-p)
r=dict(train_n=n,p=p,heldout_n=len(V),observed_mean=float(Q.mean()),gaussian_finite_sample_mean=float(scale*(n-p)/(n-p-2)),gaussian_finite_sample_95=float(crit),exceed_finite_sample_95=int(np.sum(Q>crit)),chi2_95=float(chi2.ppf(.95,p)),exceed_chi2_95=int(np.sum(Q>chi2.ppf(.95,p))),max_score=float(Q.max()),scope='Gaussian iid reference for a single held-out score with estimated sample mean and covariance; scores share training estimates, so no exact binomial test or official likelihood claimed')
(D/'HOLDOUT_FINITE_SAMPLE.json').write_text(json.dumps(r,indent=2)+'\n')
record('BASS','C10-finite-MC-reference','Independent held-out score verification; exact scaled F marginal under Gaussian iid assumptions, conditional on unchanged training sample/operator. Shared training estimates preclude exact independent binomial inference.',['HOLDOUT_FINITE_SAMPLE.json'])
print(json.dumps(r,indent=2),flush=True)
