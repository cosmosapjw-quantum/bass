from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4j_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4j_bass.py','haar.py':'r118c4j_haar.py','matter.rs.txt':'r118c4j_matter.rs.txt','thomson.rs.txt':'r118c4j_thomson.rs.txt','stream.rs.txt':'r118c4j_stream.rs.txt'},'REC':{'rec.py':'r118c4j_rec.py','feedback.py':'r118c4j_feedback.py','event.py':'r118c4j_event.py'},'REI':{'rei.py':'r118c4j_rei.py','transport.rs.txt':'r118c4j_transport.rs.txt','stage.rs.txt':'r118c4j_stage.rs.txt','clock.py':'r118c4j_clock.py'}}
notes={'BASS':['C4I synchronized Taylor companion and actual C3X native operator pinned shadow. Differentiate represented matter and RK4 operators at actual finite-amplitude states.','Native OwnedModel matter_impl, exact fixed-particle coframe perturbation; actual LieHierarchy rhs and linear photon potentials. Frozen one-substep branch.','Second-order signed Taylor coefficients, rotation invariant and independent native finite differences; equal-cost IID/RQMC using C4I fixed allocation.','One pinned 4096-step actual native case and local endpoint probes, independent 4x2x4 quadrature replicates of 4096 draws.'],'REC':['C4I true scalar weak-history adjoint and actual signed first limiter. Fixed lambda=-0.5 prefix 960 steps, actual 5/3 moments and gas stages.','Map.mom3, original JumpResponse, positive3.reconstruct, C4H accepted trajectory. Actual C4I surviving HeI spectrum.','Exact fixed-geometry delay action on directional tangent, native finite-difference local gas derivatives, active LP directional replay; local moving-event identity.','One tangent and 4 independent perturbed signed histories, actual HMLA-valid H/HeII continuation, event contribution check.'],'REI':['C4I prepared absorption and C4H local J; actual selected spectral cells re-prepared, fixed-node analytic moment score and Verner smooth derivative.','Actual positive reconstruction and node quadrature, native accepted chemical stages, C4I source and C4F archive.','Covariance score at fixed nodes; mean and log-scale actual re-preparation FD, local J composition, no claim for threshold motion. Adaptive CF4 on actual knots.','Two native base replays and bounded selected cell diagnostics. CF4 step doubling, two hierarchy dimensions and four tolerances.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4j_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Scoped runnable source and actual Python syntax check. Native Rust builds and numerical tests in C6.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'haar.py',[],'haar',600);r=job('bass.py',['build'],'build_driver',480);rr=[r]
   if r.get('exit')==0:rr.append(job('bass.py',['run'],'native',300))
   rr.append(f.result())
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=3) as ex:
   f=ex.submit(job,'feedback.py',[],'feedback',350);g=ex.submit(job,'event.py',[],'event',180)
   r=job('rec.py',['tangent'],'tangent',700);rr=[r,f.result(),g.result()]
   if r.get('exit')==0:
    for h in [1e-6,1e-7]:
     rr+=list(ex.map(lambda l:job('rec.py',['fd',l],f'fd_{l:g}',600),[-h,h]))
    if all(x.get('exit')==0 for x in rr if x['tag'].startswith('fd_')):rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'clock.py',[],'clock',600);r=job('rei.py',['build'],'build_driver',480);rr=[r]
   if r.get('exit')==0:
    r=job('rei.py',['native'],'native',700);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['analyze'],'analysis',90))
   rr.append(f.result())
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n');print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual build/run exits and evidence: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a,b=j('OPERATOR_JET.json'),j('RQMC.json');record(k,'C7','Actual native represented coframe matter and harmonic RK4 Taylor probes: '+json.dumps(a));record(k,'C8','Fresh equal-count IID/RQMC comparison: '+json.dumps(b));ok=a is not None and b is not None
  next_='Compose actual local native matter, coframe, expansion, radiation and collision Taylor operators through full midpoint/Strang evolution; differentiate radial distribution weights; verify higher orders and general Lie constraints.'
 elif k=='REC':
  a,b,c=map(j,['SIGNED_TANGENT.json','HMLA_CONTINUATION.json','EVENT_MOTION.json']);record(k,'C7','Actual fixed-signed weak-history directional tangent, active LP branch and nonlinear replay: '+json.dumps(dict(tangent=a,event=c)));record(k,'C8','Actual surviving HeI spectrum in HMLA-valid H/HeII continuation: '+json.dumps(b));ok=a is not None and b is not None and c is not None
  next_='Extend branch-sensitive derivative to full signed trajectory and adjoint, include lambda-dependent retarded geometry and event jumps, then couple new recombination photons and thermal response.'
 else:
  a,b,c=map(j,['NATIVE_RUNS.json','SHAPE_JACOBIAN.json','ADAPTIVE_CF4.json']);record(k,'C7','Actual selected-cell spectral shape, geometry and local implicit response: '+json.dumps(dict(native=a,shape=b)));record(k,'C8','Actual knot-aligned adaptive CF4: '+json.dumps(c));ok=a is not None and b is not None and c is not None
  next_='Compose full prepared-cell reconstruction and threshold-motion derivatives with coframe/ray geometry and outer adaptive native map; physical observable-space error control.'
 record(k,'C9','Actual scope and failure classification: '+json.dumps(rows)+'; no full production regression or whole coupled derivative promotion.')
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4J',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

