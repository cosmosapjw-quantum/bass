from pathlib import Path
import json,subprocess,sys,concurrent.futures as cf,os,shutil,time,hashlib
H=Path.home();sys.path.insert(0,str(H))
from r118c3z_theory_driver_20261127 import repos,scopes,push,git,record,base
notes={
'BASS':["Pinned C3Y BASS base, C3X c3x_radial binary, C3Y finite signed amplitude. Exact spin3 projector criterion and independent actual paired MC covariance.","C3C WEDGE.json, C3S temporal matrix H/M, C3U selected control, C3Y matched l8 zero; C3X l10 signed pair at 4096. Actual Commander FITS source pair metadata from r105; no official likelihood.","Exact commutator projector, derivative of wedge in control coordinates. Run l10 zero at 4096/8192 and l10 ±.04 at 8192. MC sparse actual pixel centers, E-mode nuisance projection, paired covariance.","2 concurrent native processes, independent MC and projector; input provenance and timeouts. Protect all preexisting branches/data."],
'REC':["Pinned H-only fixed-H C3X direct and C3Y signed nt32. Acceptance same scalar reference, signed comparator and final stored positivity certificate; no continuum inference.","C3Y source_pair replay and C3X three_moments. Extend to 64/128; quadratic operator moment identity from R7 with exact native JumpResponse. Separate real-line energy flux.","Moment projection exact three lower moments, limiter total positivity; midpoint gas interpolation in quadratic direct owner; real line outgoing occupation flux from native energies/edge mapping.","Execute scalar64 and scalar128 sequential or parallel; at most 2 concurrent pair tasks; actual quadratic nt32 ± and zero, independent line budget. Per-command timeouts, no clipping."],
'REI':["Pinned C3X history and C3Y material tangent; actual primary harmonic continuous generator and EOS derivatives; no new native step or full chemistry credit.","Byte-compare PR378 vs BASS generator owner source, native moment formula and gas EOS/threshold constants. Read native historical blobs; retain C3Y J.","Use actual native clock with DOP853 continuous harmonic response and delta S/ln H/F closure, residual external sector radiation-like. EOS fixed-a partial derivatives. Independent memory via exact auxiliary elimination.","3 actual histories, lmax4 and one lmax6; independent memory 6 q values and 256/512/1024 refinement. No production mutation."]}
codes={'BASS':'bass.py','REC':'rec.py','REI':'rei.py'}
def receipt(k):return [json.loads(x) for x in (H/f'r118c3z_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def stage(k,i):
 D=repos[k]/scopes[k];st=f'C{i}'
 if i<=4:record(k,st,notes[k][i-1]);return
 p=D/codes[k];shutil.copyfile(H/f'r118c3z_{codes[k]}',p);subprocess.run([sys.executable,'-m','py_compile',str(p)],check=True)
 record(k,st,'Implemented bounded executable research scope; syntax compile success, scientific runs follow C6.',[p.name])
def execute(k):
 D=repos[k]/scopes[k];p=D/codes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(args,tag,timeout):
  f=D/(tag+'.log');t=time.monotonic()
  try:
   with f.open('w') as o:r=subprocess.run([sys.executable,'-u',str(p),*map(str,args)],cwd=str(repos[k]),env=env,stdout=o,stderr=subprocess.STDOUT,timeout=timeout)
   out=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-t)
  except Exception as e:out=dict(tag=tag,error=repr(e),seconds=time.monotonic()-t)
  print(k,out,flush=True);return out
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=3) as e:return list(e.map(lambda a:job(*a),[(['projector'],'projector',90),(['native'],'native',650),(['mc'],'mc',300)]))
 if k=='REI':
  with cf.ThreadPoolExecutor(max_workers=2) as e:return list(e.map(lambda a:job(*a),[(['harmonic'],'harmonic',200),(['memory'],'memory',90)]))
 rows=[]
 # Launch independent line budget concurrently with scalar replays. Keep at most 2 heavy pair processes later.
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  f=ex.submit(job,['line'],'line',120)
  rr=list(ex.map(lambda n:job(['scalar',n],f'scalar{n}',200),[64,128]));rows.extend(rr);rows.append(f.result())
 jobs=[]
 for n,r in zip([64,128],rr):
  if r.get('exit')==0:jobs.extend([(['pair',n,l],f'pair{n}_{l:g}',360) for l in [-.5,.5]])
 with cf.ThreadPoolExecutor(max_workers=2) as ex:rows.extend(ex.map(lambda a:job(*a),jobs))
 with cf.ThreadPoolExecutor(max_workers=2) as ex:rows.extend(ex.map(lambda l:job(['quad',32,l],f'quad32_{l:g}',240),[0.,-.5,.5]))
 return rows
def finish(k,rows):
 D=repos[k]/scopes[k];(D/'EXECUTION.json').write_text(json.dumps(rows,indent=2)+'\n')
 files=[p.name for p in D.iterdir() if p.is_file() and p.name not in {codes[k]} and not (p.name[0] in 'RC' and p.suffix=='.md') and p.name!='R7.json']
 # Include actual all execution outputs except historical stage notes; git commit path-limited.
 record(k,'C6','Actual execution command outcomes: '+json.dumps(rows)+'. Nonzero exits are not science passes.',sorted(set(files)))
 def j(name):
  p=D/name;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  p=j('PROJECTOR.json');b=j('BANDLIMIT.json');mc=j('COMMANDER_MC.json');native=j('NATIVE_RUNS.json')
  record(k,'C7','Exact projector check / selected control sensitivity: '+json.dumps(p)+'\nNative finite amplitudes: '+json.dumps(b))
  record(k,'C8','Native lmax/time differences and actual MC covariance; '+json.dumps({'bandlimit':b,'mc':mc,'native':native}))
  record(k,'C9','Self-review: exact group theory conditional on scalar opacity and SO(3) equivariance; discrete cancellation not exact. MC sparse sample, analytic latitude cut, unit beam and fixed orientation; no official likelihood, no observed sky or physical amplitude claim. Results: '+json.dumps(rows))
  next_='Full lmax10/12 signed amplitude sets and robust control sensitivity; actual Commander common mask and beam if acquired, full pixel operator and held-out MC. Keep original all-Bianchi scope.'
 elif k=='REC':
  pairs={}
  for n in [64,128]:
   for l in [-.5,.5]:
    a=j(f'pair_{n}_{l:g}.json');b=j(f'FINAL_POS_{n}_{l:g}.json')
    if a:pairs[f'{n}_{l:g}']=dict(pair=a,positivity=b)
  q={str(l):j(f'q3_32_{l:g}.json') for l in [0.,-.5,.5]};line=j('LINE_FLUX.json')
  record(k,'C7','Actual same-reference pair and full stored virtual positivity: '+json.dumps(pairs)+'\nQuadratic direct owner: '+json.dumps(q))
  delta={}
  for n in [64,128]:
   if all(f'{n}_{l:g}' in pairs for l in [-.5,.5]):delta[n]=(sum(pairs[f'{n}_{l:g}']['pair']['delta_x'] for l in [-.5,.5]))/(2*.5**2)
  record(k,'C8','Signed even coefficient by time grid (no continuum inference): '+json.dumps(delta)+'; quadratic direct outcomes '+json.dumps(q)+'; line flux max native comparison '+json.dumps(None if not line else {k:v for k,v in line.items() if k!='rows'}))
  record(k,'C9','Self-review: positivity after exact signed lower coefficient replacement; no heat admission from line-boundary flux, no HHe donor or physical H. Quadratic midpoint gas does not guarantee global order. Actual outcomes '+json.dumps(rows))
  next_='Compare stable quadratic signed pair on same reference, more common-event mesh control, HHe photon donor and net energy ledger. Preserve time nonmonotonicity if observed.'
 else:
  a=j('HARMONIC.json');b=j('MEMORY.json')
  record(k,'C7','Continuous primary harmonic material tangent and EOS identity on actual traces: '+json.dumps(a))
  record(k,'C8','Refinement and auxiliary memory comparison on actual thermal trace: '+json.dumps(b))
  record(k,'C9','Self-review: native source byte match but continuous generator, not discrete native trajectory tangent; conditional residual sector, no HHe rate derivative. Diagnostic coupling not physical kinetic kernel. Actual outcomes '+json.dumps(rows))
  next_='Native discrete primary/chemistry Jacobian through actual accepted owner, 4096/32 DG, source-owned HHe rates; derive memory coupling from physical collision model. AX11/T2 unchanged.'
 # Remove only generated bytecode of this cycle; no old tree is presumed obsolete.
 rem=[];cache=D/'__pycache__'
 if cache.is_dir():
  for p in cache.glob('*.pyc'):
   if p.is_file():rem.append(dict(path=str(p),bytes=p.stat().st_size));p.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(removed=rem,prune_dry_run=prune,unrelated_preserved=True),indent=2)+'\n')
 (D/'NEXT.md').write_text(next_+'\n')
 ok=all(r.get('exit')==0 for r in rows)
 dag=dict(cycle='R118-C3Z',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',stage_receipts=receipt(k),execution=rows,native_subagent='NOT_RUN',full_production_regression='NOT_RUN',next=next_)
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n')
 record(k,'C10','Scope executed with actual evidence; publication/production/claim admission separate. '+next_,['CLEANUP.json','NEXT.md','DAG.json'])
if __name__=='__main__':
 for k in repos:assert [r['stage'] for r in receipt(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:stage(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  fs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(fs):finish(fs[f],f.result())
 print('C1-C10 DRIVER COMPLETE',flush=True)

