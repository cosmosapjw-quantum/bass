from pathlib import Path
import sys,json,subprocess,os,hashlib
H=Path.home();sys.path.insert(0,str(H))
from r118c3z_theory_driver_20261127 import repos,scopes,push
k='REI';D=repos[k]/scopes[k];p=D/'rei.py';s=p.read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b)
# Native generator rhs excludes exact isotropic -4Y; carrier is therefore comoving.
rep("yr=np.array([photon(y,F[0],m)[0] for y in yy.y.T]);pp=np.array([photon(y,F[0],m)[1] for y in yy.y.T])","yr=np.array([photon(y,aa,m)[0] for y,aa in zip(yy.y.T,F)]);pp=np.array([photon(y,aa,m)[1] for y,aa in zip(yy.y.T,F)])")
rep("_,pga=photon(Yt,F[0],m)","_,pga=photon(Yt,F[0]*np.exp(t),m)")
rep("drg,dpg=photon(Z,F[0],m)","drg,dpg=photon(Z,F[0]*np.exp(t),m)")
rep("[photon(z,F[0],m)[0] for z in yf[:,16:]]","[photon(z,aa,m)[0] for z,aa in zip(yf[:,16:],F)]")
rep("def photon(y,a0,m):","def photon(y,a0,m):\n # a0 argument is actual endpoint a, not initial a. Exported generator excludes isotropic -4Y.")
p.write_text(s)
push(k,'C6-repair-carrier',['rei.py'])
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with (D/'harmonic_carrier_repair.log').open('w') as o:
 r=subprocess.run([sys.executable,'-u',str(p),'harmonic'],env=env,cwd=str(repos[k]),stdout=o,stderr=subprocess.STDOUT,timeout=150)
row=dict(tag='harmonic_carrier_repair',exit=r.returncode,diagnosis='LieHierarchy::rhs anisotropic only, a^-4 carrier. Prior trace discrepancy 3.8096145141128265e-5, actual (a_end/a_start)^4-1=3.809614514183046e-5; retain original acceptance.')
(D/'CARRIER_REPAIR.json').write_text(json.dumps(row,indent=2)+'\n')
fs=['harmonic_carrier_repair.log','CARRIER_REPAIR.json']+[x.name for x in D.glob('*_TANGENT.npz')]
if (D/'HARMONIC.json').exists():fs+=['HARMONIC.json']
push(k,'C6-repair-execution',fs)
print(row,flush=True)
if r.returncode==0:
 a=json.loads((D/'HARMONIC.json').read_text())
 dag=json.loads((D/'DAG.json').read_text());dag['repair_execution']=row;dag['status']='SCOPED_EXECUTED';dag['scientific_scope']='continuous primary response and algebraic HHe only; native discrete chemistry unresolved';(D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n')
 (D/'C10_CARRIER_REPAIR.md').write_text('# C10 carrier repair\n\nExact source states anisotropic-only rhs; physical a^-4 scaling restored. Actual rerun all cases exit zero, trace/FD/EOS tests in HARMONIC.json. Original failed log retained. No native discrete HHe rate Jacobian credit.\n')
 push(k,'C10-repair-closeout',['DAG.json','C10_CARRIER_REPAIR.md'])
 print('REI repaired',json.dumps(a)[:7000],flush=True)

