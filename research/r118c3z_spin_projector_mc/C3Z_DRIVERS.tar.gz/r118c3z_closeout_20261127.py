from pathlib import Path
import sys,json,hashlib,tarfile,subprocess,datetime
H=Path.home();sys.path.insert(0,str(H))
from r118c3z_theory_driver_20261127 import repos,scopes,base,git,push,record
def sha(b):return hashlib.sha256(b).hexdigest()
def receipts(k):return [json.loads(x) for x in (H/f'r118c3z_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected={f'{q}{i}' for q in ('R','C') for i in range(1,11)}
for k,p in repos.items():
 r=receipts(k);assert expected<=set(x['stage'] for x in r),k
 assert all(x['head']==x['remote'] for x in r),k
 assert git(p,'rev-parse','HEAD')==r[-1]['head'],k
 assert git(p,'status','--porcelain','--',scopes[k])=='',k
D=repos['BASS']/scopes['BASS']
# Correct historical derivation notes by explicit addendum, not by silently rewriting them.
E=repos['REI']/scopes['REI']
record('REI','C10-conventions','Superseding convention for R4/R5: implemented memory model is dV/dt=-alpha V-bX, dX/dt=cV-gamma X with b=c=1. Therefore memory kernel enters V equation with minus sign. Comoving Y physical trace uses CURRENT a^-4; the historical a_initial^-4 note was corrected by C10_CARRIER_REPAIR.md. No native HHe rate integration or discrete tangent asserted.')
names=['r118c3z_bass.py','r118c3z_rec.py','r118c3z_rei.py','r118c3z_theory_driver_20261127.py','r118c3z_coding_driver_20261127.py','r118c3z_rei_repair_20261127.py','r118c3z_mc_extend_20261127.py','r118c3z_mc_extend_20261127.log','r118c3z_rec_exact_line_20261127.py','r118c3z_rec_exact_line_20261127.log','r118c3z_LINE_FLUX_EXACT.json','r118c3z_closeout_20261127.py']
files=[H/n for n in names]
assert all(p.is_file() and not p.is_symlink() for p in files)
manifest=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
a=D/'C3Z_DRIVERS.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p in files:t.add(p,arcname=p.name,recursive=False)
with tarfile.open(a,'r:gz') as t:
 assert set(t.getnames())==set(names)
 for m in manifest:assert sha(t.extractfile(m['name']).read())==m['sha256']
(D/'DRIVER_ARCHIVE_MANIFEST.json').write_text(json.dumps({'archive':a.name,'sha256':sha(a.read_bytes()),'members':manifest},indent=2)+'\n')
record('BASS','C10-archive','Lossless archive of exact cycle-local driver and duplicate log/data files. Member checks completed; unlink only after remote HEAD match and archive blob verification.',[a.name,'DRIVER_ARCHIVE_MANIFEST.json'])
h=git(repos['BASS'],'rev-parse','HEAD');branch=git(repos['BASS'],'branch','--show-current')
assert git(repos['BASS'],'ls-remote','origin',f'refs/heads/{branch}').split()[0]==h
blob=subprocess.check_output(['git','-C',str(repos['BASS']),'show',h+':'+scopes['BASS']+'/'+a.name])
assert sha(blob)==sha(a.read_bytes())
deleted=[]
for p,m in zip(files,manifest):
 assert p.is_file() and not p.is_symlink() and sha(p.read_bytes())==m['sha256']
 p.unlink();deleted.append(m)
worktrees={}
for k,p in repos.items():
 dry=git(p,'worktree','prune','--dry-run','--verbose')
 git(p,'worktree','prune')
 worktrees[k]={'prune_dry_run':dry,'retained':git(p,'worktree','list','--porcelain')}
cleanup={'archived_and_removed':deleted,'count':len(deleted),'bytes':sum(x['bytes'] for x in deleted),'archive_sha256':sha(blob),'worktrees':worktrees,'no_active_worktrees_deleted':True,'unrelated_backups_and_work_preserved':True}
(D/'FINAL_CLEANUP.json').write_text(json.dumps(cleanup,indent=2)+'\n')
record('BASS','C10-cleanup','Cycle-local duplicates removed after archive byte verification and remote push; stale worktree registration prune applied; active worktrees preserved. See FINAL_CLEANUP.json.',['FINAL_CLEANUP.json'])
out={}
allrows=[]
for k,p in repos.items():
 r=receipts(k);allrows+=r
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');remote=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==remote==r[-1]['head'],k
 assert expected<=set(x['stage'] for x in r),k
 assert all(x['head']==x['remote'] for x in r),k
 assert git(p,'status','--porcelain','--',scopes[k])=='',k
 assert git(p,'merge-base','--is-ancestor',base[k],h)=='',k
 out[k]={'base':base[k],'head':h,'tree':git(p,'rev-parse','HEAD^{tree}'),'branch':b,'remote':remote,'scope':scopes[k],'scope_clean':True,'stages':sorted(expected),'push_count':len(r),'repo_status':git(p,'status','--porcelain')}
# Cross-check executed evidence, including the REI failed original and successful repair.
for k in ['BASS','REC']:
 d=repos[k]/scopes[k];j=json.loads((d/'EXECUTION.json').read_text());assert all(x['exit']==0 for x in j),k
e=repos['REI']/scopes['REI'];assert (e/'HARMONIC.json').exists() and (e/'MEMORY.json').exists() and (e/'CARRIER_REPAIR.json').exists()
(H/'r118c3z_push_receipts_20261127.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in allrows))
final={'cycle':'R118-C3Z','status':'SCOPED_RESEARCH_EXECUTED_REMOTE_VERIFIED','standard_stage_count':60,'push_count':len(allrows),'repos':out,'cleanup':cleanup,'full_production_regression':'NOT_RUN','native_subagents':'NOT_RUN','original_targets':'OPEN','timestamp':datetime.datetime.now().astimezone().isoformat()}
(H/'r118c3z_final_receipt_20261127.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'push_count':len(allrows),'repos':out,'cleanup_count':cleanup['count'],'cleanup_bytes':cleanup['bytes'],'archive_sha256':cleanup['archive_sha256'],'prune':{k:v['prune_dry_run'] for k,v in worktrees.items()},'receipt':str(H/'r118c3z_final_receipt_20261127.json')},indent=2),flush=True)
