from pathlib import Path
import sys,subprocess,json,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4f_theory import repos,scopes,base,git,record
sources={'BASS':{'bass.py':'r118c4f_bass.py','haar.py':'r118c4f_haar.py'},'REC':{'rec.py':'r118c4f_rec.py'},'REI':{'native.py':'r118c4f_native.py','rei.py':'r118c4f_rei.py','instrumentation_patch.py.txt':'r118c4f_instrumentation_patch.py.txt'}}
notes={'BASS':['Train-only multi-matrix constrained fit on C4E actual 192/256 M; heldout 320 direct physical and matrix, matched native 16384. Separate prior and Haar sensitivity.','Exact C4E DP5 physical source, Q basis, C4E selected control and actual C3X binary; original 190 Commander score cache.','Mean/difference residual, analytic SVD Newton, budget+spin1+peak checks, holdout not used in selection; 2 Sobol scrambles and injections on actual null draws.','Fit, independent 3 direct/basis computations, 13 native cases at 16384, separate cache-only Haar calculation; bound threads.'],
'REC':['Refine 96 C4E intervals ranked by prior even/odd discrepancy, align actual kinematic arrival candidates; same common scalar and signed grid. Independent HeII effective source rate decomposition.','C4D/C4E actual histories, C3V Map, C4A same source weak moments and positivity, source helium_rhs.','Generate actual first and second kinematic arrivals, keep old mesh nodes, shared grid and exact source splitting, preserve min-delay and positivity. Rate terms net, not resolved spectrum.','Mesh + helium, three direct solves parallel, then signed pairs; record exact outputs and failure.'],
'REI':['Pinned C4C native shadow instrument only accepted nodes: full external pressure and stock/ledger. C4D cases and C4E tangent re-evaluate. Independent adaptive closure.','C4C exact build source PR378/C3X, actual C4D 18 histories and source C3Z generators, C4E conditional response.','No operator change; direct components before huge background subtraction. Compare native replay and measure stable energy, pressure derivatives. C4E conditional tangent uses full external STF; nested retained-mode diagnostic.','One shadow build, 18 native cases (6 workers), full tangent after native, independent adaptive; no HTT mutation.']}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4f_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k,i):
 D=repos[k]/scopes[k]
 if i<=4:record(k,f'C{i}',notes[k][i-1]);return
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):subprocess.run([sys.executable,'-m','py_compile',str(D/dst)],check=True)
 record(k,'C5','Executable scoped research source; actual syntax compilation for Python files. Native build is C6.',list(sources[k]))
def execute(k):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 def job(file,args,tag,timeout):
  tm=time.monotonic();p=D/(tag+'.log')
  try:
   with p.open('w') as f:r=subprocess.run([sys.executable,'-u',str(D/file),*map(str,args)],cwd=repos[k],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   x=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-tm)
  except Exception as e:x=dict(tag=tag,error=repr(e),seconds=time.monotonic()-tm)
  print(k,x,flush=True);return x
 if k=='BASS':
  with cf.ThreadPoolExecutor(max_workers=3) as ex:
   f=ex.submit(job,'haar.py',[],'haar',300);r=job('bass.py',['fit'],'fit',120);rr=[r]
   if r.get('exit')==0:
    a=ex.submit(job,'bass.py',['heldout'],'heldout',350);b=ex.submit(job,'bass.py',['native'],'native',700);rr.extend([a.result(),b.result()])
   rr.append(f.result())
 elif k=='REC':
  with cf.ThreadPoolExecutor(max_workers=3) as ex:
   f=ex.submit(job,'rec.py',['helium'],'helium',90);r=job('rec.py',['mesh'],'mesh',120);rr=[r,f.result()]
   if r.get('exit')==0:
    direct=list(ex.map(lambda l:job('rec.py',['direct',l],f'direct_{l:g}',400),[0.,-.5,.5]));rr+=direct
    if all(x.get('exit')==0 for x in direct):
     rr+=list(ex.map(lambda l:job('rec.py',['pair',l],f'pair_{l:g}',550),[-.5,.5]))
     if all(x.get('exit')==0 for x in rr if x['tag']!='helium'):rr.append(job('rec.py',['analyze'],'analysis',90))
 else:
  with cf.ThreadPoolExecutor(max_workers=2) as ex:
   f=ex.submit(job,'rei.py',['adaptive'],'adaptive',180);r=job('native.py',['build'],'build_driver',360);rr=[r,f.result()]
   if r.get('exit')==0:
    r=job('native.py',['native'],'native',650);rr.append(r)
    if r.get('exit')==0:rr.append(job('rei.py',['geometry'],'geometry',180))
 (D/'EXECUTION.json').write_text(json.dumps(rr,indent=2)+'\n')
 print('EXECUTED',k,json.dumps(rr),flush=True);return rr
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 fs=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual execution exits and artifacts, including recorded initial failures: '+json.dumps(rows),sorted(set(fs)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 if k=='BASS':
  a,b,c,o=map(j,['TRAIN_SELECTION.json','HELDOUT.json','NATIVE_16384.json','HAAR_PRIOR_SENSITIVITY.json']);r=dict(train=a,heldout=b,native=c)
  record(k,'C7','Actual robust train, independent direct physical heldout, native time refinement: '+json.dumps(r));record(k,'C8','Actual 2-scramble, 5-prior Haar and injected signal tests: '+json.dumps(o))
  ok=all(x is not None for x in [a,b,c,o]);next_='Use heldout and native results to choose control; direct nonlinear perturbative coefficient or coupled higher-precision native integrator, prior-dependent orientation sensitivity remains a conditional diagnostic.'
 elif k=='REC':
  a,b,o=map(j,['MESH.json','CAUSAL_SUMMARY.json','HELIUM_CHANNELS.json']);r=dict(mesh=a,signed=b)
  record(k,'C7','Actual ray-delay alignment and direct/signed owner comparison: '+json.dumps(r));record(k,'C8','Primordial source rate decomposition and energy comparison: '+json.dumps(o))
  ok=a is not None and b is not None and o is not None;next_='Use causal defect results to rank weighted channel/source events and refine odd response; construct independent source-owned frequency-resolved He/H feedback and radiation energy closure.'
 else:
  a,b,o=map(j,['NATIVE_RUNS.json','FULL_EXTERNAL_TANGENT.json','ADAPTIVE_CLOSURE.json']);r=dict(native=a,tangent=b)
  record(k,'C7','Actual native external components, replay and conditional full stress tangent: '+json.dumps(r));record(k,'C8','Nested low-l adaptive closure diagnostics: '+json.dumps(o))
  ok=a is not None and all(x['exit']==0 for x in a) and b is not None and o is not None;next_='Close explicit native discrete signed gas-rate/geometry feedback Jacobian and refine full source over long clock; adaptive truncation needs cheap error estimator and physical transfer validation.'
 record(k,'C9','Self-review, actual scope and failure status: '+json.dumps(rows)+'; no production regression, full native coupled tangent or continuum promotion.')
 (D/'NEXT.md').write_text(next_+'\n')
 (D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4F',base=base[k],scope=scopes[k],status='SCOPED_EXECUTED' if ok else 'SCOPED_PARTIAL',execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 cache=D/'__pycache__'
 if cache.is_dir():
  for q in cache.glob('*.pyc'):q.unlink()
  if not any(cache.iterdir()):cache.rmdir()
 prune=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prune:git(repos[k],'worktree','prune')
 (D/'CLEANUP.json').write_text(json.dumps(dict(prune_dry_run=prune,prune_executed=not bool(prune),unrelated_preserved=True),indent=2)+'\n')
 record(k,'C10','Actual scoped disposition; '+next_,['NEXT.md','DAG.json','CLEANUP.json'])
if __name__=='__main__':
 if len(sys.argv)>1:finish(sys.argv[1]);sys.exit()
 for k in repos:assert [x['stage'] for x in receipts(k)]==[f'R{i}' for i in range(1,11)]
 for i in range(1,6):
  with cf.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(lambda k:pre(k,i),repos))
 with cf.ThreadPoolExecutor(max_workers=3) as ex:
  jobs={ex.submit(execute,k):k for k in repos}
  for f in cf.as_completed(jobs):
   k=jobs[f];r=f.result()
   if all(x.get('exit')==0 for x in r):finish(k)
   else:print('REPAIR_REQUIRED',k,flush=True)
 print('CODING_DRIVER_COMPLETE',flush=True)

