"""Final C4F verified publication and exact scoped cleanup."""
from pathlib import Path
import sys,json,subprocess,hashlib,tarfile,datetime,os,shutil,gzip
H=Path.home();sys.path.insert(0,str(H));from r118c4f_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4f_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k,clean=True):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k])
 if clean:assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=not status,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists()
 manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False)
   manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def verify_remote_file(k,name,hs):
 p=repos[k];h=git(p,'rev-parse','HEAD');b=subprocess.check_output(['git','-C',str(p),'show',h+':'+scopes[k]+'/'+name]);assert sha(b)==hs;return h
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n')
 record(k,tag,'Verified archive member bytes and matching remote commit before scoped deletion.',[target.name,mname])
 return verify_remote_file(k,target.name,info['archive_sha256'])
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
train=maybe(B,'TRAIN_SELECTION.json');held=maybe(B,'HELDOUT.json');native=maybe(B,'NATIVE_16384.json');haar=maybe(B,'HAAR_PRIOR_SENSITIVITY.json');mesh=maybe(R,'MESH.json');rec=maybe(R,'CAUSAL_SUMMARY.json');he=maybe(R,'HELIUM_CHANNELS.json');rei=maybe(E,'NATIVE_RUNS.json');geo=maybe(E,'FULL_EXTERNAL_TANGENT.json');cl=maybe(E,'ADAPTIVE_CLOSURE.json')
if native is not None:assert len(native['rows'])==13 and all(x['exit']==0 for x in native['rows'])
if haar is not None:assert haar['orientation_count']==8192 and len(haar['rows'])==10 and haar['n_pairs']==190
if geo is not None:assert len(geo['rows'])==2 and all(len(x['directions'])==4 for x in geo['rows'])
if cl is not None:assert len(cl['rows'])==36
if rec is not None:assert len(rec['pairs'])==2 and rec['steps']==mesh['steps'] and rec['min_positive']>0
summary={'BASS':dict(train=train,heldout=held,native=native,haar=haar,sensitivity=maybe(B,'ROBUST_SENSITIVITY.json')),'REC':dict(mesh=mesh,causal=rec,helium=he,arrival_replay=maybe(R,'ARRIVAL_REPLAY.json')),'REI':dict(native=rei,geometry=geo,adaptive=cl,ledger_fd_audit=maybe(E,'LEDGER_FD_AUDIT.json'))}
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN';dag['htt_base_mutation']=False
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n')
 record(k,'C10-final-science','Final scoped results, checked actual artifacts and source boundary; no original-goal promotion.', ['DAG.json','FINAL_SCIENCE.json'])
names={'BASS':['r118c4f_bass.py','r118c4f_haar.py'],'REC':['r118c4f_rec.py'],'REI':['r118c4f_native.py','r118c4f_rei.py','r118c4f_instrumentation_patch.py.txt']}
common=['r118c4f_theory.py','r118c4f_coding.py','r118c4f_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4f_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4f_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';info=archive(target,[(H/n,n) for n in nn]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
# Preserve the exact complete shadow source tree and unique native run files, excluding reproducible build target.
SH=H/'r118c4f_external_shadow';shadow=dict(status='NOT_CREATED')
if SH.exists():
 assert SH.is_dir() and not SH.is_symlink() and SH.resolve()==SH
 items=[];duplicates=[];symlinks=[];build_files=0;build_bytes=0
 for p in sorted(SH.rglob('*')):
  rel=p.relative_to(SH)
  if p.is_symlink():symlinks.append(str(rel));continue
  if not p.is_file():continue
  if rel.parts[:2]==('bridge','target'):
   build_files+=1;build_bytes+=p.stat().st_size;continue
  if rel.parts[0]=='runs':
   if len(rel.parts)==3:dst=rel.parts[1]+'_'+rel.parts[2]
   elif len(rel.parts)==2 and p.suffix=='.cfg':dst=p.name
   else:dst=None
   if dst and (E/dst).is_file() and hashfile(E/dst)==hashfile(p):
    verify_remote_file('REI',dst,hashfile(p));duplicates.append(dict(source=str(rel),remote=dst,bytes=p.stat().st_size,sha256=hashfile(p)));continue
  items.append((p,str(rel)))
 assert not symlinks,symlinks
 # Only remove target if exact built executable has a remotely verified gzip copy.
 binary=SH/'bridge/target/release/c3x_dg_bridge';bid=maybe(E,'BUILD_ID.json')
 if binary.exists() and (E/'c4f_dg_bridge.gz').exists():
  assert bid is not None and sha(gzip.decompress((E/'c4f_dg_bridge.gz').read_bytes()))==hashfile(binary)==bid['binary_sha']
  verify_remote_file('REI','c4f_dg_bridge.gz',hashfile(E/'c4f_dg_bridge.gz'));binary_verified=True
 else:binary_verified=False
 target=E/'NATIVE_SHADOW_SOURCE.tar.gz';info=archive(target,items);info.update(duplicate_count=len(duplicates),duplicates=duplicates,build_files=build_files,build_bytes=build_bytes,binary_verified=binary_verified)
 arc_commit=publish_archive('REI','C10-shadow-source-archive',target,info,'SHADOW_ARCHIVE.json')
 # Keep partial builds if executable could not be verified; otherwise remove only the exact cycle shadow.
 if binary_verified:
  nfiles=sum(1 for p in SH.rglob('*') if p.is_file());nbytes=sum(p.stat().st_size for p in SH.rglob('*') if p.is_file())
  assert nfiles==len(items)+len(duplicates)+build_files
  shutil.rmtree(SH);assert not SH.exists()
  shadow=dict(status='REMOVED_VERIFIED',files=nfiles,logical_bytes=nbytes,archive_sha=info['archive_sha256'],archive_commit=arc_commit,duplicate_count=len(duplicates),build_bytes=build_bytes)
 else:shadow=dict(status='PRESERVED_INCOMPLETE_BUILD',archive_sha=info['archive_sha256'],archive_commit=arc_commit)
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4f_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed)
 if k=='REI':obj['shadow']=shadow
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Scoped redundant drivers and verified shadow cleanup; no unrelated worktree or data removed.',['FINAL_CLEANUP.json'])
for k in repos:
 p=H/f'r118c4f_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4F',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),shadow=shadow,prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN',htt_base_mutation=False)
(H/'r118c4f_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4f_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],shadow=shadow,prunes=prunes),indent=2),flush=True)
