"""C4N scoped closure; exact remote commit receipts and safe source/build scratch disposition."""
from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,datetime,shutil,gzip,io
H=Path.home();sys.path.insert(0,str(H));from r118c4n_theory import repos,scopes,base,git,record
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def receipts(k):return [json.loads(s) for s in (H/f'r118c4n_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
expected=[f'R{i}' for i in range(1,11)]+[f'C{i}' for i in range(1,11)]
def verify(k):
 p=repos[k];r=receipts(k);assert [x['stage'] for x in r if x['stage'] in expected]==expected,(k,[x['stage'] for x in r])
 assert all(x['head']==x['remote'] for x in r)
 b=git(p,'branch','--show-current');h=git(p,'rev-parse','HEAD');rh=git(p,'ls-remote','origin',f'refs/heads/{b}').split()[0]
 assert h==rh==r[-1]['head'] and git(p,'rev-parse','HEAD^{tree}')==r[-1]['tree']
 assert subprocess.run(['git','-C',str(p),'merge-base','--is-ancestor',base[k],h]).returncode==0
 status=git(p,'status','--porcelain','--',scopes[k]);assert not status,(k,status)
 return dict(branch=b,head=h,remote=rh,tree=r[-1]['tree'],scope=scopes[k],stages=20,pushes=len(r),scope_clean=True,other_status=git(p,'status','--porcelain'))
def archive(target,items):
 assert not target.exists();manifest=[]
 with tarfile.open(target,'w:gz') as t:
  for p,n in items:
   assert p.is_file() and not p.is_symlink();t.add(p,arcname=n,recursive=False);manifest.append(dict(name=n,bytes=p.stat().st_size,sha256=hashfile(p)))
 with tarfile.open(target,'r:gz') as t:
  assert set(t.getnames())=={x['name'] for x in manifest}
  for x in manifest:assert sha(t.extractfile(x['name']).read())==x['sha256']
 return dict(archive=target.name,archive_sha256=hashfile(target),archive_bytes=target.stat().st_size,members=manifest,original_bytes=sum(x['bytes'] for x in manifest))
def blob(k,n,rev=None):return subprocess.check_output(['git','-C',str(repos[k]),'show',(rev or git(repos[k],'rev-parse','HEAD'))+':'+n])
def published(k,n,hs):assert sha(blob(k,scopes[k]+'/'+n))==hs
def publish_archive(k,tag,target,info,mname):
 D=repos[k]/scopes[k];(D/mname).write_text(json.dumps(info,indent=2)+'\n');record(k,tag,'Verified archive members and matching remote head before scoped cleanup.',[target.name,mname]);published(k,target.name,info['archive_sha256'])
 return git(repos[k],'rev-parse','HEAD')
for k in repos:verify(k)
B=repos['BASS']/scopes['BASS'];R=repos['REC']/scopes['REC'];E=repos['REI']/scopes['REI']
def maybe(D,n):return load(D/n) if (D/n).exists() else None
summary={k:load(repos[k]/scopes[k]/'FINAL_SCIENCE.json') for k in repos}
summary['BASS']['codazzi_matched']=load(B/'LIE_CODAZZI.json')
summary['BASS']['work_table_audit']=load(B/'WORK_TABLE_AUDIT.json')
summary['REC']['spline_audit']=load(R/'SPLINE_AUDIT.json')
summary['REC']['spline_residual_audit']=load(R/'SPLINE_RESIDUAL_AUDIT.json')
summary['REC']['fixed_T_atomic_x_jvp']=load(R/'ATOMIC_X_JVP.json')
summary['REI']['cost_bracket']=load(E/'COST_BRACKET.json')
summary['REI']['capture']=load(E/'CAPTURE.json')
assert all(a['main'] is not None and a['independent'] is not None for a in summary.values())
assert all(x['exit']==0 for x in summary['BASS']['main']['runs']) and len(summary['BASS']['main']['runs'])==9
assert len(summary['BASS']['main']['replays'])==5 and all(not any(x['geometry_gap'].values()) and x['coframe_gap']==0 for x in summary['BASS']['main']['replays'])
assert len(summary['BASS']['codazzi_matched']['rows'])==12
assert summary['REC']['main']['steps']==1773 and summary['REC']['main']['lp_analytic_total']>=summary['REC']['main']['lp_analytic_used']
assert len(summary['REC']['independent']['rows'])==3 and len(summary['REC']['fixed_T_atomic_x_jvp']['rows'])==14
assert len(summary['REC']['spline_audit']['rows'])==12
assert all(x['exit']==0 and all(x['parity'].values()) for x in load(E/'NATIVE_RUNS.json')) and len(load(E/'NATIVE_RUNS.json'))==5
assert len(summary['REI']['main']['rows'])==2 and len(summary['REI']['cost_bracket']['comparisons'])==2
assert all(x.get('exit')==0 for v in summary.values() for x in v['execution'])
for k,D in [('BASS',B),('REC',R),('REI',E)]:
 dag=load(D/'DAG.json');dag['final_science']=summary[k];dag['claim_status']={'BASS':'EXACT_NATIVE_STAGE_REPLAY_FINITE_TABLE_RESPONSE_NOT_LIVE_CHEMICAL_TAYLOR2','REC':'EXACT_REPRESENTED_SPLINE_AND_FIXED_SNAPSHOT_ANGULAR_JVP_NOT_FULL_GAS_JVP','REI':'FIXED_GEOMETRY_THETA_LOCAL_DG_JVP_NOT_FULL_MOVING_CUT_CHAIN'}[k];dag['native_subagent']='NOT_RUN';dag['production_regression']='NOT_RUN';dag['htt_base_mutation']=False
 (D/'DAG.json').write_text(json.dumps(dag,indent=2)+'\n');(D/'FINAL_SCIENCE.json').write_text(json.dumps(summary[k],indent=2)+'\n');record(k,'C10-final-science','Final measured scoped results and actual source/claim boundaries; no original goal promotion.',['DAG.json','FINAL_SCIENCE.json'])
from r118c4n_coding import sources
names={k:list(v.values()) for k,v in sources.items()}
for k,v in sources.items():
 for dst,src in v.items():
  p=H/src; final= repos[k]/scopes[k]/dst
  assert p.is_file() and final.is_file() and not p.is_symlink() and not final.is_symlink()
  published(k,dst,hashfile(final))
  if hashfile(p)!=hashfile(final):
   shutil.copyfile(final,p)
common=['r118c4n_theory.py','r118c4n_coding.py','r118c4n_closeout.py'];root=H/'research_cycle_backups';root.mkdir(exist_ok=True)
common_info=archive(root/'r118c4n_orchestration.tar.gz',[(H/n,n) for n in common]);shutil.copyfile(root/'r118c4n_orchestration.tar.gz',B/'ORCHESTRATION.tar.gz');common_remote=publish_archive('BASS','C10-orchestration-archive',B/'ORCHESTRATION.tar.gz',common_info,'ORCHESTRATION_ARCHIVE.json')
archives={}
for k,nn in names.items():
 D=repos[k]/scopes[k];target=D/'CYCLE_DRIVERS.tar.gz';aux=sorted(p.name for p in D.iterdir() if p.is_file() and p.suffix in ('.py','.rs','.cpp') and p.name not in sources[k]);info=archive(target,[(H/n,n) for n in nn]+[(D/n,n) for n in aux]);info['remote_archive_commit']=publish_archive(k,'C10-driver-archive',target,info,'DRIVER_ARCHIVE.json');archives[k]=info
scratch={}
def cleanup(k,SH,prior,patches,table_hashes,binary_path,binary_archive,binary_sha,build_prefix):
 D=repos[k]/scopes[k]
 if not SH.exists():return dict(status='NOT_CREATED')
 assert SH.is_dir() and not SH.is_symlink() and SH.resolve()==SH
 if not binary_sha or not (SH/binary_path).is_file() or not (D/binary_archive).is_file():
  return dict(status='PRESERVED_INCOMPLETE_BUILD',path=str(SH))
 assert hashfile(SH/binary_path)==binary_sha==sha(gzip.decompress(blob(k,scopes[k]+'/'+binary_archive)))
 known=[];unique=[];build_n=build_bytes=0
 for p in sorted(SH.rglob('*')):
  assert not p.is_symlink(),str(p)
  if not p.is_file():continue
  rel=p.relative_to(SH);r=str(rel)
  if rel.parts[:len(build_prefix)]==build_prefix:
   build_n+=1;build_bytes+=p.stat().st_size;continue
  h=hashfile(p);kind=None
  if prior.get(r)==h:kind='pinned original source'
  elif r in patches:
   dest,want=patches[r];assert h==want
   if dest:published(k,dest,h)
   kind='verified published patched source'
  elif r in table_hashes:
   assert h==table_hashes[r];kind='verified generated stage table receipt'
  elif len(rel.parts)==2:
   dst=rel.parts[0]+'_'+rel.parts[1]
   if (D/dst).is_file() and hashfile(D/dst)==h:published(k,dst,h);kind='published actual native output'
  if kind:known.append(dict(path=r,sha=h,bytes=p.stat().st_size,kind=kind))
  else:unique.append((p,r))
 info=dict(known=known,build_files=build_n,build_bytes=build_bytes,exact_binary_sha=binary_sha);fs=['SHADOW_MANIFEST.json']
 if unique:
  target=D/'NATIVE_SHADOW_UNIQUE.tar.gz';info['unique']=archive(target,unique);fs.append(target.name)
 (D/'SHADOW_MANIFEST.json').write_text(json.dumps(info,indent=2)+'\n');record(k,'C10-shadow-verified','Exact source, patched files, run outputs and native binary checked. Unique files archived before removing scratch.',fs)
 if unique:published(k,target.name,info['unique']['archive_sha256'])
 published(k,'SHADOW_MANIFEST.json',hashfile(D/'SHADOW_MANIFEST.json'))
 nfiles=sum(1 for p in SH.rglob('*') if p.is_file());nbytes=sum(p.stat().st_size for p in SH.rglob('*') if p.is_file());assert nfiles==len(known)+len(unique)+build_n
 shutil.rmtree(SH);assert not SH.exists();return dict(status='REMOVED_VERIFIED',files=nfiles,logical_bytes=nbytes,unique_count=len(unique),build_files=build_n)
# Single shared REI shadow. BASS replay binaries/source verified in BOTH owners.
F=E.parent/'r118c4f_external_stress';prev=load(F/'SHADOW_ARCHIVE.json');assert hashfile(F/'NATIVE_SHADOW_SOURCE.tar.gz')==prev['archive_sha256'];prior={x['name']:x['sha256'] for x in prev['members']};a=load(E/'BUILD_ID.json')
SH=H/'r118c4n_rei_shadow';assert a['prior_archive']==prev['archive_sha256']
for name,hs in a['bins'].items():
 assert hashfile(SH/'bridge/target/release'/name)==hs==sha(gzip.decompress(blob('REI',scopes['REI']+'/'+name+'.gz')))
assert a['bins']['c4n_bass']==sha(gzip.decompress(blob('BASS',scopes['BASS']+'/c4n_bass.gz')))
lc=summary['BASS']['codazzi_matched']
assert hashfile(SH/'bridge/target/release/c4n_bass_matched')==lc['binary_sha']==sha(gzip.decompress(blob('BASS',scopes['BASS']+'/c4n_bass_matched.gz')))
assert hashfile(SH/'bridge/src/bin/c4n_bass_matched.rs')==lc['source_sha']
published('BASS','lie_codazzi.rs',lc['source_sha'])
published('BASS','native.rs',a['changes']['bridge/src/bin/c4n_bass.rs']['sha'])
patch={n:(v['file'],v['sha']) for n,v in a['changes'].items()}
patch['bridge/src/bin/c4n_bass_matched.rs']=(None,lc['source_sha'])
scratch['REI']=cleanup('REI',SH,prior,patch,{},'bridge/target/release/c3x_dg_bridge','c3x_dg_bridge.gz',a['bins']['c3x_dg_bridge'],('bridge','target'))
assert scratch['REI']['status']=='REMOVED_VERIFIED'
removed=[]
for n in [n for nn in names.values() for n in nn]+common:
 p=H/n;assert p.is_file() and not p.is_symlink();removed.append(dict(path=str(p),bytes=p.stat().st_size,sha=hashfile(p)));p.unlink()
for p in (H/'__pycache__').glob('r118c4n_*.pyc'):
 if p.is_file() and not p.is_symlink():removed.append(dict(path=str(p),bytes=p.stat().st_size,cache=True));p.unlink()
prunes={}
for k in repos:
 prunes[k]=git(repos[k],'worktree','prune','--dry-run','--verbose')
 if not prunes[k]:git(repos[k],'worktree','prune')
 D=repos[k]/scopes[k];obj=dict(driver_archive=archives[k],prune_dry_run=prunes[k],prune_executed=not bool(prunes[k]),unrelated_preserved=True)
 if k=='BASS':obj.update(common_archive=common_info,common_remote=common_remote,removed_files=removed,shared_shadow='verified and removed in REI cleanup')
 if k in scratch:obj['scratch']=scratch[k]
 (D/'FINAL_CLEANUP.json').write_text(json.dumps(obj,indent=2)+'\n');record(k,'C10-cleanup','Verified scoped redundant drivers and scratch cleanup; unrelated data/worktrees preserved.',['FINAL_CLEANUP.json'])
for k in repos:
 p=H/f'r118c4n_{k.lower()}.lock'
 if p.is_file() and p.stat().st_size==0 and not p.is_symlink():p.unlink()
final={k:verify(k) for k in repos};out=dict(cycle='R118-C4N',time=datetime.datetime.now().astimezone().isoformat(),standard_stages=60,pushes=sum(x['pushes'] for x in final.values()),repos=final,science=summary,driver_archives=archives,common_archive=common_info,common_remote=common_remote,removed_files=len(removed),removed_bytes=sum(x['bytes'] for x in removed),scratch=scratch,prunes=prunes,native_subagents='NOT_RUN',full_production_regression='NOT_RUN',htt_base_mutation=False)
(H/'r118c4n_final_receipt_20261128.json').write_text(json.dumps(out,indent=2)+'\n');(H/'r118c4n_push_receipts_20261128.jsonl').write_text(''.join(json.dumps(x)+'\n' for k in repos for x in receipts(k)))
print(json.dumps(dict(pushes=out['pushes'],repos=final,removed_files=out['removed_files'],removed_bytes=out['removed_bytes'],scratch=scratch,prunes=prunes),indent=2),flush=True)
