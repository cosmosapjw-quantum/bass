from pathlib import Path
import sys,json,subprocess,hashlib,os,time,shutil,concurrent.futures as cf
H=Path.home();sys.path.insert(0,str(H));from r118c4n_theory import repos,scopes,base,git,record,notes
sources={'BASS':{'bass.py':'r118c4n_bass.py','native.rs':'r118c4n_bass_native.rs'},'REC':{'rec.py':'r118c4n_rec.py','event.py':'r118c4n_event.py','atomic.py':'r118c4n_atomic.py','feedback.py':'r118c4n_feedback.py'},'REI':{'rei.py':'r118c4n_rei.py','dg.py':'r118c4n_dg.py','clock.py':'r118c4n_clock.py'}}
def receipts(k):return [json.loads(s) for s in (H/f'r118c4n_{k.lower()}_push_receipts.jsonl').read_text().splitlines()]
def pre(k):
 D=repos[k]/scopes[k];assert [x['stage'] for x in receipts(k) if x['stage'].startswith('R')]==[f'R{i}' for i in range(1,11)]
 for i,n in enumerate([notes[k][0],notes[k][2],notes[k][4],notes[k][3]],1):record(k,f'C{i}',n)
 for dst,src in sources[k].items():
  shutil.copyfile(H/src,D/dst)
  if dst.endswith('.py'):compile((D/dst).read_text(),str(D/dst),'exec')
 record(k,'C5','Actual executable implementation. Runtime/scientific tests separate.',list(sources[k]))
def job(k,file,args,tag,timeout):
 D=repos[k]/scopes[k];env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 t=time.monotonic();cmd=[sys.executable,'-u',str(D/file),*map(str,args)]
 try:
  with (D/(tag+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
  result=dict(tag=tag,exit=r.returncode,seconds=time.monotonic()-t,command=cmd)
 except Exception as e:result=dict(tag=tag,error=repr(e),seconds=time.monotonic()-t,command=cmd)
 print(k,result,flush=True);return result
def save(k,rows):
 (repos[k]/scopes[k]/'EXECUTION.json').write_text(json.dumps(rows,indent=2)+'\n')
def finish(k):
 D=repos[k]/scopes[k];rows=json.loads((D/'EXECUTION.json').read_text())
 files=[p.name for p in D.iterdir() if p.is_file() and p.name not in sources[k] and p.name!='R7.json' and not (p.name[0] in 'RC' and p.suffix=='.md')]
 record(k,'C6','Actual executed commands and raw results; '+json.dumps(rows),sorted(set(files)))
 def j(n):
  p=D/n;return json.loads(p.read_text()) if p.exists() else None
 a,b={'BASS':('TABLE_REPLAY.json','LIE_NONLINEAR.json'),'REC':('EXACT_HISTORY.json','COUPLED_FEEDBACK.json'),'REI':('DG_JVP.json','LOCAL_COST.json')}[k];m,n=j(a),j(b)
 record(k,'C7','Main route measured result and bounds: '+json.dumps(m))
 record(k,'C8','Independent route measured result and bounds: '+json.dumps(n))
 (D/'FINAL_SCIENCE.json').write_text(json.dumps(dict(main=m,independent=n,execution=rows),indent=2)+'\n')
 record(k,'C9','Scope-specific verification. Native subagent and production regression NOT_RUN; preserve failures. '+json.dumps(rows),['FINAL_SCIENCE.json'])
 next_={'BASS':'Differentiate native SDIRK sky collision and live REI owner instead of table response; preserve actual replay. General Lie Codazzi consistency and longer controlled runs.','REC':'Differentiate gas-dependent atomic rates/table and diffusion, improve event/delay alignment and nonsteady temperature, full line-transfer feedback.','REI':'Moving-cut/geometry/theta DG JVP, positivity-projection and full stock/cooling/chemistry chain, optimize low-cost defect policy only where measured.'}[k]
 (D/'NEXT.md').write_text(next_+'\n');(D/'DAG.json').write_text(json.dumps(dict(cycle='R118-C4N',base=base[k],status='SCOPED_EXECUTED' if m is not None and n is not None else 'SCOPED_PARTIAL',main=a,independent=b,execution=rows,receipts=receipts(k),native_subagent='NOT_RUN',production_regression='NOT_RUN',htt_base_mutation=False,next=next_),indent=2)+'\n')
 record(k,'C10','Scoped disposition and exact next work. '+next_,['NEXT.md','DAG.json'])
if __name__=='__main__':
 mode=sys.argv[1];k=sys.argv[2]
 if mode=='pre':pre(k)
 elif mode=='finish':finish(k)
