from __future__ import annotations

import math

import pytest

from bass8b2a.electron_state_binding import (
    ComovingWithMatterSpecies,
    HashRef,
    IndependentElectronState,
    PlasmaIdentity,
    QHubbleTimeAuthority,
    SpeciesKinematicJet,
    VelocityEqualityProof,
    bind_electron_state,
)
from bianchi.q.electron_rate import (
    ElectronScheduleProvenance,
    PrescribedComovingElectronSchedule,
    PrescribedIndependentElectronSchedule,
)

H_A = "a" * 64
H_B = "b" * 64
H_C = "c" * 64
H_D = "d" * 64


def coordinate():
    return QHubbleTimeAuthority("exact-host-origin", HashRef("q-time", H_A))


def test_real_independent_schedule_view_is_consumed_without_owner_mutation():
    schedule = PrescribedIndependentElectronSchedule(
        [0.0, 1.0],
        [2.0, 3.0],
        [[0.1, -0.05, 0.02], [0.2, 0.03, -0.04]],
        provenance=ElectronScheduleProvenance("real-independent", H_D),
    )
    out = bind_electron_state(
        schedule,
        tau=0.4,
        coordinate=coordinate(),
        binding_provenance=HashRef("2a-binding", H_B),
    )
    assert isinstance(out.state, IndependentElectronState)
    assert out.jet is not None
    assert out.jet.proper_density_m3 > 0.0
    assert sum(value * value for value in out.jet.beta_normal) < 1.0


def test_real_comoving_schedule_requires_and_accepts_named_plasma_jet():
    schedule = PrescribedComovingElectronSchedule(
        [0.0, 1.0],
        [2.0, 4.0],
        provenance=ElectronScheduleProvenance("real-comoving", H_D),
    )
    coord = coordinate()
    species_id = "ionized-baryon-electron-plasma"
    species_jet = SpeciesKinematicJet(
        species_id=species_id,
        beta_normal=(0.1, -0.2, 0.05),
        dbeta_normal_dtau=(0.02, 0.01, -0.03),
        tau=0.25,
        coordinate_sha256=coord.payload_sha256,
        provenance=HashRef("live-species-jet", H_D),
    )
    identity = PlasmaIdentity(
        species_id,
        "cold-ionized-baryon-electron-plasma",
        HashRef("plasma-identity", H_A),
    )
    proof = VelocityEqualityProof(
        species_id,
        "u_e_equals_u_species",
        H_B,
        HashRef("velocity-equality", H_C),
    )
    out = bind_electron_state(
        schedule,
        tau=0.25,
        coordinate=coord,
        binding_provenance=HashRef("2a-binding", H_B),
        species_jet=species_jet,
        plasma_identity=identity,
        equality_proof=proof,
    )
    assert isinstance(out.state, ComovingWithMatterSpecies)
    assert out.jet is not None
    assert out.jet.proper_density_m3 == pytest.approx(2.5)
    assert out.jet.dproper_density_dtau == pytest.approx(2.0)
    assert out.jet.beta_normal == pytest.approx(species_jet.beta_normal)
    assert out.jet.dbeta_normal_dtau == pytest.approx(species_jet.dbeta_normal_dtau)


def test_real_independent_typeii_aligned_schedule_is_generic_restriction():
    schedule = PrescribedIndependentElectronSchedule(
        [0.0, 1.0],
        [2.0, 2.5],
        [[0.0, 0.1, 0.0], [0.0, 0.2, 0.0]],
        provenance=ElectronScheduleProvenance("real-typeii-restriction", H_D),
    )
    out = bind_electron_state(
        schedule,
        tau=0.5,
        coordinate=coordinate(),
        binding_provenance=HashRef("2a-binding", H_B),
    )
    assert out.jet is not None
    assert out.jet.beta_normal[0] == pytest.approx(0.0)
    assert out.jet.beta_normal[2] == pytest.approx(0.0)
    assert out.metadata["typeii_special_case_implemented"] is False
    assert math.isfinite(out.jet.dbeta_normal_dtau[1])
