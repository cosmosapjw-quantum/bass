from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
import math
import sys

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))

from bass8b2a.electron_state_binding import (  # noqa: E402
    CollisionOff,
    ComovingWithMatterSpecies,
    DerivativeSide,
    HashRef,
    IndependentElectronState,
    PlasmaIdentity,
    QHubbleTimeAuthority,
    SpeciesKinematicJet,
    VelocityEqualityProof,
    bind_electron_state,
)

H_A = "a" * 64
H_B = "b" * 64
H_C = "c" * 64
H_D = "d" * 64


@dataclass
class FakeSchedule:
    view: object
    payload_sha256: str

    def trajectory_view(self):
        return self.view


def coordinate() -> QHubbleTimeAuthority:
    return QHubbleTimeAuthority(
        origin_event="tau-origin",
        provenance=HashRef("q-time", H_A),
    )


def binding_ref() -> HashRef:
    return HashRef("binding", H_B)


def independent_schedule(nodes, currents, *, payload=H_C):
    view = SimpleNamespace(
        coordinate_kind="q_hubble_time_tau",
        nodes_ascending=tuple(float(x) for x in nodes),
        interpolation="linear_number_current_v1",
        number_current_nodes=tuple(tuple(float(v) for v in row) for row in currents),
        density_nodes_m3=None,
        source_id="independent-schedule",
        source_sha256=H_D,
        schedule_payload_sha256=payload,
        c_m_s=299_792_458.0,
    )
    return FakeSchedule(view=view, payload_sha256=payload)


def comoving_schedule(nodes, densities, *, payload=H_C):
    view = SimpleNamespace(
        coordinate_kind="q_hubble_time_tau",
        nodes_ascending=tuple(float(x) for x in nodes),
        interpolation="linear_proper_density_live_fluid_beta",
        number_current_nodes=None,
        density_nodes_m3=tuple(float(x) for x in densities),
        source_id="comoving-schedule",
        source_sha256=H_D,
        schedule_payload_sha256=payload,
        c_m_s=299_792_458.0,
    )
    return FakeSchedule(view=view, payload_sha256=payload)


def plasma_objects(species_id="ionized-baryon-electron-plasma"):
    identity = PlasmaIdentity(
        species_id=species_id,
        plasma_model="cold-ionized-baryon-electron-plasma",
        provenance=HashRef("plasma", H_A),
    )
    proof = VelocityEqualityProof(
        species_id=species_id,
        statement="u_e_equals_u_species",
        proof_sha256=H_B,
        authority=HashRef("closure-proof", H_C),
    )
    return identity, proof


def test_independent_constant_current_has_zero_segment_jet():
    n = 7.5
    beta = np.array([0.2, -0.1, 0.05])
    gamma = 1.0 / math.sqrt(1.0 - float(beta @ beta))
    current = n * np.concatenate(([gamma], gamma * beta))
    schedule = independent_schedule((0.0, 1.0), (current, current))

    out = bind_electron_state(
        schedule,
        tau=0.25,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    )

    assert isinstance(out.state, IndependentElectronState)
    assert out.jet is not None
    assert out.jet.proper_density_m3 == pytest.approx(n)
    assert out.jet.beta_normal == pytest.approx(tuple(beta))
    assert out.jet.dproper_density_dtau == pytest.approx(0.0)
    assert out.jet.dbeta_normal_dtau == pytest.approx((0.0, 0.0, 0.0))
    assert out.metadata["ad_jvp_certified"] is True
    assert out.metadata["generic_solver_jvp_certified"] is False


def test_generic_affine_current_matches_exact_quotient_formulas():
    left = np.array([5.0, 1.0, 0.5, -0.25])
    right = np.array([6.0, 1.8, 0.2, 0.4])
    schedule = independent_schedule((2.0, 5.0), (left, right))
    tau = 3.2

    out = bind_electron_state(
        schedule,
        tau=tau,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    )
    jet = out.jet
    assert jet is not None

    w = (tau - 2.0) / 3.0
    current = (1.0 - w) * left + w * right
    dcurrent = (right - left) / 3.0
    n = math.sqrt(current[0] ** 2 - float(current[1:] @ current[1:]))
    dn = (current[0] * dcurrent[0] - float(current[1:] @ dcurrent[1:])) / n
    beta = current[1:] / current[0]
    dbeta = (dcurrent[1:] * current[0] - current[1:] * dcurrent[0]) / current[0] ** 2

    assert jet.proper_density_m3 == pytest.approx(n, rel=2e-15)
    assert jet.dproper_density_dtau == pytest.approx(dn, rel=2e-15)
    assert jet.beta_normal == pytest.approx(tuple(beta), rel=2e-15)
    assert jet.dbeta_normal_dtau == pytest.approx(tuple(dbeta), rel=2e-15)


def test_null_or_spacelike_current_fails_closed():
    schedule = independent_schedule((0.0, 1.0), ((1.0, 1.0, 0.0, 0.0), (1.0, 1.0, 0.0, 0.0)))
    with pytest.raises(ValueError, match="future-timelike"):
        bind_electron_state(
            schedule,
            tau=0.5,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )


def test_exact_vacuum_returns_typed_collision_off_without_velocity():
    schedule = independent_schedule((0.0, 1.0), ((0.0, 0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 0.0)))
    out = bind_electron_state(
        schedule,
        tau=0.5,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    )
    assert isinstance(out.state, CollisionOff)
    assert out.state.kappa == 0.0
    assert out.state.beta_normal is None
    assert out.jet is None


def test_interior_knot_requires_explicit_side_and_sides_differ():
    currents = (
        (5.0, 0.5, 0.0, 0.0),
        (6.0, 1.0, 0.0, 0.0),
        (7.0, 2.0, 0.5, 0.0),
    )
    schedule = independent_schedule((0.0, 1.0, 2.0), currents)
    kwargs = dict(coordinate=coordinate(), binding_provenance=binding_ref())

    with pytest.raises(ValueError, match="explicit LEFT or RIGHT"):
        bind_electron_state(schedule, tau=1.0, **kwargs)

    left = bind_electron_state(schedule, tau=1.0, side=DerivativeSide.LEFT, **kwargs)
    right = bind_electron_state(schedule, tau=1.0, side=DerivativeSide.RIGHT, **kwargs)
    assert left.jet is not None and right.jet is not None
    assert left.jet.segment_index == 0
    assert right.jet.segment_index == 1
    assert left.jet.dbeta_normal_dtau != pytest.approx(right.jet.dbeta_normal_dtau)


def test_endpoint_side_policy_is_fail_closed():
    schedule = independent_schedule((0.0, 1.0), ((5.0, 0.0, 0.0, 0.0), (6.0, 1.0, 0.0, 0.0)))
    kwargs = dict(coordinate=coordinate(), binding_provenance=binding_ref())
    with pytest.raises(ValueError, match="RIGHT"):
        bind_electron_state(schedule, tau=0.0, side=DerivativeSide.LEFT, **kwargs)
    with pytest.raises(ValueError, match="LEFT"):
        bind_electron_state(schedule, tau=1.0, side=DerivativeSide.RIGHT, **kwargs)


def test_support_escape_is_rejected():
    schedule = independent_schedule((0.0, 1.0), ((5.0, 0.0, 0.0, 0.0), (5.0, 0.0, 0.0, 0.0)))
    with pytest.raises(ValueError, match="outside closed support"):
        bind_electron_state(
            schedule,
            tau=np.nextafter(1.0, np.inf),
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )


def test_comoving_branch_requires_identity_proof_and_species_jet():
    schedule = comoving_schedule((0.0, 1.0), (3.0, 4.0))
    with pytest.raises(ValueError, match="requires species_jet"):
        bind_electron_state(
            schedule,
            tau=0.4,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )


def test_comoving_branch_binds_species_identity_and_velocity_equality():
    schedule = comoving_schedule((0.0, 1.0), (3.0, 5.0))
    identity, proof = plasma_objects()
    species_jet = SpeciesKinematicJet(
        species_id=identity.species_id,
        beta_normal=(0.1, 0.2, -0.05),
        dbeta_normal_dtau=(0.01, -0.02, 0.03),
        tau=0.25,
        coordinate_sha256=coordinate().payload_sha256,
        provenance=HashRef("species-jet", H_D),
    )

    out = bind_electron_state(
        schedule,
        tau=0.25,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
        species_jet=species_jet,
        plasma_identity=identity,
        equality_proof=proof,
    )

    assert isinstance(out.state, ComovingWithMatterSpecies)
    assert out.state.species_id == identity.species_id
    assert out.jet is not None
    assert out.jet.proper_density_m3 == pytest.approx(3.5)
    assert out.jet.dproper_density_dtau == pytest.approx(2.0)
    assert out.jet.beta_normal == pytest.approx(species_jet.beta_normal)
    assert out.jet.dbeta_normal_dtau == pytest.approx(species_jet.dbeta_normal_dtau)


def test_comoving_species_mismatch_is_rejected():
    schedule = comoving_schedule((0.0, 1.0), (3.0, 5.0))
    identity, proof = plasma_objects("species-A")
    species_jet = SpeciesKinematicJet(
        species_id="species-B",
        beta_normal=(0.0, 0.0, 0.0),
        dbeta_normal_dtau=(0.0, 0.0, 0.0),
        tau=0.25,
        coordinate_sha256=coordinate().payload_sha256,
        provenance=HashRef("species-jet", H_D),
    )
    with pytest.raises(ValueError, match="species_id mismatch"):
        bind_electron_state(
            schedule,
            tau=0.25,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
            species_jet=species_jet,
            plasma_identity=identity,
            equality_proof=proof,
        )


def test_observer_or_generic_fluid_substitution_cannot_satisfy_proof_contract():
    schedule = comoving_schedule((0.0, 1.0), (3.0, 5.0))
    identity = PlasmaIdentity(
        species_id="ionized-plasma",
        plasma_model="generic-gamma-law-fluid",
        provenance=HashRef("wrong-model", H_A),
    )
    proof = VelocityEqualityProof(
        species_id="ionized-plasma",
        statement="observer_boost_equals_electron_velocity",
        proof_sha256=H_B,
        authority=HashRef("wrong-proof", H_C),
    )
    species_jet = SpeciesKinematicJet(
        species_id="ionized-plasma",
        beta_normal=(0.1, 0.0, 0.0),
        dbeta_normal_dtau=(0.0, 0.0, 0.0),
        tau=0.25,
        coordinate_sha256=coordinate().payload_sha256,
        provenance=HashRef("species-jet", H_D),
    )
    with pytest.raises(ValueError, match="u_e_equals_u_species"):
        bind_electron_state(
            schedule,
            tau=0.25,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
            species_jet=species_jet,
            plasma_identity=identity,
            equality_proof=proof,
        )


def test_proper_rotation_covariance_of_independent_state_jet():
    left = np.array([5.0, 0.5, 1.0, -0.25])
    right = np.array([6.0, 1.5, 0.5, 0.75])
    R = np.array([[0.0, -1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    assert np.linalg.det(R) == pytest.approx(1.0)

    base = bind_electron_state(
        independent_schedule((0.0, 1.0), (left, right)),
        tau=0.3,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    ).jet
    rotated_currents = [np.concatenate(([row[0]], R @ row[1:])) for row in (left, right)]
    rotated = bind_electron_state(
        independent_schedule((0.0, 1.0), rotated_currents),
        tau=0.3,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    ).jet

    assert base is not None and rotated is not None
    assert rotated.proper_density_m3 == pytest.approx(base.proper_density_m3)
    assert rotated.dproper_density_dtau == pytest.approx(base.dproper_density_dtau)
    assert rotated.beta_normal == pytest.approx(tuple(R @ np.asarray(base.beta_normal)))
    assert rotated.dbeta_normal_dtau == pytest.approx(tuple(R @ np.asarray(base.dbeta_normal_dtau)))


def test_typeii_aligned_path_is_only_a_restriction_of_generic_three_vector_schema():
    schedule = independent_schedule(
        (0.0, 1.0),
        ((5.0, 0.0, 1.0, 0.0), (6.0, 0.0, 2.0, 0.0)),
    )
    out = bind_electron_state(
        schedule,
        tau=0.4,
        coordinate=coordinate(),
        binding_provenance=binding_ref(),
    )
    assert isinstance(out.state, IndependentElectronState)
    assert out.jet is not None
    assert out.jet.beta_normal[0] == pytest.approx(0.0)
    assert out.jet.beta_normal[2] == pytest.approx(0.0)
    assert out.metadata["typeii_special_case_implemented"] is False
    assert out.metadata["generic_three_vector_schema"] is True


def test_schedule_payload_mismatch_is_rejected():
    schedule = independent_schedule((0.0, 1.0), ((5.0, 0.0, 0.0, 0.0), (5.0, 0.0, 0.0, 0.0)))
    schedule.payload_sha256 = H_D
    with pytest.raises(ValueError, match="payload"):
        bind_electron_state(
            schedule,
            tau=0.5,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )


def test_non_q_coordinate_and_unknown_interpolation_are_rejected():
    schedule = independent_schedule((0.0, 1.0), ((5.0, 0.0, 0.0, 0.0), (5.0, 0.0, 0.0, 0.0)))
    schedule.view.coordinate_kind = "conformal_time"
    with pytest.raises(ValueError, match="q_hubble_time_tau"):
        bind_electron_state(
            schedule,
            tau=0.5,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )

    schedule = independent_schedule((0.0, 1.0), ((5.0, 0.0, 0.0, 0.0), (5.0, 0.0, 0.0, 0.0)))
    schedule.view.interpolation = "cubic_spline"
    with pytest.raises(ValueError, match="unsupported interpolation"):
        bind_electron_state(
            schedule,
            tau=0.5,
            coordinate=coordinate(),
            binding_provenance=binding_ref(),
        )
