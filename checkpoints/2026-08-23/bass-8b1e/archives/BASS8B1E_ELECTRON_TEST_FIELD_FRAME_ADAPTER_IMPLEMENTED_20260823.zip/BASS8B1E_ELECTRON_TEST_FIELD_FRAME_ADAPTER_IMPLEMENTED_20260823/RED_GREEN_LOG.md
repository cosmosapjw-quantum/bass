# Recorded red/green evidence

## Cycle 1 — requested public seam

Command, before production source existed:

```bash
python tests/test_electron_test_field.py
```

```text
exit 1
AssertionError: RED: bianchi.q.electron state/frame adapter has not been implemented
```

After the first bounded implementation, the identical command returned:

```text
7 tests, OK, exit 0
```

## Cycle 2 — existing single-boost parity

A new exact compatibility test failed because an identity zero-velocity screen
stage performed an unnecessary re-projection before the existing single boost.

```text
1 failure: transformed polarization was not bitwise equal to boost_shape
```

The implementation now skips exactly zero source/target stages.  Same command:

```text
10 tests, OK, exit 0
```

## Cycle 3 — independent review: forged comoving closure

Reviewer reproduction:

```text
closure             comoving-electron
is_comoving_zero    false
Gamma_ef            1.0910894511799618
matrix_is_identity  false
```

Negative tests were added first and produced ten failures: public label
forgery plus all nine inconsistent relational/forward/inverse calls.  After
making the label factory-only and enforcing exact fluid-beta equality:

```text
12 tests, OK, exit 0
```

## Cycle 4 — density unit

The legacy rate survey exposed `cm^-3` while the new explicit `c` boundary is
SI.  A test requiring an immutable `m^-3` unit failed with `AttributeError`.
After adding state/schema/docs metadata:

```text
13 tests, OK, exit 0
```

The thirteenth test also commits the previously external circular-polarization
antisymmetric-carrier regression.

