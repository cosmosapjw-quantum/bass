# BASS-8B.1E electron test-field frame adapter

```text
STATUS                 IMPLEMENTED_BOUNDED
INDEPENDENT_VERDICT    PARTIALLY_CONFIRMED
OPEN_BOUNDED_FINDINGS  0
CANONICAL_PROMOTION    NO
```

This checkpoint implements the user-selected
`H2_WITH_COMOVING_RESTRICTION` model:

- independent cold-electron test-field state;
- exact `u_e=u_fluid` comoving restriction;
- reversible fluid-frame ↔ electron-frame photon transformation;
- basis-free normalized polarization-screen transformation;
- exact Mode-A `D^4` intensity and `D^-2` angular-weight mapping;
- explicit SI `c` and proper-density unit `m^-3`;
- no Einstein/background backreaction.

The qualifier `PARTIALLY_CONFIRMED` records an environment boundary, not an
open focused defect: the source host lacks the repository's installed
JAX/Rust/pytest stack, so the complete package suite was not run.  The
self-contained NumPy gate, direct 4-vector/screen oracle, prior P9 screen audit,
JSON parser, and Python compiler all pass.

Start with:

- `docs/ELECTRON-TEST-FIELD-CONTRACT.md`
- `VERIFICATION_REPORT.md`
- `NEXT_ACTION.md`
- `RUNBOOK.md`

