# Verification report

## Outcome

The bounded state/frame-adapter specification is implemented and has no open
focused implementation finding.  Independent verdict:

```text
PARTIALLY_CONFIRMED
```

The qualifier is solely the unavailable full installed-package/JAX/Rust
integration on this host.

## Implemented source

```text
f5fa2da696453ea0b11cfddeb7f824cd1bdb42596cd4e2947fb7841e1387aafe
  bianchi/q/electron.py

5e3e5f9a8abe8c439871dceba37a033bbf26fb6150dbeec9e35d44d0f91c4a4e
  tests/test_electron_test_field.py

e1e94a40138d2dd74fcab8f62401d523d101db377299ca645890e1f863281f6a
  audit/electron_frame_adapter.py
```

## Fresh focused gate

Command:

```bash
python tests/test_electron_test_field.py
```

Result:

```text
Ran 13 tests
OK
exit 0
```

Coverage:

- invalid density/velocity rejection;
- independent state and factory-only comoving restriction;
- rejection of forged comoving labels and mismatched later fluid frames;
- explicit-`c` four-velocity normalization;
- immutable SI proper-density unit;
- Lorentz metric preservation and inverse;
- non-collinear ordered composition versus forbidden naive subtraction;
- existing single-boost photon/polarization bitwise parity;
- photon positive energy, nullness, and round trip;
- symmetric PSD coherency screen/trace/round trip;
- antisymmetric circular-polarization carrier round trip and norm;
- Mode-A `D^4`/`D^-2` forward/inverse mapping;
- exact comoving bitwise identity;
- machine-readable no-backreaction/non-promotion boundary.

## Hostile direct oracle

Independent construction: full Lorentz 4-matrix, photon four-vector, and
gauge-restored screen representatives.  Sample: 1,000 random source/target
velocities, each up to `0.85c`.

```text
metric                         8.216e-15
inverse                        8.216e-15
relative gamma                 8.882e-16
photon direction               3.803e-15
photon energy                  1.776e-15
photon round trip              1.665e-15
polarization direct parity     3.136e-15
polarization round trip        9.992e-16
screen leak                    1.639e-16
trace                          2.220e-16
spatial-block asymmetry        1.619
```

The large last value proves the sample included genuinely non-collinear
spatial/Wigner rotation rather than only pure/collinear boosts.

## Existing independent audit

Command:

```bash
python audit/p9_boost_screen.py
```

Result:

```text
scale       4.441e-16
anisotropy  6.661e-16
psi         6.667e-16
round trip  7.772e-16
leak        1.657e-15
exit 0
```

This `psi=0` statement applies to the canonical transported screen map for one
pure boost.  The two-frame adapter retains the non-collinear composition's
spatial rotation; it does not claim arbitrary global Stokes bases have zero
Wigner phase.

## Independent review history

The reviewer found one medium API semantic defect: a caller could forge the
`comoving-electron` label and later pass a different fluid velocity.  The issue
was independently reproduced at `Gamma_ef=1.091089...`; negative tests failed
before repair.  The final implementation makes the label factory-only and
checks exact velocity equality on every relational/forward/inverse comoving
operation.  Two low findings were also closed: density unit is immutable SI
`m^-3`, and circular-polarization coverage is committed.

Updated review: no open Critical, High, Medium, or Low bounded finding.

## Not verified / not claimed

- full locked Python suite (`1682` expected) and Rust suite (`122` expected);
- normal installed-package import with JAX/Rust extension;
- direction-dependent normal-time collision rate `n_e* sigma_T c D`;
- density schedule/provenance and legacy `cm^-3` conversion wiring;
- `n_e=0` runtime collision no-op and vacuum quotient;
- residual-`U(1)` quotient descent/global Stokes basis;
- finite-`l_max` closure under a finite boost;
- `Collision.v_b`, Rust ABI, solver/runtime wiring;
- OD001–OD004 receipt, row 7/8, release promotion.

No branch, commit, PR, Jira, Confluence, or other external write was made.

