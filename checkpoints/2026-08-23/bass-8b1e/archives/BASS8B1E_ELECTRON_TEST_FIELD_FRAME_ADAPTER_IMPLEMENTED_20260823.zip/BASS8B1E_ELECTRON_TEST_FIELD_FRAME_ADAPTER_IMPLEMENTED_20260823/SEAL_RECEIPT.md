# Seal receipt

The first complete archive candidate was verified before this receipt/state-only
reseal.

```text
candidate SHA-256
0e36bfaf215312cbde61b99a073cb71425eec13d1b7f8475ceea8b8f3f6f3a34

unzip CRC                         PASS
internal MANIFEST.sha256          PASS
clean extracted focused gate      13/13 PASS
clean extracted P9 audit          PASS
contract/source JSON parse        PASS
```

The final ZIP hash cannot be embedded inside itself without a circular digest.
It is therefore owned by the adjacent external `.zip.sha256` sidecar.  Final
verification must check that sidecar, ZIP CRC, this internal manifest, and an
extracted focused rerun.

Generated `__pycache__` and `.pyc` files are intentionally excluded.
