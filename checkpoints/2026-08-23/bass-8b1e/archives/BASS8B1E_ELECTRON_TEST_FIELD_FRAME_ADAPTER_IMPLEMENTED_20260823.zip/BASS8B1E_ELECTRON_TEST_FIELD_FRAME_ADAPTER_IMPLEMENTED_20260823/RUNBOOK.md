# Focused runbook

The checkpoint is self-contained for its NumPy-only bounded gate.

```bash
python tests/test_electron_test_field.py
python audit/p9_boost_screen.py
python -m json.tool docs/electron-test-field-contract.json >/dev/null
python -m py_compile \
  bianchi/q/electron.py \
  audit/electron_frame_adapter.py \
  tests/test_electron_test_field.py
```

Expected:

```text
13 tests, OK
P9 audit exit 0
JSON exit 0
py_compile exit 0
```

The test falls back to isolated NumPy module loading when JAX is absent and
restores `sys.modules` afterward.  In a restored full repository, run the
locked bootstrap/full suites as an additional integration gate; do not infer
their result from this focused checkpoint.

