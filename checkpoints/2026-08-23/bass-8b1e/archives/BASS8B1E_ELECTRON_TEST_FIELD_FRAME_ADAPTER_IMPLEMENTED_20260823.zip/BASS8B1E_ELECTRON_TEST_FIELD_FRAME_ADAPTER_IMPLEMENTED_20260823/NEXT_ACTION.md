# Next single gated task

```text
BASS-8B.1E.2 — electron collision-context relative-flux and vacuum/schedule authority
```

## Objective

Close exactly the collision-rate and prescribed-input boundary left open by
this frame adapter, without wiring the production loop or promoting row 7.

## Required owner decisions

1. Select the time-dependent `n_e*`/`beta_e` schedule provenance and
   interpolation contract.
2. Select the vacuum behavior:
   - `n_e*=0` collision-off and electron velocity quotiented;
   - retain an explicit fluid representative;
   - or declare the comoving restriction undefined on the vacuum stratum.
3. Fix the conversion boundary between this SI `m^-3` state and the legacy
   history/rate lane's `cm^-3` values.

## One formula to implement and audit

For a fluid-frame ray,

\[
\frac{d\tau_T}{dt_f}
=n_e^\star\sigma_TcD_{e\leftarrow f}(\mathbf e_f)
=-\frac{n_e^\star\sigma_T}{c}\,u_e\!\cdot\frac{dx}{dt_f}.
\]

For the project's Hubble time variable, divide by the selected physical
`H_t` exactly once.  Energy remap, `D^4`, `D^-2`, and rate `D` must remain
separate named factors.

## Acceptance gates

- covariant scalar and frame-component rate agree;
- comoving limit gives `D=1` in the fluid frame;
- `n_e*=0` is an exact collision no-op for all electron velocities;
- explicit `m^-3` ↔ `cm^-3` conversion parity with `q/rate.py`;
- mutation omitting `D` fails;
- mutation applying `D` twice fails;
- no double `Gamma` from observer density plus proper density;
- prescribed schedule rejects missing provenance/out-of-support calls;
- cold-Thomson validity domain is surfaced, not silently assumed;
- independent review and full-stack test environment before runtime wiring.

## Stop boundary

Do not modify `Collision.v_b`, Rust ABI, solver loops, finite-`l` production
carrier, projector/classifier, branch, commit, or PR in this task.  After this
rate gate, the next separate authority node is residual-`U(1)` quotient descent.

