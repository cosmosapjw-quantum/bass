# BASS-8B.1 applicability and quotient decision

## Verdict

`BLOCKED_MODEL_OWNER_DECISION_REQUIRED`

No current, explicit, hash-bound project authority selects exactly one of the three physically inequivalent row-7 applicability models:

1. **H1 — comoving closure:** `u_e = u_A4` plus a complete proper-free-electron-density map.
2. **H2 — independent electron field:** retain independent electron velocity/density data with declared evolution and coupling policy.
3. **H3 — sector exclusion:** set `exact_electron_frame_thomson = false` for this release/lane and do not claim Thomson row-7 authority.

The evidence therefore supports H4 (unresolved owner choice). This phase does not select a model, construct an adapter, or promote row 7.

## Decisive internal authority

- Source bundle SHA-256: `79c36566c958cc260adf82a2795a992fe7723c9d37611ab7b8d94de73fe831fa`.
- `contracts/owner_decisions.json` SHA-256: `c1d00d6d2a6ca6ce01215e6ccb5035605b9248880c7e093eded6f8dc9e1d24a8`.
- OD002 is `PENDING_OWNER`, its `value` is `null`, `all_resolved` is false, and `owner_receipt` is null.
- The recommended profile has `exact_electron_frame_thomson:false`, but `docs/OWNER_DECISIONS_REQUIRED.md` requires a hash-bound explicit receipt for every resolved value. A recommendation is not an approval.
- `state/claims.json` keeps the exact-electron-frame claim `LOCKED_PENDING_EVIDENCE`; `state/gates.json` keeps its parent gate blocked.
- Jira BASS-8 and canonical Confluence both explicitly say the owner must choose one of H1/H2/H3; no later connected-corpus approval was found.

## Decisive physical boundary

Primary sources make the alternatives non-interchangeable. Cold Thomson scattering depends on the electron four-velocity and proper free-electron density. A different electron velocity changes Doppler/aberration and the collision operator. A fluid energy density and tilt do not by themselves determine free-electron density; a composition/ionization map is required. Polarization also carries a spin-2 screen-basis action, so continuum covariance does not by itself prove descent through the project's residual Bianchi `U(1)` quotient.

Public physics restricts admissible models but cannot choose private release scope. Accordingly, exact algebra would be testing an invented assumption until an owner receipt selects H1, H2, or H3.

## Gate state

```text
BASS-8B.1 applicability selector    BLOCKED_MODEL_OWNER_DECISION_REQUIRED
BASS-8 row 7                       NOT PROMOTED
BASS-8 row 8                       DO_NOT_START
BASS-3 / classifier / runtime      BLOCKED
solver / branch / commit / PR      DO_NOT_START
```

## Non-claims

- The recommended H3-like profile is not treated as current authority.
- The background `U(1)` quotient is not treated as proof of radiation spin-2 quotient descent.
- Collision-off equality at `n_e^free sigma_T = 0` is not treated as global equivalence of H1/H2/H3.
- No Wolfram or special-function calculation was run: the blocking variable is an unresolved model selector, and the governing evidence contains no special function whose evaluation could resolve it.
