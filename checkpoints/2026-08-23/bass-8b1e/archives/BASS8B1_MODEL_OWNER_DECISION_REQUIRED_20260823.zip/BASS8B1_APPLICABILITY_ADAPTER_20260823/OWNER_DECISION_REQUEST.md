# Owner decision request — BASS-8B.1 / OD002 row-7 applicability

## Required action

The model owner must approve **exactly one** selection, bind it to the source/decision snapshot hashes, and sign the scope. Silence, a recommended profile, or a code-local default is not a decision.

Before that selection can become canonical authority, choose one receipt route:

1. resolve OD001–OD004 together under the existing `bass.owner_decision_receipt/v1`, whose canonical template lists all four decision IDs; or
2. first approve an authoritative schema amendment that explicitly permits an OD002-only partial receipt.

A row-7 request cannot silently weaken the existing canonical receipt schema.

### H1 — comoving electron closure

Approve all of the following:

- `exact_electron_frame_thomson = true` in OD002.
- Exact identity and normalization of `u_e = u_A4`, under project signature `(-,+,+,+)` and explicit `c`.
- A dimensionally complete map `n_e^free = F(rho_A4, composition, x_e, constants)` with an unambiguous convention for whether `x_e` is already included.
- Cold-electron scope, or the additional temperature/distribution data for a non-cold model.
- Active, vacuum, and zero-opacity strata; in particular the meaning at `rho_A4=0` and/or `n_e^free=0`.
- Radiation screen representation and residual-`U(1)` scope choice. This owner choice does not prove equivariance, quotient descent, or the tangent rule modulo gauge; those require downstream hash-bound technical authority and exact verification.

Downstream node after approval: `BASS-8B.1A — exact A.4-to-M8 comoving adapter plus separate radiation equivariance, quotient-descent, and tangent proofs`.

### H2 — independent electron test/dynamical field

Approve all of the following:

- `exact_electron_frame_thomson = true` in OD002.
- State carrier and domain for independent `(u_e,n_e^free)` and, where applicable, `x_e`, composition, and `T_e`/electron distribution.
- Evolution, algebraic constraints, initial data, conservation/current closure, and backreaction policy.
- Whether the field is prescribed, test-field, or dynamically coupled.
- Embedding/restriction that recovers H1, plus vacuum and zero-opacity strata.
- Radiation screen representation and residual-`U(1)` scope choice. This owner choice does not prove equivariance, quotient descent, or the tangent rule modulo gauge; those require downstream hash-bound technical authority and exact verification.

H2 cannot be represented as a function on the current A.4 seven-dimensional background state until this extension is authorized. Downstream node after approval: `BASS-8B.1E — electron-state extension authority`; only after it closes may an M8 adapter be tested.

### H3 — release/lane sector exclusion

Approve all of the following:

- `exact_electron_frame_thomson = false` in OD002 for the named release/lane.
- Dependency-consistent values for recombination and reionization; under the current OD002 rules both must be false when exact electron-frame Thomson is false.
- An explicit statement that row-7 Thomson authority is **not claimed** for this release/lane.
- Scope and supersession language explaining what is excluded and what future decision may re-enable it.

H3 does not promote row 7. It changes the applicable release scope. Downstream node after approval: `BASS-8B.1S — sector-scope and supersession re-adjudication`.

## Receipt fields

Use `OWNER_DECISION_TEMPLATE.json` as a decision-request payload. It is deliberately marked `template_is_not_authority:true`. Under the current canonical `bass.owner_decision_receipt/v1`, the completed selection and nine-key OD002 map must be incorporated into an OD001–OD004 snapshot and receipt; otherwise an authoritative partial-receipt schema amendment must precede the receipt. Required fields are:

- decision/request ID and the chosen canonical receipt route;
- owner identity, explicit confirmation, confirmation method/evidence, and actual signature;
- issued timestamp;
- source-bundle SHA-256, OD002 input snapshot SHA-256, and completed owner-decisions snapshot SHA-256;
- exactly one selection `H1`, `H2`, or `H3`;
- the complete nine-key OD002 boolean map and all dependency checks;
- complete selection-specific payload;
- release/lane scope;
- rationale and supersession policy;
- explicit statement that the receipt grants no code read/write/build/execute/install authority;
- independent canonical-receipt hash readback.

The receipt should be independently read back before any exact adapter calculation begins. The receipt selects model/representation scope only; it does not count as the later technical proof of radiation `U(1)` equivariance, quotient descent, or `dP|ker(DC)`.
