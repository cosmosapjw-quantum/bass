# Primary-source audit

## Result

`SOURCE_BACKED__OWNER_SELECTION_STILL_REQUIRED`

The primary literature proves that the three candidate models are generally inequivalent and identifies their minimum data. It does not select private BASS release policy.

## Electron-frame collision data

- A. Challinor, *Microwave background polarization in cosmological models*, arXiv:astro-ph/9911481, Eqs. (2.21)–(2.24), (3.7)–(3.10), (3.14): the exact Thomson tensor is written in the electron rest frame and depends on proper free-electron density. Boosting introduces explicit Doppler/aberration factors. <https://arxiv.org/pdf/astro-ph/9911481>
- M. Beneke and C. Fidler, arXiv:1003.1834, Eqs. (91), (92), (98), (140): the local electron distribution is parameterized by electron density, temperature, and bulk velocity; the free-electron density includes ionization information; opacity contains `n_e sigma_T a`. <https://arxiv.org/pdf/1003.1834>
- K. Takahashi et al., arXiv:astro-ph/0502283, Eqs. (7), (15)–(18): electron, proton, and photon fluids have distinct velocities, and Thomson momentum transfer/current depend on relative velocities. A comoving identification is therefore a closure valid only under declared conditions. <https://arxiv.org/pdf/astro-ph/0502283>
- C. Pitrou, arXiv:0809.3036, Eqs. (6.1), (6.7), §6.3 and Eq. (7.60): the general collision tensor depends on the electron distribution; a cold bulk delta distribution is an additional restriction, while opacity requires a free-electron/ionization convention. <https://arxiv.org/pdf/0809.3036>

## Radiation screen and quotient

- Pitrou Eqs. (1.5), (1.10), (1.46) and Challinor Eqs. (2.23)–(2.25) require screen projection when observer/frame changes.
- M. Zaldarriaga and U. Seljak, arXiv:astro-ph/9609170, Eqs. (1)–(2), give `(Q +/- iU)' = exp(-/+ 2 i psi)(Q +/- iU)`. Thus linear polarization is a spin-2 screen representation. <https://arxiv.org/pdf/astro-ph/9609170>

Inference: a project collision/projector may descend to the residual Bianchi `U(1)` quotient only after the finite carrier action and equivariance are explicitly bound. Continuum tensor covariance is necessary context, not a verification of the private A.3/A.4 quotient edge.

## Convention cautions

- Challinor uses signature `(+,-,-,-)` and the project uses `(-,+,+,+)`.
- The cited papers commonly set `c=1`; any selected adapter must restore and dimension-check explicit `c`.
- Literature notation varies between `n_e` already meaning free-electron density and a convention that multiplies an available-electron density by `x_e`. The project must choose exactly one convention.
- A non-cold electron model requires `T_e` or the full electron distribution in addition to `(u_e,n_e^free)`.

## Model comparison

- **H1:** a constrained submodel of H2 requiring velocity identity and a density/composition/ionization map.
- **H2:** adds independent state data and potentially new dynamics/constraints.
- **H3:** removes the Thomson operator from the applicable lane; it matches H1/H2 only on special collision-off/kernel strata, not globally.
