#!/usr/bin/env bash
set -euo pipefail

checkpoint_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$checkpoint_dir"

sha256sum -c MANIFEST.sha256
jq empty OWNER_DECISION_TEMPLATE.json RESULT.json
jq -e '
  (.template_is_not_authority == true) and
  (.canonical_receipt_schema_required == "bass.owner_decision_receipt/v1") and
  (.allowed_canonical_resolution_routes | length == 2) and
  (.canonical_decision_ids_required_under_existing_v1 == ["OD001", "OD002", "OD003", "OD004"]) and
  (.allowed_selections | length == 3) and
  (.od002_value | keys | length == 9) and
  (.authority_binding | has("completed_owner_decisions_snapshot_sha256")) and
  (.selection == null)
' OWNER_DECISION_TEMPLATE.json >/dev/null
jq -e '
  (.verdict == "BLOCKED_MODEL_OWNER_DECISION_REQUIRED") and
  (.selected_model == null) and
  (.gates.row7_promoted == false) and
  (.gates.row8_may_start == false) and
  (.gates.classifier_runtime_may_start == false)
' RESULT.json >/dev/null

printf '%s\n' 'BASS-8B.1 checkpoint verification: PASS'
