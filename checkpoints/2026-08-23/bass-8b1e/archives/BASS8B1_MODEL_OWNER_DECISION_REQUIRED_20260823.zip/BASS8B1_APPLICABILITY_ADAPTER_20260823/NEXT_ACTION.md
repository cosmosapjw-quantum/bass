# Next single action

`BASS-8B.1D — canonical owner-receipt route and OD002 row-7 selection`

## Owner action only

1. Choose the canonical receipt route: resolve OD001–OD004 together under v1, or first authorize an OD002-partial-receipt schema amendment.
2. Read `OWNER_DECISION_REQUEST.md` and fill `OWNER_DECISION_TEMPLATE.json`.
3. Select exactly one of H1, H2, or H3.
4. Complete the full nine-key OD002 boolean map and bind the decision to the recorded source-bundle, OD002 input snapshot, and completed owner-decisions snapshot hashes.
5. Supply all selection-specific fields, scope, rationale, timestamp, owner identity, confirmation method/evidence, and actual signature.
6. Incorporate the request into the approved canonical receipt flow; the template alone is not authority.
7. Record the hash-bound receipt in the canonical authority location.
8. Read it back independently, verify the canonical receipt hash, and check OD002 dependency rules.

## Branch after verified receipt

- H1 -> `BASS-8B.1A`, exact A.4-to-M8 comoving adapter plus separate radiation equivariance/quotient/tangent proofs.
- H2 -> `BASS-8B.1E`, electron-state extension authority before any M8 adapter.
- H3 -> `BASS-8B.1S`, sector-scope/supersession re-adjudication; row 7 remains unpromoted and out of scope.

Until the receipt exists and passes readback, do not run adapter algebra, promote row 7, start row 8, or touch classifier, solver, runtime, branch, commit, or PR work. Even after receipt, do not treat the owner signature itself as the technical radiation-quotient proof.
