# Inner seal receipt

Date: 2026-08-23

## Pre-seal commands

```text
find . -maxdepth 1 -type f ! -name MANIFEST.sha256 -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > MANIFEST.sha256
sha256sum -c MANIFEST.sha256
./verify_checkpoint.sh
```

## Result

```text
14/14 non-manifest members: OK
OWNER_DECISION_TEMPLATE.json: valid and structural assertions PASS
RESULT.json: valid and blocker/gate assertions PASS
BASS-8B.1 checkpoint verification: PASS
```

The final archive's SHA-256, ZIP CRC, and extracted-manifest result are stored in the adjacent sidecar and post-seal verification receipt; the outer hash cannot be embedded in the archive without self-reference.
