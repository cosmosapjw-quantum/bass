# Independent verdict

## Initial verdict

`PARTIALLY_CONFIRMED`

The fresh read-only verifier reproduced the decisive source/member hashes, OD002 pending/null state, locked claim/gate state, prior checkpoint SHA/CRC/51-member manifest, and the absence of an owner-approved A.4 binding in `bianchireview87`. It found no overlooked H1/H2/H3 selector or complete adapter authority. Thus the blocker verdict is confirmed.

## Mandatory contract corrections found

1. Existing `bass.owner_decision_receipt/v1` lists OD001–OD004, so a row-7 request must either resolve all four under v1 or first obtain an authoritative OD002-partial-receipt schema amendment.
2. The request needed an explicit completed owner-decisions snapshot hash field corresponding to canonical `decision_snapshot_sha256`.
3. An owner receipt may choose model/representation scope but cannot itself prove radiation `U(1)` equivariance, quotient descent, or the projector tangent identity.
4. Placeholder confirmation text and empty signatures are not an approval; identity, time, method/evidence, actual signature, hash binding, and independent readback are required.

All four corrections were applied to the request/template/next-action documents after the initial verdict. A narrow verifier readback was requested before sealing.

## Correction readback

`CONFIRMED`

The same verifier re-opened the current files and confirmed that all four mandatory corrections are accurately applied. It found no remaining material contract defect in the bounded readback.
