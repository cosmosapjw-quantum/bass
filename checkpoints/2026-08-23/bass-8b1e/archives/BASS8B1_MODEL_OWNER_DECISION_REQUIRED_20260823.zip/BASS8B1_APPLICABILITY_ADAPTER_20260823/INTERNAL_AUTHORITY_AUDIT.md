# Internal authority audit

## Bounded corpus

- Prior BASS-8B row-7 checkpoint, outer SHA-256 `2427b5ada26e2c791ea4faa4d64d6d65c9189713a883dcbc07908426181c9f8a`; outer sidecar, ZIP CRC, and 51-member internal manifest verified.
- `BASS_v1_BACKGROUND_HIGHL_HARNESS_PROJECT_SOURCE_BUNDLE_20260803(1).zip`, local normalized filename `14-BASS_v1_BACKGROUND_HIGHL_HARNESS_PROJECT_SOURCE_BUNDLE_20260803-1-.zip`, SHA-256 `79c36566c958cc260adf82a2795a992fe7723c9d37611ab7b8d94de73fe831fa`.
- `bianchireview87.tar(1).gz` and supplied text/source archives, searched for electron/background identity, OD002, global tilt, Thomson scope, quotient, approval, and supersession terms.

## Decisive records

| Record | SHA-256 | Observation |
|---|---|---|
| `contracts/owner_decisions.json` | `c1d00d6d2a6ca6ce01215e6ccb5035605b9248880c7e093eded6f8dc9e1d24a8` | OD002 `PENDING_OWNER`, `value:null`; `all_resolved:false`; `owner_receipt:null` |
| `docs/OWNER_DECISIONS_REQUIRED.md` | `b01d85849b2f31d2b65f2eaeb7376f2b81301c6dc339e172b42641730699ceb1` | recommended profile is only a starting profile; all resolutions require explicit hash-bound owner receipt |
| `contracts/scientific_contract.json` | `a4dbbdf3acbb0e43b47c387f1662b9cd2c132952ae834f6884daf338821974da` | defines exact-electron-frame sector and binds it to `G-C6-THOMSON` |
| `state/claims.json` | `ef6de7ea3e4c24700c1d7b71ff359e481f50d8609aed0dea5227b44a60bad226` | exact-electron-frame claim is `LOCKED_PENDING_EVIDENCE`, value null |
| `state/gates.json` | `e1c8bef4bde20f2a17ff6c57eb90252de64b5c6a604127bb2229a4858b30720f` | parent gate remains `BLOCKED` |
| `templates/owner_decision_receipt.json` | `bd4790109ef398833b21bba98c54df7f1c327a16e66a08e193a0ddb21d74fde1` | requires owner identity/confirmation and decision snapshot hash |
| `contracts/scope_lock.json` | `db55b1c050a49ea1a67721788b290abccb8ea44047dc9289c2212a97c4f9a628` | phase remains `USER_SCOPE_CONFIRMATION` |

OD002's recommended value sets `exact_electron_frame_thomson:false`, `recombination:false`, and `reionization:false`. Because OD002 is pending and the owner receipt is null, this is neither H3 selection nor supersession authority.

The historical collision implementations accept electron velocity and density/opacity data as inputs. They do not bind them to the A.4 perfect-fluid variables and do not supply an owner selector. `bianchireview87` SHA-256 is `6bb094d30a6d24b3feee11a1d9ae2827049945dae8281ed37d0d0796a6e9ea84`; all 434 regular members were searched. Optional `v_e`/`v_b` APIs and a moving-electron implementation are computational capabilities, not policy authority. No searched current artifact supplies a signed H1 identity, an H2 state extension, or an H3 scope receipt.

Recovered BI-T1 and M7-A1 scopes also do not decide applicability. BI-T1 is restricted to cold zero-electron-tilt scope; M7-A1 excludes finite electron tilt. M7-A1's statement that branch/background electron velocity is a separate matter input is a future design note without a density map, state extension, scope receipt, or owner signature; it cannot select H2.

## Result

`H4_UNRESOLVED_OWNER_CHOICE`

The bounded corpus supports a blocker, not a negative universal claim about files outside the connected/local corpus.
