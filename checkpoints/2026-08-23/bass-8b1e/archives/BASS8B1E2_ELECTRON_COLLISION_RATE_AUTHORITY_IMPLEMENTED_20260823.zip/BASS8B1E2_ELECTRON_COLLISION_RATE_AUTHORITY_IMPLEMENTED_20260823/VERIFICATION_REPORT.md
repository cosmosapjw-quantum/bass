# Verification report

## Result

```text
bounded claim             PASS
fresh independent review confirmed
production wiring         NOT PERFORMED
authority promotion       NOT CLAIMED
```

## Fresh post-review primary gate

The integrated command exited `0`:

```text
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_test_field.py
PYTHONDONTWRITEBYTECODE=1 python audit/electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python audit/p9_boost_screen.py
python -m json.tool docs/electron-collision-rate-contract.json
python -m json.tool docs/electron-test-field-contract.json
PYTHONDONTWRITEBYTECODE=1 python -m py_compile \
  bianchi/q/electron_rate.py bianchi/q/electron.py \
  tests/test_electron_collision_rate.py audit/electron_collision_rate.py
```

Observed:

```text
new focused gate                 13/13 PASS
prior electron/frame gate        13/13 PASS
rate audit cases                  2000
worst Lorentz scalar residual     8.496e-15
normal-frame D oracle             0.5 / 2 / 1.25
SI/cgs relative difference        0
counterstream midpoint n*/n       5/3
P9 worst screen leak              1.657e-15
JSON parse / source compilation   PASS
```

The signed-zero provenance repair was also run as a valid focused red/green:
the new assertion failed before the one-line canonicalization and passed after
it.  The independent verifier reran the repaired focused gate and retained
verdict `confirmed`.

## Deliberate limits

- No JAX or `bianchi_rustcore` runtime was available.
- No production consumer, Rust ABI, solver loop, branch, commit, PR, Jira, or
  Confluence change was made.
- Existing `collision_moving.py` applies `D` internally; future wiring must pass
  rest opacity rather than an observer rate, or it will create `D^2`.
- Cold-Thomson spectral and electron-temperature validity is not certified.
