# Seal receipt

Candidate archive:

```text
SHA-256 147805cc37eb161b41360b83399cb2a5fa245d2a08264837e676166fa77a7b33
ZIP CRC PASS
internal MANIFEST PASS
```

Clean extraction in a new temporary directory returned exit `0` for:

```text
electron collision-rate gate  13/13
electron/frame regression      13/13
rate covariance audit          2000 cases
P9 screen audit                PASS
two contract JSON parsers      PASS
```

The candidate was then resealed only to include this receipt, the append-only
candidate evidence, and a refreshed internal manifest.  The final ZIP hash is
kept in the external `.sha256` sidecar to avoid circular self-reference.
