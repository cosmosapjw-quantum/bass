# BASS-8B.1E.2 implementation report

## Bounded claim

The work copy implements a Python-only authority seam for:

1. cold-electron Thomson optical-depth rates per fluid-observer and normal-observer ray time;
2. normal-frame Hubble-time normalization;
3. an independent H2 number-current schedule;
4. an H1 density schedule that receives the live fluid beta at every positive-density query;
5. exact collision-off/vacuum velocity quotient behavior;
6. strict provenance/support and explicit proper-density SI/cgs conversion.

Status claimed for independent review:

```text
BOUNDED_IMPLEMENTED_NOT_PRODUCTION_WIRED_NOT_PROMOTED
```

## Formula and time correction

With `(-,+,+,+)`, proper density `n_e*`, and future ray,

```text
d_tau = -(n_e* sigma_T/c) u_e dot dx
r_f   = n_e* sigma_T c D_e<-f
r_n   = n_e* sigma_T c D_e<-normal
nu_Q  = r_n/H_normal
```

The preregistered shortcut `r_f/H_normal` was rejected after internal time-owner review.  A tilted comoving electron has `D_e<-f=1` but generally `D_e<-normal!=1`.

## Source identity

```text
331ce8904ddf821d4128bb7661e76dec7d9b91f79521d8109343d58e1d9c3180  bianchi/q/electron_rate.py
0d29b4039b60801a2c352bc3f08b744d6c6a8cf5c23bd1d68769a837e672e8d2  tests/test_electron_collision_rate.py
dc5d0c54e176dadeb0ab3506c487334204c526111b8293c5254c83bbe2999937  audit/electron_collision_rate.py
f1fd90f53401904433605514c6928d040cc48b07c36be78196654e7852717e3d  docs/ELECTRON-COLLISION-RATE-CONTRACT.md
53323428f9ec069dd08b9610897e7819c74082a4d5e691277dfd0dffe074cb5c  docs/electron-collision-rate-contract.json
```

Reused owners:

```text
f5fa2da696453ea0b11cfddeb7f824cd1bdb42596cd4e2947fb7841e1387aafe  bianchi/q/electron.py
d61d32fa0dc66a60257423d95d0fa4c7c2647a6cd8ec0f8a3a7755fd805322c2  bianchi/q/rate.py
ed69ff41fe99bca60cffe904c06afebc9c96b4cadbe1fba4b0ebcf64420672e4  bianchi/thermo/history_api.py
2fde1df38b213c50056d343d1e5d8aa1b96caaae43b1d529b11ac2f62592d3a0  bianchi/matter/collision_moving.py
```

## Evidence summary

- Valid initial red: missing module, exit 1.
- Initial green: 10/10.
- Second red/green: vacuum beta leaked into payload identity, then canonicalized.
- Final focused gate: 13/13.
- Fresh verifier: `confirmed`, with no Critical/High/Medium defects.
- Its sole Low finding, signed-zero vacuum payload identity, was reproduced and repaired by canonicalizing zero density before hashing; the new assertion is green.
- The same verifier reran the repaired focused gate (`13/13`, exit `0`) and retained verdict `confirmed`; the Low finding is closed.
- Prior frame gate: 13/13.
- Independent numerical audit: 2,000 random cases, maximum recorded relative/scalar residual `8.496e-15`.
- P9 screen audit unchanged, maximum leak `1.657e-15`.
- Contract JSON and source compilation: exit 0.

## Deliberate gaps

- No `Collision.v_b`, q/model, Q step-loop, Rust, branch, commit, PR, Jira, or Confluence mutation.
- Existing moving-collision oracle applies `D` internally; a future consumer must pass rest opacity, not this observer rate.
- Legacy `x_e n_H` is not automatically adapted to generic H2 proper density.
- Current interpolation is normal-tetrad-gauge dependent, not residual-U(1) descended, and may overshoot proper density for counter-streaming endpoints.
- Cold-electron state is declared, but photon-energy support is `ENERGY_DOMAIN_UNVERIFIED`; no Klein–Nishina validity claim is made.
- Full installed-package/JAX/Rust suites are unavailable on this host.

## Primary sources

- Younsi, Wu, Fuerst: https://arxiv.org/pdf/1207.4234
- Challinor: https://arxiv.org/pdf/astro-ph/9911481
- Pitrou: https://arxiv.org/pdf/0809.3036
