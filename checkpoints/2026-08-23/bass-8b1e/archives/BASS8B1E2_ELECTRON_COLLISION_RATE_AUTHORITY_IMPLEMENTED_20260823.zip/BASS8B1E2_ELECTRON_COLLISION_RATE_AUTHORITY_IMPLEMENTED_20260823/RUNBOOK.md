# Runbook

Run from this directory with Python 3.11+ and NumPy:

```bash
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_test_field.py
PYTHONDONTWRITEBYTECODE=1 python audit/electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python audit/p9_boost_screen.py
python -m json.tool docs/electron-collision-rate-contract.json >/dev/null
python -m json.tool docs/electron-test-field-contract.json >/dev/null
sha256sum -c MANIFEST.sha256
```

Expected focused counts are `13/13` and `13/13`; the rate audit reports 2,000
cases.  These commands deliberately use the bounded NumPy loader and do not
stand in for the unavailable full JAX/Rust suite.
