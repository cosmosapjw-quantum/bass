# Next single node

```text
BASS-8B.1E.3 — cold-Thomson energy-validity and consumer-contract authority
```

Do not wire the runtime yet.  First close the two remaining preconditions that
can otherwise create a silently wrong collision term.

1. Add provenance-bound photon-energy support and electron temperature.
2. Transform the support into the electron frame with the exact finite boost,
   `E_e = D E_source`; a source-frame-valid photon that crosses the bound after
   boosting must fail.
3. Define explicit dimensionless validity parameters
   `E_e,max/(m_e c^2)` and `k_B T_e/(m_e c^2)` and a caller-owned error budget.
4. Cross-check the exact Klein-Nishina total cross section and its low-energy
   expansion with an independent high-precision engine; do not promote a
   bolometric lane that lacks a spectral upper bound.
5. Freeze the consumer interface as two distinct values:

   ```text
   rest_opacity_s      = n_e* sigma_T c
   observer_ray_rate_s = rest_opacity_s D
   ```

   A consumer that already computes `D` must receive only `rest_opacity_s`.
6. Add omit-`D`, double-`D`, density-frame, boosted-threshold, vacuum, and
   backward-integration-orientation mutation tests.

Pass only if the validity predicate is source-bound and both consumer classes
apply `D` exactly once.  Otherwise checkpoint as `ENERGY_DOMAIN_UNVERIFIED`.
Production solver/Rust wiring, projector/classifier work, branch, commit, and PR
remain outside this node.
