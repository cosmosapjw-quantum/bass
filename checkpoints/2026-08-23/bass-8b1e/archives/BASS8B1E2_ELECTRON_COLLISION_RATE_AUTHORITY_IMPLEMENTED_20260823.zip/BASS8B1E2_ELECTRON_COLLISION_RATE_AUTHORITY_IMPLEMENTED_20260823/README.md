# BASS-8B.1E.2 — electron collision-rate authority

Status:

```text
BOUNDED_IMPLEMENTED
INDEPENDENT_CONFIRMED
NOT_PRODUCTION_WIRED
NOT_PROMOTED
```

This checkpoint adds a Python authority seam for an independent cold-electron
test field and the exact comoving-electron restriction.  It separates the
fluid-observer and normal-observer ray rates,

```text
r_f  = n_e* sigma_T c D_e<-f
r_n  = n_e* sigma_T c D_e<-normal
nu_Q = r_n / H_normal,
```

with `n_e*` the electron-rest proper density.  It also supplies strict,
provenance-bound independent and comoving schedules.  Vacuum velocity and the
sign bit of zero density are quotiented from payload identity.

The artifact contains the minimal source, focused tests, independent numerical
audits, contracts, provenance, and verification records needed to reproduce
the bounded claim.  It does not wire the new API into `Collision.v_b`, solver
loops, JAX, or Rust.  Cold-Thomson photon-energy support remains explicitly
`ENERGY_DOMAIN_UNVERIFIED`.

See `RUNBOOK.md`, `VERIFICATION_REPORT.md`, and `NEXT_ACTION.md`.
