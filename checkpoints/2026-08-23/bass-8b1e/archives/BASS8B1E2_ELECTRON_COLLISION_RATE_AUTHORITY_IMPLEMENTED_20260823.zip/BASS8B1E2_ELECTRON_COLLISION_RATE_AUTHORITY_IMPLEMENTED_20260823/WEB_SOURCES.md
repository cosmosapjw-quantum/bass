# Primary web sources

- Younsi, Wu, Fuerst, *General relativistic radiative transfer*:
  https://arxiv.org/pdf/1207.4234 — covariant optical-depth increment with
  `(-,+,+,+)` and the medium four-velocity.
- Challinor, *Microwave background anisotropies from gravitational waves*:
  https://arxiv.org/pdf/astro-ph/9911481 — exact observer-energy/Doppler and
  moving-electron Thomson collision structure, with signature conversion noted
  in the contract.
- Pitrou, *The radiative transfer at second order*:
  https://arxiv.org/pdf/0809.3036 — electron-rest proper density and the
  cold-Thomson/recoil/thermal validity boundary.
- NIST 2022 CODATA speed of light:
  https://physics.nist.gov/cuu/Constants/Value/c.html
- BIPM SI definition of the metre and exact `c`:
  https://www.bipm.org/en/measurement-units

These public sources constrain formulas and units.  They do not replace the
hash-bound internal source, tests, or schedule provenance in this checkpoint.
