# BASS-8B.1E.3 durable state — 2026-08-23

## Objective (frozen)

Implement and verify a bounded Python authority for deciding whether a
source-frame photon-energy support is safely inside the cold-electron Thomson
domain after the exact finite frame transformation, and freeze an explicit
consumer contract that separates rest opacity from an observer-ray rate.  The
authority must preserve explicit `c` and `k_B`, distinguish exact
Klein–Nishina recoil error from a caller-declared electron-temperature
coldness threshold, fail closed for bolometric/unknown spectral support, and
stop before production-loop, JAX, Rust, finite-ell, or authority-row promotion.

## Conventions and assumptions (frozen)

1. Metric signature is `(-,+,+,+)`; future photon propagation directions are
   unit spatial vectors in the named source tetrad.
2. `c`, `k_B`, and `m_e c^2` remain explicit SI quantities.  Photon energy is
   in joules and electron temperature in kelvin.
3. `x=E_e/(m_e c^2)` and `theta_e=k_B T_e/(m_e c^2)` are dimensionless.
4. For a source-frame photon, `E_e=D_{e<-source} E_source`, using the existing
   exact finite frame map.  For an all-sky energy support, the hostile endpoint
   is the maximum of `D` over the full unit sphere, not a sampled direction.
5. The exact total Klein–Nishina cross-section ratio for a stationary electron
   is the recoil authority.  Its difference from one does not by itself bound
   thermal redistribution or the full polarized collision operator.
6. A temperature check is therefore a declared policy `theta_e <= theta_max`,
   with provenance and no claim that `theta_max` equals a universal operator
   error.
7. A bolometric lane or any input without a finite spectral upper bound cannot
   be certified as Thomson-valid.
8. Existing moving-collision consumers that already multiply by `D` must
   receive `rest_opacity_s=n_e* sigma_T c`; consumers that do not own `D` may
   receive `observer_ray_rate_s=rest_opacity_s D`, never both.

## Hypotheses (frozen)

- **H1 — exact recoil ratio.** Prediction: a cancellation-safe implementation
  of `sigma_KN(x)/sigma_T` agrees with an independent high-precision exact
  expression from `x=0` through the declared finite domain and tends to one as
  `x->0`. Falsifier: non-finite output, ratio outside `(0,1]`, wrong low-energy
  coefficients, or disagreement above the numerical tolerance.
- **H2 — exact boost support.** Prediction: the all-sky electron-frame energy
  bound equals the analytic maximum of the time row of the exact Lorentz frame
  map and bounds every randomized direction. Falsifier: any direction exceeds
  the declared bound or a comoving frame yields a value other than the source
  bound.
- **H3 — fail-closed validity.** Prediction: certification requires finite
  non-negative `E_max`, finite non-negative `T_e`, a source-bound error budget,
  and both recoil and thermal predicates. Unknown/bolometric energy support is
  `UNVERIFIED`, not pass. Falsifier: an unknown support or violated predicate
  is certified.
- **H4 — one-D consumer contract.** Prediction: `rest_opacity_s` is isotropic
  and direction independent, while `observer_ray_rate_s` applies exactly one
  `D`; omit-`D` and double-`D` mutations fail. Falsifier: either consumer class
  cannot be represented without ambiguity or an existing internal-`D`
  consumer is documented to receive an observer rate.
- **H5 — bounded compatibility.** Prediction: new focused gates plus the prior
  collision-rate/frame/P9 gates pass without production-loop or Rust edits.
  Falsifier: the authority requires such an edit or regresses the sealed gates.

## Planned confirmatory experiments (frozen)

- **E1 — valid RED.** Add one focused direct-run test for the public validity
  authority and require a nonzero failure specifically because the behavior is
  absent.
- **E2 — high-precision formula authority.** Use the original Klein–Nishina
  result plus a Wolfram exact series/numerical receipt to freeze the normalized
  total cross section, low-energy expansion, and representative thresholds.
- **E3 — minimal GREEN.** Implement only the spectral-support, validity-policy,
  and one-D consumer seam required by E1; rerun the identical command to zero.
- **E4 — hostile numerical audit.** Compare production values to an independent
  high-precision oracle over logarithmic `x`, randomized boosts/directions,
  near-comoving and near-light cases, and exact boundary values.
- **E5 — fail-closed/mutation audit.** Exercise bolometric support, malformed
  units/provenance, boosted threshold crossing, vacuum, omit-`D`, double-`D`,
  and integration-orientation separation.
- **E6 — bounded regression.** Rerun BASS-8B.1E.2 focused rate/frame/P9 gates,
  parse machine contracts, and confirm no runtime/Rust owner was changed.
- **E7 — independent verification.** A fresh read-only verifier receives the
  frozen state, sources, tests, receipts, and claims without a suggested
  verdict and returns one research verdict.
- **E8 — durable seal.** Build a minimal manifest-bound ZIP, verify CRC, rerun
  clean-extracted focused commands, and create an external SHA-256 sidecar.

## Falsifiable criteria

- **C1:** E1 is a valid missing-behavior red and the identical command is green
  after E3.
- **C2:** E2/E4 establish exact formula, units, limits, and numerical stability.
- **C3:** E4 proves the all-sky boost bound for representative and hostile cases.
- **C4:** E5 proves fail-closed spectral/temperature policy and one-D ownership.
- **C5:** E6 is zero-exit and source identity shows no production/Rust mutation.
- **C6:** E7 is not `inconclusive`; findings are resolved or retained as blockers.
- **C7:** E8 manifest, CRC, clean extraction, gates, and sidecar are zero-exit.

## Stopping rules

- Stop as `BLOCKED_KN_FORMULA_MISMATCH` if independent exact engines disagree
  and one transcription cannot be identified within one classified retry.
- Stop as `ENERGY_DOMAIN_UNVERIFIED` rather than invent an `E_max` for a
  bolometric lane.
- Stop as `BLOCKED_CONSUMER_D_OWNERSHIP` if an existing consumer's `D`
  ownership cannot be classified without production mutation.
- At most one classified retry per exact-engine command; append all deviations.
- Do not install packages or modify `Collision.v_b`, solver loops, JAX/Rust ABI,
  finite-ell carrier, residual-U(1), projector/classifier, branch, commit, PR,
  Jira, or Confluence.

## Criterion status

- **C1: PASS.** Valid missing-behavior REDs preceded the focused 20/20 GREEN.
- **C2: PASS.** Wolfram exact series/limits and independent Decimal oracles agree.
- **C3: PASS.** Analytic all-sky bound and hostile randomized directions agree.
- **C4: PASS.** Fail-closed lanes and concrete one-D ownership are covered.
- **C5: PASS.** Prior gates pass and the E2 comparison has only the intended
  `electron_rate.py` seam among common decisive sources.
- **C6: PASS.** Fresh independent verdict is `confirmed`; no critical, high,
  or medium findings remain.
- **C7: PASS.** The final capsule was tested in place, manifest-bound, ZIP-CRC
  checked, clean-extracted, replayed, and paired with an external SHA-256
  sidecar before release.

## Evidence log (append-only)

- **EV000 — preregistration timing deviation.** The user requested web search,
  so initial source discovery for the original Klein–Nishina paper, thermal
  Compton literature, and NIST CODATA occurred before this state file existed.
  Those observations are discovery only and cannot close a criterion.
- **EV001 — Wolfram context discovery failure.** The required initial Wolfram
  semantic-context call failed once with MCP internal error `-32603`.  No
  formula result was obtained and no retry will be spent on that context
  endpoint; the independent Wolfram Language evaluator remains a separate
  planned exact engine for E2.
- **EV002 — Wolfram exact Klein–Nishina receipt.** The independent evaluator
  returned `Limit[R(x),x->0]=1`, the exact coefficients through `x^10`, and
  high-precision recoil thresholds.  In particular
  `R=1-2x+26/5*x^2-133/10*x^3+...`; the roots of `1-R={1e-2,1e-3,1e-4}` are
  `{0.0050658699987645858,0.00050065085986219560,
  0.000050006500858861094}`.  Direct high-precision evaluation emitted
  cancellation warnings at extremely small `x`, preregistering a series
  branch as an implementation requirement rather than hiding the diagnostic.
  Full input and output are preserved in `WOLFRAM_KN_RECEIPT.txt`.
- **EV003 — focused missing-behavior RED.** The first direct command exited 1
  with `RED: bianchi.q.electron_validity ... is absent`.  Later adversarial
  REDs separately exposed the nearly-null relative-gamma loss, unbound
  frame/temperature/state provenance, caller-selected consumer kind, tiny-x
  deficit subtraction, one-ray Doppler cancellation, near-unit direction
  leakage, numeric overflow, and malformed vacuum source input.  Each failed
  before its corresponding production change.
- **EV004 — bounded implementation GREEN.** The final identical focused
  command passes 20/20.  The authority uses exact-binary64 Decimal-80 for
  relative gamma, one-ray Doppler, and the nonsmall Klein–Nishina expression;
  a Wolfram x^10 series covers `x<=1e-3`, and the total-cross-section deficit
  is evaluated directly.  Certificate payload hashes bind state, frame,
  energy, temperature, budget, constants, event, outputs, and status.
- **EV005 — precise-special-function boundary.** Precise Bessel-K evaluations
  for `K_2(1/theta_e)` at `theta_e={0.1,0.01,0.001}` were preserved in
  `PRECISE_SPECIAL_FUNCTION_RECEIPT.txt`.  They support only the statement
  that a thermal normalization is a separate special-function authority; no
  finite-temperature promotion was inferred.
- **EV006 — hostile audit.** The stdlib Decimal oracle audit passes 1,201 KN
  points and 1,200 randomized boost cases.  Maximum ratio absolute error is
  `1.1102230246251565e-16`; boost extremum relative error is
  `5.329070518200751e-15`; tiny-x deficit error and hostile Decimal one-ray
  error are zero at reported binary64 precision.  Omit-D and double-D
  mutations remain visible at 1.0 and 2.0 respectively; scalar Q is blocked.
- **EV007 — bounded regressions.** Prior electron collision-rate and frame
  gates pass 13/13 each.  The independent 2,000-case rate audit has maximum
  reported residual `8.49594120975575e-15`; P9 screen audit maxima are at most
  `1.657e-15`.  Both machine contracts parse.
- **EV008 — explicit retained stops.** The total KN deficit is not a recoil
  energy or polarized/differential/thermal operator norm.  Mode A remains
  bolometric; Mode B has no hard SI energy calibration.  Q scalar collision
  generation, trajectory/segment suprema, reverse schedule support,
  integration orientation, project ceiling, runtime typing/wiring, and all
  authority-row promotion remain unverified.
- **EV009 — terminology correction without physics mutation.** The frozen
  preregistration used the shorthand "recoil error" for the exact KN/Thomson
  rate difference.  Adversarial review showed that this could be read too
  broadly.  Final public names, docs, and claims use only "stationary-electron
  total-cross-section relative error/deficit".  No evolution or cross-section
  formula changed.
- **EV010 — bounded adversarial verdict.** The hostile reviewer returned
  `BOUNDED_CONFIRMED_WITH_STOP_BOUNDARIES`.  It independently recovered the
  exact all-sky envelope and canonical Doppler oracles, confirmed fail-closed
  thermal/spectral lanes and consumer ownership, and retained the explicit
  stops for differential/polarized/thermal kernels, scalar Q generation,
  trajectory support/orientation, runtime typing, and project-wide promotion.
- **EV011 — fresh independent verification.** A read-only verifier re-read
  the final hashes and returned `confirmed` with no critical, high, or medium
  finding.  It replayed 20/20 + 13/13 + 13/13 focused tests, all focused
  audits, three JSON contracts, and independent Decimal-120 formula/frame
  oracles.  It also confirmed the actual `collision_moving` implementation
  owns `lp/L`, the scalar Q block, and the E2 change surface.  Git history,
  JAX, and Rust runtimes were unavailable, but none is required by this
  bounded Python claim and none was installed.
- **EV012 — final durable seal.** The minimal capsule contains the bounded
  implementation plus direct reproduction dependencies and reports.  In-place
  and clean-extracted runs pass 20/20 + 13/13 + 13/13, the validity/rate/P9
  audits, compilation, and three JSON parses.  `MANIFEST.sha256` verifies all
  payload members; the final ZIP passes CRC and is bound by the adjacent
  `.sha256` sidecar.  The archive name is
  `BASS8B1E3_COLD_THOMSON_VALIDITY_AUTHORITY_20260823.zip`.
