# BASS-8B.1E.3 implementation report

Status: `IMPLEMENTED_BOUNDED_NOT_PROMOTED`

## Delivered authority

This phase adds a bounded Python authority for an instantaneous cold-electron
Thomson validity decision.  It does not wire a solver runtime.

The authority now:

1. binds a finite source-frame photon-energy support, source observer frame,
   electron state, electron temperature, caller budget, event identity, and
   provenance into canonical SHA-256 payloads;
2. computes the exact all-sky relative-frame Doppler envelope

   ```text
   D_max = Gamma_rel + sqrt((Gamma_rel - 1)(Gamma_rel + 1))
   D_min = 1 / D_max
   ```

   from the supplied binary64 velocity components promoted exactly into a
   Decimal-80 calculation;
3. evaluates the stationary-electron total Klein-Nishina ratio with the
   Wolfram-derived order-10 series at `x <= 1e-3` and a Decimal-80 closed form
   above that switch;
4. evaluates the small-`x` deficit directly, avoiding a false zero from
   subtracting a rounded ratio from one;
5. certifies only the exact-cold delta lane (`T_e=0`) with finite hard spectral
   support and a caller-owned total-cross-section budget;
6. fails closed for positive-temperature tails, bolometric/unknown/effective
   spectral support, numeric-domain failures, and mismatched event/frame
   identities;
7. separates `RestOpacityPerSecond = n_e* sigma_T c` from
   `ObserverRayRatePerSecond = n_e* sigma_T c D` using concrete consumer IDs;
8. blocks the scalar Q consumer because its direction-dependent generator is
   not a scalar rate.

## Units and limits

```text
metric                         (-,+,+,+)
photon direction               future propagation direction in named tetrad
n_e*                           electron-rest proper density [m^-3]
E                              photon energy [J]
T_e                            electron temperature [K]
x                              E_e / (m_e c^2)
theta_e                        k_B T_e / (m_e c^2)
c                              299792458 m s^-1, exact SI
k_B                            1.380649e-23 J K^-1, exact SI
m_e c^2                        8.1871057880e-14 J, CODATA 2022
rate                           s^-1
```

The implemented error measure is only

```text
(sigma_T - sigma_KN) / sigma_T
```

for the total cross section of one stationary free electron.  It is not an
energy-loss, angular, polarized, thermal-tail, or redistribution error norm.

## Consumer ownership

| Consumer ID | Accepted input | Relative-flux owner |
|---|---|---|
| `bianchi.matter.collision_moving.collision_rate_density` | `RestOpacityPerSecond` | consumer |
| `external.single_observer_ray` | `ObserverRayRatePerSecond` | authority |
| `bianchi.q.scalar_collision_kernel` | blocked | unresolved direction-dependent generator |

The bounded validator rejects the wrong typed input.  Existing production
signatures still accept naked floats and were deliberately not changed.

## Source changes

- extended `bianchi/physical/units.py` with named CODATA/SI constants;
- added rest-opacity access to `bianchi/q/electron_rate.py`;
- added `bianchi/q/electron_validity.py`;
- added focused tests and hostile audit;
- added human- and machine-readable validity contracts.

No solver loop, `Collision.v_b`, JAX path, Rust ABI, finite-ell carrier,
projector/classifier, branch, commit, PR, Jira, or Confluence object was
changed.

## Retained stop boundaries

- no positive-temperature collision-kernel certification;
- no bolometric or effective-tail promotion;
- no trajectory-wide joint support or segment supremum;
- no reverse-schedule or integration-orientation authority;
- no scalar Q source-time generator;
- no runtime typed enforcement;
- no project-wide tolerance ceiling or authority-row promotion.
