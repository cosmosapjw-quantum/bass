# Next single node

`BASS-8B.1E.4 — trajectory-aligned support and integration-orientation authority`

## Why this is next

E3 certificates are instantaneous.  Reusing one along a trajectory would be
unsound without proving that photon-energy support, electron state,
temperature, and observer frame refer to the same event/time and remain valid
over every integration segment.

There is also a notation and sign boundary that must be explicit:

- the Q electron schedule uses increasing Hubble time `tau_Q`;
- CMB optical depth is conventionally accumulated from emission time to the
  observer, `kappa(eta)=integral_eta^eta0 kappa_dot deta`;
- a positive local future-ray collision rate therefore must not be confused
  with the derivative of a past-directed accumulated optical depth.

## Required output

Implement a bounded, typed trajectory authority that provides:

1. a common physical event/time coordinate and explicit maps from every
   schedule coordinate;
2. the closed intersection of electron, energy, temperature, frame, Hubble,
   and ray support, with no clamp or extrapolation;
3. a conservative per-segment supremum of

   ```text
   x_max = E_source,max D_max / (m_e c^2)
   theta_e = k_B T_e / (m_e c^2)
   ```

   including possible interior extrema created by nonlinear current-to-beta
   reconstruction;
4. separate typed orientations for:

   ```text
   FUTURE_KINETIC_IVP:
       d optical_depth_local / dt_source = +nu_source

   PAST_LIGHT_CONE_ACCUMULATION:
       optical_depth(t) = integral_t^t_observer nu_source dt_source
       d optical_depth / dt = -nu_source
   ```

5. ascending canonical storage independent of numerical traversal direction;
6. an immutable trajectory certificate binding support, orientation, segment
   maxima, sources, constants, and caller budget.

## Required hostile gates

- forward and reverse traversal of the same physical segment give equal
  non-negative accumulated optical depth after the declared orientation map;
- reversed solver `t_span` never implies reversed source arrays;
- a one-ULP support escape fails closed;
- mismatched event/time-coordinate provenance fails closed;
- an interior velocity extremum that exceeds endpoint-only sampling is caught;
- vacuum subsegments remain collision-off but do not erase spectral/frame
  validation for adjacent non-vacuum segments;
- the internal recombination observable's sorted-redshift accumulation is not
  silently reused as a kinetic-IVP sign convention;
- the E3 exact-cold and hard-support restrictions remain unchanged.

## Stop boundary

Do not implement the direction-dependent Q collision generator, production
solver wiring, JAX/Rust, finite-ell hierarchy, Planck-tail promotion, branch,
commit, or PR in this node.  After E4 closes, the separate next node is
`BASS-8B.1F — direction-dependent Q source-time collision generator` for
`kappa M_D (K-I)`.

## Preparatory authority sources

- Seljak and Zaldarriaga define positive differential Thomson depth and
  `kappa(eta)=integral_eta^eta0 kappa_dot deta`, with visibility
  `g=kappa_dot exp(-kappa)`:
  https://arxiv.org/pdf/astro-ph/9603033
- SciPy's official IVP contract says the solver starts at `t0` and integrates
  to `tf`; traversal direction is therefore solver input and must not be
  inferred from sorted source arrays:
  https://docs.scipy.org/doc/scipy/reference/generated/scipy.integrate.solve_ivp.html
- Internal `bianchi/q/electron_rate.py` currently stores strictly increasing
  `tau_Q` knots and rejects `end < start`.
- Internal `bianchi/thermo/recombination.py` sorts redshift and accumulates a
  positive `integral_0^z d optical_depth/dz`; this is an observable routine,
  not a signed kinetic-IVP authority.
- The internal `Low-ell Bianchi Einstein-Boltzmann Solver.txt` requires an
  exact electron-frame Thomson authority path and forbids treating a shortcut
  as production evidence.
