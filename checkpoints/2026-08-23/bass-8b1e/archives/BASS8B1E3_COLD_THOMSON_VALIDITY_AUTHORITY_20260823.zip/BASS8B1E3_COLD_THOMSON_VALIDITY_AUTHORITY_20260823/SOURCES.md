# BASS-8B.1E.3 source ledger

Retrieved: 2026-08-23

## Primary formula and constants

1. O. Klein and Y. Nishina, *Über die Streuung von Strahlung durch freie
   Elektronen nach der neuen relativistischen Quantendynamik*, Z. Phys. 52
   (1929), DOI `10.1007/BF01366453`.
   - Metadata/DOI: https://cir.nii.ac.jp/crid/1361418518949625600
   - Role: original free-electron Compton cross-section authority.
2. R. N. Lee, M. D. Schwartz, and X. Zhang, *Compton Scattering Total Cross
   Section at Next-to-Leading Order*, Phys. Rev. Lett. 126 (2021),
   arXiv:2102.06718.
   - https://arxiv.org/abs/2102.06718
   - Role: modern exact leading-order total formula and threshold expansion.
     Their variable `X=(s-m^2)/m^2` equals `2x` in an electron rest frame for
     this project's `x=E_e/(m_e c^2)`, giving
     `sigma_KN/sigma_T = 1-2x+26/5*x^2-...`.
3. E. Tiesinga et al., *CODATA Recommended Values of the Fundamental Physical
   Constants: 2022*, Rev. Mod. Phys. / NIST publication.
   - https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=958143
   - Values used: `k_B=1.380649e-23 J/K` exact and
     `m_e c^2=8.1871057880(26)e-14 J`.

## Scope boundaries

4. S. Y. Sazonov and R. A. Sunyaev, thermal/mildly relativistic Compton
   redistribution kernel, arXiv:astro-ph/9910280.
   - https://arxiv.org/abs/astro-ph/9910280
   - Role: confirms that photon energy and electron temperature are distinct
     expansion parameters.  It does not turn a total stationary-electron
     cross-section deficit into a finite-temperature operator-error bound.
5. NIST XCOM documentation.
   - https://physics.nist.gov/PhysRefData/Xcom/Text/intro.html
   - https://physics.nist.gov/PhysRefData/Xcom/Text/chap2.html
   - Role: boundary check only.  XCOM incoherent atomic cross sections add
     scattering functions/corrections; the implemented authority is for one
     free stationary electron, not an atomic material opacity.

## Interpretation guard

The web sources establish public physics and constants.  They do not replace
the hash-pinned internal electron state, source-frame, spectral-bound,
temperature, consumer-identity, or event provenance required by this gate.
The implemented measure is only
`(sigma_T-sigma_KN)/sigma_T` for the total stationary-electron cross section.
It is not a recoil-energy, angular, polarized, thermal-tail, or redistribution
error norm.
