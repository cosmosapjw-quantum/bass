# BASS-8B.1E.3 cold-Thomson validity authority

Verdict: `BOUNDED_IMPLEMENTED_VERIFIED_NOT_PROMOTED`

This archive records a bounded Python authority for instantaneous cold-electron
Thomson energy validity and collision-rate consumer ownership.  It includes
the exact-engine receipts, source ledger, tests, hostile audit, contracts,
implementation report, independent reviews, and reproduction commands.

The strongest positive claim is limited to an exact-cold (`T_e=0`) free
electron with finite hard photon-energy support, a matching source/electron
frame event, and a caller-owned stationary-electron total-cross-section
budget.

It does not certify thermal redistribution, bolometric spectra, a scalar Q
collision generator, trajectory-wide support, production runtime wiring, or
an authority-row promotion.  See `NEXT_ACTION.md` for the next single node.
