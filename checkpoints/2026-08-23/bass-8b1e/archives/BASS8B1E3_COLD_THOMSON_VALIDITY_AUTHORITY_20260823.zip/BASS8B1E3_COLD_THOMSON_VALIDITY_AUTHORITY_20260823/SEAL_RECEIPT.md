# Seal receipt

Artifact: `BASS8B1E3_COLD_THOMSON_VALIDITY_AUTHORITY_20260823.zip`

The capsule was assembled only from the frozen final hashes recorded in
`SOURCE_IDENTITY.json`, the predecessor reproduction dependencies, and the
durable E3 reports/receipts.

Pre-seal capsule gates:

```text
compile                              PASS
validity focused tests               20/20 PASS
collision-rate focused tests         13/13 PASS
electron state/frame focused tests   13/13 PASS
validity hostile audit               PASS (1201 KN, 1200 boost)
collision-rate audit                 PASS (2000 cases)
P9 screen audit                      PASS
machine JSON                         3/3 PASS
```

Release conditions are `MANIFEST.sha256` verification, ZIP member CRC,
clean-extracted replay of the decisive gates, and an external archive
SHA-256 sidecar.  No Git, branch, commit, PR, Jira, or Confluence mutation is
part of this seal.
