# Reproduction runbook

Run from the sealed repository root with the project Python environment.

```bash
PYTHONDONTWRITEBYTECODE=1 python -m py_compile \
  bianchi/physical/units.py \
  bianchi/q/electron_rate.py \
  bianchi/q/electron_validity.py \
  tests/test_electron_thomson_validity.py \
  audit/electron_thomson_validity.py

PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_thomson_validity.py
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python tests/test_electron_test_field.py
PYTHONDONTWRITEBYTECODE=1 python audit/electron_thomson_validity.py
PYTHONDONTWRITEBYTECODE=1 python audit/electron_collision_rate.py
PYTHONDONTWRITEBYTECODE=1 python -m audit.p9_boost_screen
python -m json.tool docs/electron-thomson-validity-contract.json >/dev/null
```

These commands verify the bounded Python authority only.  They do not prove
production runtime wiring, a full polarized/thermal collision operator, or an
authority-row promotion.
