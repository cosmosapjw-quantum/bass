# BASS RF-04 polarized source-probe bootstrap

Exact predecessor:

```text
branch agent/architecture/rf04-scalar-raw-20260829-fhxMnS
HEAD   50b6e9f7a6741b7fd25b0421d2a674b9eb92cdda
tree   b32fcc26ca51dcaca9e9225d48b03fe9e02988ed
PR     #57 OPEN / DRAFT / UNMERGED
```

The scalar fixed-node raw slice is already proven and is reused. This package
does not reopen it and does not resurrect the withdrawn A2 contract.

The five remaining polarized boundaries are resolved by executable source
differentials, not by another prose contract. If all five have a unique
source-supported disposition, the same local run immediately writes genuine
composed RED and implements full RF-04. If a boundary remains nonunique, the
run returns measured candidates/counterexamples without inventing authority.
