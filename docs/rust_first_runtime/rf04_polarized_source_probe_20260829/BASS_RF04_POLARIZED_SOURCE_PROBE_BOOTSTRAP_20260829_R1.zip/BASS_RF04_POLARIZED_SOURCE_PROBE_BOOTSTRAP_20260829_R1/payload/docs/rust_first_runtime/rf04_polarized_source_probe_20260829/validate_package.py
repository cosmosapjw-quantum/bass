#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FILES={
 "README.md","PACKAGE.json","SOURCE_INVENTORY.json","PROBE_MATRIX.json",
 "WORK_UNITS.json","ACCEPTANCE_MATRIX.json","CODEX_HANDOFF.md",
 "validate_package.py"
}
HEAD="50b6e9f7a6741b7fd25b0421d2a674b9eb92cdda"
TREE="b32fcc26ca51dcaca9e9225d48b03fe9e02988ed"
BRANCH="agent/architecture/rf04-scalar-raw-20260829-fhxMnS"
BLOBS={"_rustcore/src/kinetic/rf04_contract_tests.rs": "db546232ab78c6a279eb1b6a82e5bb03c7c78656", "_rustcore/src/kinetic/rf04_typeii.rs": "71508ebb9b3a5abd3bc403d6a24502ad9de09d39", "docs/rust_first_runtime/rf04_external_review_resume_20260829/CONTRACT.json": "a6cdf5c3c0b32fa09083f13439ddd16743d19e3a", "runtime/rust/typeii/tests/FIXTURE_PROVENANCE.json": "09df0fb7bd3ea7f557b55822e2b053d26b31717c", "runtime/rust/typeii/tests/typeii_polarized_liouville_fixture.rs": "ac8c1d069a61a4281f8feb39d25ba99100389962", "runtime/rust/typeii/tests/typeii_polarized_liouville_unit.rs": "90fb4d6a6413ef89ae61b742f9892ed34cf59ce6", "runtime/rust/typeii/tests/typeii_polarized_remap_fixture.rs": "45c87f0bf194cd6f9c4e0747d35436d8f960d450", "runtime/rust/typeii/tests/typeii_polarized_remap_unit.rs": "7aae4aeec3e95e2d2d2c82fa1617bedd8e698028", "runtime/rust/typeii/typeii_collision_ap.rs": "1a8d0efd21451d47b532f66d7a739cc322f28bbd", "runtime/rust/typeii/typeii_physical_guard.rs": "a2fa999a42dc010f804be0b844da1c8d313bb38b", "runtime/rust/typeii/typeii_polarized_liouville.rs": "da6fade06f717ab938b0ec4c712ab239e78c998a", "runtime/rust/typeii/typeii_polarized_remap.rs": "5f7a1e580df3855f07f567fb3baa0e339d52c82e", "runtime/rust/typeii/typeii_polarized_runtime.rs": "a852431274c206cc81b063f9501e46a524bd3765", "runtime/rust/typeii/typeii_polarized_runtime_physical.rs": "03684d7a9ef76be3bb06841af86bb5822574bab3"}

def fail(x): raise SystemExit("FAIL: "+x)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(repo,*args):
 p=subprocess.run(["git","--no-replace-objects",*args],cwd=repo,text=True,
                  stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 if p.returncode: fail("git "+" ".join(args)+": "+p.stderr.strip())
 return p.stdout.removesuffix("\n")

def local():
 entries={}
 for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
  if line.strip():
   d,n=line.split(maxsplit=1)
   if n in entries: fail("duplicate manifest")
   entries[n]=d
 if set(entries)!=FILES: fail("manifest closure")
 for n,d in entries.items():
  if digest(ROOT/n)!=d: fail("digest "+n)
 p=json.loads((ROOT/"PACKAGE.json").read_text())
 if p["package_id"]!="BASS-RF04-POLARIZED-SOURCE-PROBE-20260829-R1": fail("package id")
 if p["exact_next_action"]!="RF04-POL-01_EXECUTABLE_SOURCE_DIFFERENTIAL": fail("next action")
 m=json.loads((ROOT/"PROBE_MATRIX.json").read_text())
 if len(m["probes"])!=5: fail("probe count")
 if m["rules"]["no_candidate_selected_by_document_preference"] is not True: fail("selection rule")
 w=json.loads((ROOT/"WORK_UNITS.json").read_text())
 if w["exact_next_action"]!="RF04-POL-01_EXECUTABLE_SOURCE_DIFFERENTIAL": fail("work unit")

def live(repo_arg):
 repo=Path(git(repo_arg,"rev-parse","--show-toplevel"))
 if git(repo,"rev-parse","--verify","refs/remotes/origin/"+BRANCH)!=HEAD: fail("source branch moved")
 if git(repo,"rev-parse",HEAD+"^{tree}")!=TREE: fail("source tree")
 for path,blob in BLOBS.items():
  if git(repo,"rev-parse",HEAD+":"+path)!=blob: fail("source blob "+path)

if __name__=="__main__":
 ap=argparse.ArgumentParser();ap.add_argument("--live",action="store_true");ap.add_argument("--repo",default=".");a=ap.parse_args()
 local()
 if a.live: live(Path(a.repo))
 print(json.dumps({"status":"PASS","package_id":"BASS-RF04-POLARIZED-SOURCE-PROBE-20260829-R1",
  "source_head":HEAD,"source_tree":TREE,
  "exact_next_action":"RF04-POL-01_EXECUTABLE_SOURCE_DIFFERENTIAL",
  "claim":"PASS_RF04_SCALAR_RAW_SLICE_PROOF_AND_NO_PASS_RF04",
  "live":a.live},sort_keys=True))
